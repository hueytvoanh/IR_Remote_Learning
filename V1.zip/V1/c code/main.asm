
;CodeVisionAVR C Compiler V1.25.6 Standard
;(C) Copyright 1998-2007 Pavel Haiduc, HP InfoTech s.r.l.
;http://www.hpinfotech.com

;Chip type              : ATmega8
;Program type           : Application
;Clock frequency        : 12.000000 MHz
;Memory model           : Small
;Optimize for           : Speed
;(s)printf features     : int, width
;(s)scanf features      : int, width
;External SRAM size     : 0
;Data Stack size        : 256 byte(s)
;Heap size              : 0 byte(s)
;Promote char to int    : No
;char is unsigned       : Yes
;8 bit enums            : Yes
;Word align FLASH struct: No
;Enhanced core instructions    : On
;Smart register allocation : On
;Automatic register allocation : On

	#pragma AVRPART ADMIN PART_NAME ATmega8
	#pragma AVRPART MEMORY PROG_FLASH 8192
	#pragma AVRPART MEMORY EEPROM 512
	#pragma AVRPART MEMORY INT_SRAM SIZE 1024
	#pragma AVRPART MEMORY INT_SRAM START_ADDR 0x60

	.LISTMAC
	.EQU UDRE=0x5
	.EQU RXC=0x7
	.EQU USR=0xB
	.EQU UDR=0xC
	.EQU SPSR=0xE
	.EQU SPDR=0xF
	.EQU EERE=0x0
	.EQU EEWE=0x1
	.EQU EEMWE=0x2
	.EQU EECR=0x1C
	.EQU EEDR=0x1D
	.EQU EEARL=0x1E
	.EQU EEARH=0x1F
	.EQU WDTCR=0x21
	.EQU MCUCR=0x35
	.EQU GICR=0x3B
	.EQU SPL=0x3D
	.EQU SPH=0x3E
	.EQU SREG=0x3F

	.DEF R0X0=R0
	.DEF R0X1=R1
	.DEF R0X2=R2
	.DEF R0X3=R3
	.DEF R0X4=R4
	.DEF R0X5=R5
	.DEF R0X6=R6
	.DEF R0X7=R7
	.DEF R0X8=R8
	.DEF R0X9=R9
	.DEF R0XA=R10
	.DEF R0XB=R11
	.DEF R0XC=R12
	.DEF R0XD=R13
	.DEF R0XE=R14
	.DEF R0XF=R15
	.DEF R0X10=R16
	.DEF R0X11=R17
	.DEF R0X12=R18
	.DEF R0X13=R19
	.DEF R0X14=R20
	.DEF R0X15=R21
	.DEF R0X16=R22
	.DEF R0X17=R23
	.DEF R0X18=R24
	.DEF R0X19=R25
	.DEF R0X1A=R26
	.DEF R0X1B=R27
	.DEF R0X1C=R28
	.DEF R0X1D=R29
	.DEF R0X1E=R30
	.DEF R0X1F=R31

	.MACRO __CPD1N
	CPI  R30,LOW(@0)
	LDI  R26,HIGH(@0)
	CPC  R31,R26
	LDI  R26,BYTE3(@0)
	CPC  R22,R26
	LDI  R26,BYTE4(@0)
	CPC  R23,R26
	.ENDM

	.MACRO __CPD2N
	CPI  R26,LOW(@0)
	LDI  R30,HIGH(@0)
	CPC  R27,R30
	LDI  R30,BYTE3(@0)
	CPC  R24,R30
	LDI  R30,BYTE4(@0)
	CPC  R25,R30
	.ENDM

	.MACRO __CPWRR
	CP   R@0,R@2
	CPC  R@1,R@3
	.ENDM

	.MACRO __CPWRN
	CPI  R@0,LOW(@2)
	LDI  R30,HIGH(@2)
	CPC  R@1,R30
	.ENDM

	.MACRO __ADDB1MN
	SUBI R30,LOW(-@0-(@1))
	.ENDM
	.MACRO __ADDB2MN
	SUBI R26,LOW(-@0-(@1))
	.ENDM
	.MACRO __ADDW1MN
	SUBI R30,LOW(-@0-(@1))
	SBCI R31,HIGH(-@0-(@1))
	.ENDM
	.MACRO __ADDW2MN
	SUBI R26,LOW(-@0-(@1))
	SBCI R27,HIGH(-@0-(@1))
	.ENDM
	.MACRO __ADDW1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	.ENDM
	.MACRO __ADDD1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	SBCI R22,BYTE3(-2*@0-(@1))
	.ENDM
	.MACRO __ADDD1N
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	SBCI R22,BYTE3(-@0)
	SBCI R23,BYTE4(-@0)
	.ENDM

	.MACRO __ADDD2N
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	SBCI R24,BYTE3(-@0)
	SBCI R25,BYTE4(-@0)
	.ENDM

	.MACRO __SUBD1N
	SUBI R30,LOW(@0)
	SBCI R31,HIGH(@0)
	SBCI R22,BYTE3(@0)
	SBCI R23,BYTE4(@0)
	.ENDM

	.MACRO __SUBD2N
	SUBI R26,LOW(@0)
	SBCI R27,HIGH(@0)
	SBCI R24,BYTE3(@0)
	SBCI R25,BYTE4(@0)
	.ENDM

	.MACRO __ANDBMNN
	LDS  R30,@0+@1
	ANDI R30,LOW(@2)
	STS  @0+@1,R30
	.ENDM

	.MACRO __ANDWMNN
	LDS  R30,@0+@1
	ANDI R30,LOW(@2)
	STS  @0+@1,R30
	LDS  R30,@0+@1+1
	ANDI R30,HIGH(@2)
	STS  @0+@1+1,R30
	.ENDM

	.MACRO __ANDD1N
	ANDI R30,LOW(@0)
	ANDI R31,HIGH(@0)
	ANDI R22,BYTE3(@0)
	ANDI R23,BYTE4(@0)
	.ENDM

	.MACRO __ORBMNN
	LDS  R30,@0+@1
	ORI  R30,LOW(@2)
	STS  @0+@1,R30
	.ENDM

	.MACRO __ORWMNN
	LDS  R30,@0+@1
	ORI  R30,LOW(@2)
	STS  @0+@1,R30
	LDS  R30,@0+@1+1
	ORI  R30,HIGH(@2)
	STS  @0+@1+1,R30
	.ENDM

	.MACRO __ORD1N
	ORI  R30,LOW(@0)
	ORI  R31,HIGH(@0)
	ORI  R22,BYTE3(@0)
	ORI  R23,BYTE4(@0)
	.ENDM

	.MACRO __DELAY_USB
	LDI  R24,LOW(@0)
__DELAY_USB_LOOP:
	DEC  R24
	BRNE __DELAY_USB_LOOP
	.ENDM

	.MACRO __DELAY_USW
	LDI  R24,LOW(@0)
	LDI  R25,HIGH(@0)
__DELAY_USW_LOOP:
	SBIW R24,1
	BRNE __DELAY_USW_LOOP
	.ENDM

	.MACRO __CLRD1S
	LDI  R30,0
	STD  Y+@0,R30
	STD  Y+@0+1,R30
	STD  Y+@0+2,R30
	STD  Y+@0+3,R30
	.ENDM

	.MACRO __GETD1S
	LDD  R30,Y+@0
	LDD  R31,Y+@0+1
	LDD  R22,Y+@0+2
	LDD  R23,Y+@0+3
	.ENDM

	.MACRO __PUTD1S
	STD  Y+@0,R30
	STD  Y+@0+1,R31
	STD  Y+@0+2,R22
	STD  Y+@0+3,R23
	.ENDM

	.MACRO __PUTD2S
	STD  Y+@0,R26
	STD  Y+@0+1,R27
	STD  Y+@0+2,R24
	STD  Y+@0+3,R25
	.ENDM

	.MACRO __POINTB1MN
	LDI  R30,LOW(@0+@1)
	.ENDM

	.MACRO __POINTW1MN
	LDI  R30,LOW(@0+@1)
	LDI  R31,HIGH(@0+@1)
	.ENDM

	.MACRO __POINTD1M
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __POINTW1FN
	LDI  R30,LOW(2*@0+@1)
	LDI  R31,HIGH(2*@0+@1)
	.ENDM

	.MACRO __POINTD1FN
	LDI  R30,LOW(2*@0+@1)
	LDI  R31,HIGH(2*@0+@1)
	LDI  R22,BYTE3(2*@0+@1)
	LDI  R23,BYTE4(2*@0+@1)
	.ENDM

	.MACRO __POINTB2MN
	LDI  R26,LOW(@0+@1)
	.ENDM

	.MACRO __POINTW2MN
	LDI  R26,LOW(@0+@1)
	LDI  R27,HIGH(@0+@1)
	.ENDM

	.MACRO __POINTBRM
	LDI  R@0,LOW(@1)
	.ENDM

	.MACRO __POINTWRM
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __POINTBRMN
	LDI  R@0,LOW(@1+@2)
	.ENDM

	.MACRO __POINTWRMN
	LDI  R@0,LOW(@2+@3)
	LDI  R@1,HIGH(@2+@3)
	.ENDM

	.MACRO __POINTWRFN
	LDI  R@0,LOW(@2*2+@3)
	LDI  R@1,HIGH(@2*2+@3)
	.ENDM

	.MACRO __GETD1N
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __GETD2N
	LDI  R26,LOW(@0)
	LDI  R27,HIGH(@0)
	LDI  R24,BYTE3(@0)
	LDI  R25,BYTE4(@0)
	.ENDM

	.MACRO __GETD2S
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	LDD  R24,Y+@0+2
	LDD  R25,Y+@0+3
	.ENDM

	.MACRO __GETB1MN
	LDS  R30,@0+@1
	.ENDM

	.MACRO __GETB1HMN
	LDS  R31,@0+@1
	.ENDM

	.MACRO __GETW1MN
	LDS  R30,@0+@1
	LDS  R31,@0+@1+1
	.ENDM

	.MACRO __GETD1MN
	LDS  R30,@0+@1
	LDS  R31,@0+@1+1
	LDS  R22,@0+@1+2
	LDS  R23,@0+@1+3
	.ENDM

	.MACRO __GETBRMN
	LDS  R@0,@1+@2
	.ENDM

	.MACRO __GETWRMN
	LDS  R@0,@2+@3
	LDS  R@1,@2+@3+1
	.ENDM

	.MACRO __GETWRZ
	LDD  R@0,Z+@2
	LDD  R@1,Z+@2+1
	.ENDM

	.MACRO __GETD2Z
	LDD  R26,Z+@0
	LDD  R27,Z+@0+1
	LDD  R24,Z+@0+2
	LDD  R25,Z+@0+3
	.ENDM

	.MACRO __GETB2MN
	LDS  R26,@0+@1
	.ENDM

	.MACRO __GETW2MN
	LDS  R26,@0+@1
	LDS  R27,@0+@1+1
	.ENDM

	.MACRO __GETD2MN
	LDS  R26,@0+@1
	LDS  R27,@0+@1+1
	LDS  R24,@0+@1+2
	LDS  R25,@0+@1+3
	.ENDM

	.MACRO __PUTB1MN
	STS  @0+@1,R30
	.ENDM

	.MACRO __PUTW1MN
	STS  @0+@1,R30
	STS  @0+@1+1,R31
	.ENDM

	.MACRO __PUTD1MN
	STS  @0+@1,R30
	STS  @0+@1+1,R31
	STS  @0+@1+2,R22
	STS  @0+@1+3,R23
	.ENDM

	.MACRO __PUTBR0MN
	STS  @0+@1,R0
	.ENDM

	.MACRO __PUTDZ2
	STD  Z+@0,R26
	STD  Z+@0+1,R27
	STD  Z+@0+2,R24
	STD  Z+@0+3,R25
	.ENDM

	.MACRO __PUTBMRN
	STS  @0+@1,R@2
	.ENDM

	.MACRO __PUTWMRN
	STS  @0+@1,R@2
	STS  @0+@1+1,R@3
	.ENDM

	.MACRO __PUTBZR
	STD  Z+@1,R@0
	.ENDM

	.MACRO __PUTWZR
	STD  Z+@2,R@0
	STD  Z+@2+1,R@1
	.ENDM

	.MACRO __GETW1R
	MOV  R30,R@0
	MOV  R31,R@1
	.ENDM

	.MACRO __GETW2R
	MOV  R26,R@0
	MOV  R27,R@1
	.ENDM

	.MACRO __GETWRN
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __PUTW1R
	MOV  R@0,R30
	MOV  R@1,R31
	.ENDM

	.MACRO __PUTW2R
	MOV  R@0,R26
	MOV  R@1,R27
	.ENDM

	.MACRO __ADDWRN
	SUBI R@0,LOW(-@2)
	SBCI R@1,HIGH(-@2)
	.ENDM

	.MACRO __ADDWRR
	ADD  R@0,R@2
	ADC  R@1,R@3
	.ENDM

	.MACRO __SUBWRN
	SUBI R@0,LOW(@2)
	SBCI R@1,HIGH(@2)
	.ENDM

	.MACRO __SUBWRR
	SUB  R@0,R@2
	SBC  R@1,R@3
	.ENDM

	.MACRO __ANDWRN
	ANDI R@0,LOW(@2)
	ANDI R@1,HIGH(@2)
	.ENDM

	.MACRO __ANDWRR
	AND  R@0,R@2
	AND  R@1,R@3
	.ENDM

	.MACRO __ORWRN
	ORI  R@0,LOW(@2)
	ORI  R@1,HIGH(@2)
	.ENDM

	.MACRO __ORWRR
	OR   R@0,R@2
	OR   R@1,R@3
	.ENDM

	.MACRO __EORWRR
	EOR  R@0,R@2
	EOR  R@1,R@3
	.ENDM

	.MACRO __GETWRS
	LDD  R@0,Y+@2
	LDD  R@1,Y+@2+1
	.ENDM

	.MACRO __PUTWSR
	STD  Y+@2,R@0
	STD  Y+@2+1,R@1
	.ENDM

	.MACRO __MOVEWRR
	MOV  R@0,R@2
	MOV  R@1,R@3
	.ENDM

	.MACRO __INWR
	IN   R@0,@2
	IN   R@1,@2+1
	.ENDM

	.MACRO __OUTWR
	OUT  @2+1,R@1
	OUT  @2,R@0
	.ENDM

	.MACRO __CALL1MN
	LDS  R30,@0+@1
	LDS  R31,@0+@1+1
	ICALL
	.ENDM

	.MACRO __CALL1FN
	LDI  R30,LOW(2*@0+@1)
	LDI  R31,HIGH(2*@0+@1)
	RCALL __GETW1PF
	ICALL
	.ENDM

	.MACRO __CALL2EN
	LDI  R26,LOW(@0+@1)
	LDI  R27,HIGH(@0+@1)
	RCALL __EEPROMRDW
	ICALL
	.ENDM

	.MACRO __GETW1STACK
	IN   R26,SPL
	IN   R27,SPH
	ADIW R26,@0+1
	LD   R30,X+
	LD   R31,X
	.ENDM

	.MACRO __NBST
	BST  R@0,@1
	IN   R30,SREG
	LDI  R31,0x40
	EOR  R30,R31
	OUT  SREG,R30
	.ENDM


	.MACRO __PUTB1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RNS
	MOVW R26,R@0
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	RCALL __PUTDP1
	.ENDM


	.MACRO __GETB1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R30,Z
	.ENDM

	.MACRO __GETB1HSX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	.ENDM

	.MACRO __GETW1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R0,Z+
	LD   R31,Z
	MOV  R30,R0
	.ENDM

	.MACRO __GETD1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R0,Z+
	LD   R1,Z+
	LD   R22,Z+
	LD   R23,Z
	MOVW R30,R0
	.ENDM

	.MACRO __GETB2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R26,X
	.ENDM

	.MACRO __GETW2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	.ENDM

	.MACRO __GETD2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R1,X+
	LD   R24,X+
	LD   R25,X
	MOVW R26,R0
	.ENDM

	.MACRO __GETBRSX
	MOVW R30,R28
	SUBI R30,LOW(-@1)
	SBCI R31,HIGH(-@1)
	LD   R@0,Z
	.ENDM

	.MACRO __GETWRSX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	LD   R@0,Z+
	LD   R@1,Z
	.ENDM

	.MACRO __LSLW8SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	CLR  R30
	.ENDM

	.MACRO __PUTB1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __CLRW1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	CLR  R0
	ST   Z+,R0
	ST   Z,R0
	.ENDM

	.MACRO __CLRD1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	CLR  R0
	ST   Z+,R0
	ST   Z+,R0
	ST   Z+,R0
	ST   Z,R0
	.ENDM

	.MACRO __PUTB2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z,R26
	.ENDM

	.MACRO __PUTW2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z,R27
	.ENDM

	.MACRO __PUTD2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z+,R27
	ST   Z+,R24
	ST   Z,R25
	.ENDM

	.MACRO __PUTBSRX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z,R@1
	.ENDM

	.MACRO __PUTWSRX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	ST   Z+,R@0
	ST   Z,R@1
	.ENDM

	.MACRO __PUTB1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __MULBRR
	MULS R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRRU
	MUL  R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRR0
	MULS R@0,R@1
	.ENDM

	.MACRO __MULBRRU0
	MUL  R@0,R@1
	.ENDM

	.MACRO __MULBNWRU
	LDI  R26,@2
	MUL  R26,R@0
	MOVW R30,R0
	MUL  R26,R@1
	ADD  R31,R0
	.ENDM

	.CSEG
	.ORG 0

	.INCLUDE "main.vec"
	.INCLUDE "main.inc"

__RESET:
	CLI
	CLR  R30
	OUT  EECR,R30

;INTERRUPT VECTORS ARE PLACED
;AT THE START OF FLASH
	LDI  R31,1
	OUT  GICR,R31
	OUT  GICR,R30
	OUT  MCUCR,R30

;DISABLE WATCHDOG
	LDI  R31,0x18
	OUT  WDTCR,R31
	OUT  WDTCR,R30

;CLEAR R2-R14
	LDI  R24,13
	LDI  R26,2
	CLR  R27
__CLEAR_REG:
	ST   X+,R30
	DEC  R24
	BRNE __CLEAR_REG

;CLEAR SRAM
	LDI  R24,LOW(0x400)
	LDI  R25,HIGH(0x400)
	LDI  R26,0x60
__CLEAR_SRAM:
	ST   X+,R30
	SBIW R24,1
	BRNE __CLEAR_SRAM

;GLOBAL VARIABLES INITIALIZATION
	LDI  R30,LOW(__GLOBAL_INI_TBL*2)
	LDI  R31,HIGH(__GLOBAL_INI_TBL*2)
__GLOBAL_INI_NEXT:
	LPM  R24,Z+
	LPM  R25,Z+
	SBIW R24,0
	BREQ __GLOBAL_INI_END
	LPM  R26,Z+
	LPM  R27,Z+
	LPM  R0,Z+
	LPM  R1,Z+
	MOVW R22,R30
	MOVW R30,R0
__GLOBAL_INI_LOOP:
	LPM  R0,Z+
	ST   X+,R0
	SBIW R24,1
	BRNE __GLOBAL_INI_LOOP
	MOVW R30,R22
	RJMP __GLOBAL_INI_NEXT
__GLOBAL_INI_END:

;STACK POINTER INITIALIZATION
	LDI  R30,LOW(0x45F)
	OUT  SPL,R30
	LDI  R30,HIGH(0x45F)
	OUT  SPH,R30

;DATA STACK POINTER INITIALIZATION
	LDI  R28,LOW(0x160)
	LDI  R29,HIGH(0x160)

	RJMP _main

	.ESEG
	.ORG 0

	.DSEG
	.ORG 0x160
;       1 /*****************************************************
;       2 This program was produced by the
;       3 CodeWizardAVR V1.25.6 Standard
;       4 Automatic Program Generator
;       5 � Copyright 1998-2007 Pavel Haiduc, HP InfoTech s.r.l.
;       6 http://www.hpinfotech.com
;       7 
;       8 Project : Controller
;       9 Version : A
;      10 Date    : 9/2/2009
;      11 Author  : Thien Duy
;      12 Company : TDT
;      13 Comments:
;      14 
;      15 
;      16 Chip type           : ATmega8
;      17 Program type        : Application
;      18 Clock frequency     : 12.000000 MHz
;      19 Memory model        : Small
;      20 External SRAM size  : 0
;      21 Data Stack size     : 256
;      22 *****************************************************/
;      23 
;      24 #include <mega8.h>
;      25 	#ifndef __SLEEP_DEFINED__
	#ifndef __SLEEP_DEFINED__
;      26 	#define __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
;      27 	.EQU __se_bit=0x80
	.EQU __se_bit=0x80
;      28 	.EQU __sm_mask=0x70
	.EQU __sm_mask=0x70
;      29 	.EQU __sm_powerdown=0x20
	.EQU __sm_powerdown=0x20
;      30 	.EQU __sm_powersave=0x30
	.EQU __sm_powersave=0x30
;      31 	.EQU __sm_standby=0x60
	.EQU __sm_standby=0x60
;      32 	.EQU __sm_ext_standby=0x70
	.EQU __sm_ext_standby=0x70
;      33 	.EQU __sm_adc_noise_red=0x10
	.EQU __sm_adc_noise_red=0x10
;      34 	.SET power_ctrl_reg=mcucr
	.SET power_ctrl_reg=mcucr
;      35 	#endif
	#endif
;      36 
;      37 
;      38 // External Interrupt 1 service routine
;      39 interrupt [EXT_INT1] void ext_int1_isr(void)
;      40 {

	.CSEG
_ext_int1_isr:
;      41 // Place your code here
;      42 
;      43 }
	RETI
;      44 ///////////////////////////////////////////////////////
;      45 //Hardware define
;      46 
;      47 #define LATCH   	PORTD.7
;      48 #define LEDSCL  	PORTD.6
;      49 #define LEDSDA  	PORTD.5
;      50 #define BELLOUT    	PORTD.4
;      51 #define TX_EN   	PORTD.2
;      52 
;      53 #define bONpower		PORTC.3
;      54 #define bSwitch		PINC.4
;      55 
;      56 #define PWM_Bass    PORTB.3
;      57 #define PWM_Treble  PORTB.5
;      58 #define PWM_Volume  PORTB.4
;      59 
;      60 #define EncodeS		PINB.1
;      61 #define EncodeC		PINB.2
;      62 #define bON_OFF		PINB.0
;      63 
;      64 ///////////////////////////////////////////////////////
;      65 #define RXB8 1
;      66 #define TXB8 0
;      67 #define UPE 2
;      68 #define OVR 3
;      69 #define FE 4
;      70 #define UDRE 5
;      71 #define RXC 7
;      72 #define Nop #asm("NOP")
;      73 
;      74 #define PINGPONG    0x02
;      75 #define FAN_        0x04
;      76 #define CS_LINE2_   0x01
;      77 #define CS_LINE1_   0x02
;      78 #define CS_LINE12_  0x03
;      79 #define SOUNDON     0x20
;      80 #define ALARM       0x40
;      81 #define AMP_PW      0x80
;      82 
;      83 #define ADC_LIGHT   5
;      84 #define ADC_VOICE   2
;      85 #define ADC_ROOM    1
;      86 #define ADC_ALUM    0
;      87 
;      88 #define CHANEL_ON   0x80
;      89 #define CHANEL_OFF  0x00
;      90 #define CHANELA     0x10
;      91 #define CHANELB     0x00
;      92 
;      93 #define ANALOG1     3
;      94 #define ANALOG2     2
;      95 #define ANALOG3     1
;      96 #define ANALOG4     0
;      97 #define MIC_FRONT   6
;      98 #define MIC_BACK    7
;      99 #define BELL1       5
;     100 #define BELL2       4
;     101 
;     102 #define AUTO_ON_MIC 	0x10
;     103 #define AUTO_OFF		0x20
;     104 #define AUTO_RESTORE	0x40
;     105 #define ACK_ENABLE		0x80
;     106 
;     107 #define CHANEL_AUTO		0x08
;     108 #define CHANEL_OFFALL	0x00
;     109 #define CHANEL_1		0x01
;     110 #define CHANEL_2		0x02
;     111 #define CHANEL_12		0x03
;     112 
;     113 #define GREEN       2
;     114 #define RED         1
;     115 
;     116 #define vSYNC           0
;     117 #define vBELL_ON        1
;     118 #define vALARM_ON       2
;     119 #define vALARM_BELL_ON  3
;     120 #define vUPDATE_TIME    4
;     121 #define vSTARTUP_MODE   5
;     122 #define vON_DEVICE      6
;     123 #define vOFF_DEVICE     7
;     124 #define vUPDATE_AMPLI   8
;     125 #define vALARM_HALF     9
;     126 #define vANALOG_SELECT  10
;     127 #define vALARM_ONE		11
;     128 #define vUPDATE_ADDR	12
;     129 #define vREAD_STATUS	14
;     130 #define vCONFIG			15
;     131 #define vREAD_SENSOR	16
;     132 
;     133 #define ACK				0x0f
;     134 
;     135 #define BIT0    0x01
;     136 #define BIT1    0x02
;     137 #define BIT2    0x04
;     138 #define BIT3    0x08
;     139 #define BIT4    0x10
;     140 #define BIT5    0x20
;     141 #define BIT6    0x40
;     142 #define BIT7    0x80
;     143 
;     144 #define MAXADDR	180
;     145 
;     146 #define ALARM1RING	14
;     147 #define ALARM2RING	8
;     148 #define ALARM4RING	1
;     149 
;     150 #define FRAMING_ERROR (1<<FE)
;     151 #define PARITY_ERROR (1<<UPE)
;     152 #define DATA_OVERRUN (1<<OVR)
;     153 #define DATA_REGISTER_EMPTY (1<<UDRE)
;     154 #define RX_COMPLETE (1<<RXC)
;     155 
;     156  typedef struct {
;     157                     unsigned char week;
;     158                     unsigned char day;
;     159                     unsigned char hour;
;     160                     unsigned char minute;
;     161                     unsigned char second;
;     162                     } time_format;
;     163 
;     164  typedef struct {
;     165                     unsigned char hour;
;     166                     unsigned char minute;
;     167                     } alarm_format;
;     168 
;     169 /////////////////////////////////////////////////////////////////
;     170 // Declare your global variables here
;     171 
;     172 eeprom char eeTreble = 8, eeBass = 6, eeVolume = 8, eeFixAdd = 255, eeFixAdd_ = ~255;

	.ESEG
_eeTreble:
	.DB  0x8
_eeBass:
	.DB  0x6
_eeVolume:
	.DB  0x8
_eeFixAdd:
	.DB  0xFF
_eeFixAdd_:
	.DB  0x0
;     173 eeprom char eeLimitMode = 0;
_eeLimitMode:
	.DB  0x0
;     174 eeprom char eeLimitVolHi = 7;
_eeLimitVolHi:
	.DB  0x7
;     175 eeprom char eeLimitVolLo = 3;
_eeLimitVolLo:
	.DB  0x3
;     176 eeprom char eeConfig = AUTO_RESTORE | CHANEL_1;
_eeConfig:
	.DB  0x41
;     177 eeprom char eeChanelA = MIC_FRONT | CHANEL_ON | CHANELA;
_eeChanelA:
	.DB  0x96
;     178 eeprom char eeChanelB = MIC_FRONT | CHANEL_ON | CHANELB;
_eeChanelB:
	.DB  0x86
;     179 eeprom char eefON_OFF = 1;
_eefON_OFF:
	.DB  0x1
;     180 eeprom char eeAutoline_bk = ~CS_LINE1_;
_eeAutoline_bk:
	.DB  0xFD
;     181 eeprom char eeBellVolume = 3;
_eeBellVolume:
	.DB  0x3
;     182 eeprom char eeAnalogControl = BIT7 | BIT3 | BIT4;          // BITMICRO   + BITANALOG1
_eeAnalogControl:
	.DB  0x98
;     183 eeprom char eefAutoGain = 1;
_eefAutoGain:
	.DB  0x1
;     184 eeprom char eeSoundLevel = 100;			// 8 bit sound level
_eeSoundLevel:
	.DB  0x64
;     185 
;     186 
;     187 char Treble_value, Bass_value, Volume_value, status=0,Loadreg = ~CS_LINE1_;

	.DSEG
;     188 char AnalogControl=0, Display[6];
_Display:
	.BYTE 0x6
;     189 
;     190 char timer2_delay = 0,test,SendDelay,status_AND = 0xFF;
_SendDelay:
	.BYTE 0x1
_status_AND:
	.BYTE 0x1
;     191 char Rx_Mc = 0, FixAdd, RxDelay = 2,Delay1ms;
_Rx_Mc:
	.BYTE 0x1
_FixAdd:
	.BYTE 0x1
_RxDelay:
	.BYTE 0x1
_Delay1ms:
	.BYTE 0x1
;     192 bit f10ms_ov = 0,fSendSense = 0;
;     193 bit fVolume_AND = 1, fBass_AND = 1, fTreble_AND = 1;
;     194 
;     195 bit fBell_en = 0, fPingPong = 0,fRx_error = 0,fBlinkRED =0, fON_OFF = 1,fON_OFFsw = 0;
;     196 bit fSendACK,fWriteAnalog, fBackup,fSecond,fLedRed,fLedGreen;
;     197 bit fTranFinish = 1,fSendStatus = 0, fAutoGain = 0;
;     198 bit fEncodeSedge,fEncodeSold, fSwitch = 0,fSwitchOld = 0;
;     199 
;     200 char Bell_pulse = 1, Bell_freq = 10, Alarm_Mc = 0;
_Bell_pulse:
	.BYTE 0x1
_Bell_freq:
	.BYTE 0x1
_Alarm_Mc:
	.BYTE 0x1
;     201 
;     202 char CRC,Tx_TimeOut = 10;
_CRC:
	.BYTE 0x1
_Tx_TimeOut:
	.BYTE 0x1
;     203 
;     204 //bit fBellOn, fAnalog1, fAnalog2, fAnalog3, fAnalog4, fMicro;
;     205 #define BITBELL		BIT2
;     206 #define BITANALOG1	BIT3
;     207 #define BITANALOG2	BIT4
;     208 #define BITANALOG4	BIT5
;     209 #define BITANALOG3	BIT6
;     210 #define BITMICRO	BIT7
;     211 
;     212 time_format currenttime = {1,2,0,0,0};
_currenttime:
_0currenttime:
	.BYTE 0x1
_1currenttime:
	.BYTE 0x1
_2currenttime:
	.BYTE 0x1
_3currenttime:
	.BYTE 0x1
_4currenttime:
	.BYTE 0x1
;     213 
;     214 #define SEGA	~(0x01 << 2)
;     215 #define SEGB	~(0x01 << 3)
;     216 #define SEGC	~(0x01 << 5)
;     217 #define SEGD	~(0x01 << 6)
;     218 #define SEGE	~(0x01 << 7)
;     219 #define SEGF	~(0x01 << 1)
;     220 #define SEGG	~(0x01 << 0)
;     221 #define SEGDP_INV	~(0x01 << 4)
;     222 
;     223 #define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
;     224 #define LEDNUM1		SEGE & SEGF
;     225 #define LEDNUM2		SEGA & SEGB & SEGD & SEGE & SEGG
;     226 #define LEDNUM3		SEGA & SEGD & SEGE & SEGF & SEGG
;     227 #define LEDNUM4		              SEGC        & SEGE & SEGF  & SEGG
;     228 #define LEDNUM5		SEGA &        SEGC & SEGD &        SEGF  & SEGG
;     229 #define LEDNUM6		SEGA & SEGB & SEGC & SEGD &        SEGF  & SEGG
;     230 #define LEDNUM7		                     SEGD & SEGE & SEGF
;     231 #define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
;     232 #define LEDNUM9		SEGA &        SEGC & SEGD & SEGE & SEGF  & SEGG
;     233 #define LEDNUMA		       SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
;     234 #define LEDNUMB		SEGA & SEGB & SEGC &               SEGF  & SEGG
;     235 #define LEDNUMC		SEGA & SEGB & SEGC & SEGD
;     236 #define LEDNUMD		SEGA & SEGB &               SEGE & SEGF  & SEGG
;     237 #define LEDNUME		SEGA & SEGB & SEGC & SEGD &                SEGG
;     238 #define LEDNUMF		       SEGB & SEGC & SEGD &                SEGG
;     239 #define LEDNUM16	SEGG
;     240 #define LEDNUM17	0xFF
;     241 
;     242 //#define BIT0    0x01
;     243 //#define BIT1    0x02
;     244 //#define BIT2    0x04
;     245 //#define BIT3    0x08
;     246 //#define BIT4    0x10
;     247 //#define BIT5    0x20
;     248 //#define BIT6    0x40
;     249 //#define BIT7    0x80
;     250 
;     251 const unsigned char   MaledInv[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,

	.CSEG
;     252 								 LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};
;     253 
;     254 #define SEGA	~(0x01 << 5)
;     255 #define SEGB	~(0x01 << 4)
;     256 #define SEGC	~(0x01 << 2)
;     257 #define SEGD	~(0x01 << 1)
;     258 #define SEGE	~(0x01 << 0)
;     259 #define SEGF	~(0x01 << 6)
;     260 #define SEGG	~(0x01 << 7)
;     261 #define SEGDP	~(0x01 << 3)
;     262 
;     263 #define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
;     264 #define LEDNUM1		SEGB & SEGC
;     265 #define LEDNUM2		SEGA & SEGB &  SEGD & SEGE & SEGG
;     266 #define LEDNUM3		SEGA & SEGB & SEGC & SEGD & SEGG
;     267 #define LEDNUM4		SEGB & SEGC & SEGG & SEGF
;     268 #define LEDNUM5		SEGA & SEGC & SEGD & SEGG & SEGF
;     269 #define LEDNUM6		SEGA & SEGG & SEGC & SEGD & SEGE & SEGF
;     270 #define LEDNUM7		SEGA & SEGB & SEGC
;     271 #define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
;     272 #define LEDNUM9		SEGA & SEGB & SEGC & SEGD & SEGF  & SEGG
;     273 #define LEDNUMA		SEGA & SEGB & SEGC & SEGE & SEGF  & SEGG
;     274 #define LEDNUMB		SEGC & SEGD & SEGE & SEGF  & SEGG
;     275 #define LEDNUMC		SEGA & SEGD & SEGE & SEGF
;     276 #define LEDNUMD		SEGB & SEGC & SEGD & SEGE & SEGG
;     277 #define LEDNUME		SEGA & SEGD & SEGE & SEGF  & SEGG
;     278 #define LEDNUMF		SEGA & SEGE & SEGF  & SEGG
;     279 #define LEDNUM16	SEGG
;     280 #define LEDNUM17	0xFF
;     281 
;     282 
;     283 
;     284 const unsigned char   Maled[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,
;     285 								    LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};
;     286 const char MapAddr[8] = {0, 4, 2, 6, 1, 5, 3, 7};
;     287 const char CRC8_DATA[256]={
;     288 		0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
;     289 		0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e,	0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
;     290 		0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0,	0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
;     291 		0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,	0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
;     292 		0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,	0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
;     293 		0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58,	0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
;     294 		0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6,	0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
;     295 		0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b,	0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
;     296 		0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f,	0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
;     297 		0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92,	0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
;     298 		0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c,	0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
;     299 		0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1,	0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
;     300 		0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49,	0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
;     301 		0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,	0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
;     302 		0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a,	0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
;     303 		0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7,	0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35};
;     304 
;     305 /////////////////////////////////////////////////////////////////
;     306 /////////////////////////////////////////////////////////////////
;     307 // data structure
;     308 // time format: second : minute : hour : day : date : month
;     309 /////////////////////////////////////////////////////////////////
;     310 /////////////////////////////////////////////////////////////////
;     311 
;     312 // USART Receiver buffer
;     313 #define RX_BUFFER_SIZE 8
;     314 char rx_buffer[RX_BUFFER_SIZE];

	.DSEG
_rx_buffer:
	.BYTE 0x8
;     315 char rx_buffer_out[RX_BUFFER_SIZE];
_rx_buffer_out:
	.BYTE 0x8
;     316 
;     317 #if RX_BUFFER_SIZE<256
;     318 unsigned char rx_wr_index,rx_rd_index;//,rx_counter;
_rx_wr_index:
	.BYTE 0x1
_rx_rd_index:
	.BYTE 0x1
;     319 #else
;     320 unsigned int rx_wr_index,rx_rd_index;//,rx_counter;
;     321 #endif
;     322 
;     323 // This flag is set on USART Receiver buffer overflow
;     324 bit fRx_receive = 0;
;     325 
;     326 /////////////////////////////////////////////////////
;     327 /////////////////////////////////////////////////////
;     328 // Data frame format for network
;     329 // using fix size data frame: restart if lost of data byte
;     330 // Header: | Slave address or 0xFF | command | data bytes | CRC (include command) |
;     331 //size of frame = RX_BUFFER_SIZE including address, command, data and CRC bytes
;     332 
;     333 /////////////////////////////////////////////////////
;     334 /////////////////////////////////////////////////////
;     335 // USART Receiver interrupt service routine
;     336 interrupt [USART_RXC] void usart_rx_isr(void)
;     337 {

	.CSEG
_usart_rx_isr:
	ST   -Y,R0
	ST   -Y,R26
	ST   -Y,R27
	ST   -Y,R30
	ST   -Y,R31
	IN   R30,SREG
	ST   -Y,R30
;     338 char status1,data;
;     339 status1=UCSRA;
	RCALL __SAVELOCR2
;	status1 -> R17
;	data -> R16
	IN   R17,11
;     340 data=UDR;
	IN   R16,12
;     341 //test = data;
;     342 //fBlinkRED = 1;
;     343 if ((status1 & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
	MOV  R30,R17
	ANDI R30,LOW(0x1C)
	BREQ PC+2
	RJMP _0xB
;     344 {
;     345 switch (Rx_Mc)
	LDS  R30,_Rx_Mc
;     346     {
;     347     case 0:
	CPI  R30,0
	BRNE _0xF
;     348         {
;     349  //        UCSRA &= ~BIT0;       // turn off address mode
;     350          rx_buffer[0]=data;   //store the address byte
	STS  _rx_buffer,R16
;     351          rx_wr_index=1;
	LDI  R30,LOW(1)
	STS  _rx_wr_index,R30
;     352          CRC = data;
	STS  _CRC,R16
;     353          CRC = CRC8_DATA[CRC];
	LDS  R30,_CRC
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA*2)
	SBCI R31,HIGH(-_CRC8_DATA*2)
	LPM  R0,Z
	STS  _CRC,R0
;     354          Rx_Mc = 1;
	LDI  R30,LOW(1)
	STS  _Rx_Mc,R30
;     355          RxDelay = 5;
	LDI  R30,LOW(5)
	STS  _RxDelay,R30
;     356         }
;     357 
;     358     break;
	RJMP _0xE
;     359     case 1:         // receiving data frame
_0xF:
	CPI  R30,LOW(0x1)
	BREQ PC+2
	RJMP _0x1B
;     360     rx_buffer[rx_wr_index]=data;
	LDS  R30,_rx_wr_index
	LDI  R31,0
	SUBI R30,LOW(-_rx_buffer)
	SBCI R31,HIGH(-_rx_buffer)
	ST   Z,R16
;     361     RxDelay = 5;
	LDI  R30,LOW(5)
	STS  _RxDelay,R30
;     362     CRC ^= data;
	MOV  R30,R16
	LDS  R26,_CRC
	EOR  R30,R26
	STS  _CRC,R30
;     363     CRC = CRC8_DATA[CRC];
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA*2)
	SBCI R31,HIGH(-_CRC8_DATA*2)
	LPM  R0,Z
	STS  _CRC,R0
;     364     if (++rx_wr_index == RX_BUFFER_SIZE)
	LDS  R26,_rx_wr_index
	SUBI R26,-LOW(1)
	STS  _rx_wr_index,R26
	CPI  R26,LOW(0x8)
	BRNE _0x11
;     365        {
;     366   //  if ((data == FixAdd) || (data == 0xFF))
;     367        if ((CRC == 0) && ((rx_buffer[0] == FixAdd) || (rx_buffer[0] == 0xFF)))
	LDS  R26,_CRC
	CPI  R26,LOW(0x0)
	BRNE _0x13
	LDS  R30,_FixAdd
	LDS  R26,_rx_buffer
	CP   R30,R26
	BREQ _0x14
	CPI  R26,LOW(0xFF)
	BRNE _0x13
_0x14:
	RJMP _0x16
_0x13:
	RJMP _0x12
_0x16:
;     368             {
;     369             fRx_receive = 1;
	SET
	BLD  R5,0
;     370             for (rx_wr_index=0;rx_wr_index<RX_BUFFER_SIZE;rx_wr_index++)      //double buffer purpose
	LDI  R30,LOW(0)
	STS  _rx_wr_index,R30
_0x18:
	LDS  R26,_rx_wr_index
	CPI  R26,LOW(0x8)
	BRSH _0x19
;     371                 {
;     372                 rx_buffer_out[rx_wr_index] = rx_buffer[rx_wr_index];
	LDI  R27,0
	SUBI R26,LOW(-_rx_buffer_out)
	SBCI R27,HIGH(-_rx_buffer_out)
	LDS  R30,_rx_wr_index
	LDI  R31,0
	SUBI R30,LOW(-_rx_buffer)
	SBCI R31,HIGH(-_rx_buffer)
	LD   R30,Z
	ST   X,R30
;     373                 }
	LDS  R30,_rx_wr_index
	SUBI R30,-LOW(1)
	STS  _rx_wr_index,R30
	RJMP _0x18
_0x19:
;     374             }
;     375        else
	RJMP _0x1A
_0x12:
;     376             {
;     377              fRx_error = 1;
	SET
	BLD  R2,7
;     378             }
_0x1A:
;     379        Rx_Mc = 0;
	LDI  R30,LOW(0)
	STS  _Rx_Mc,R30
;     380 //       UCSRA |= BIT0;       // turn on address mode
;     381        };
_0x11:
;     382     break;
	RJMP _0xE
;     383     default:
_0x1B:
;     384     Rx_Mc = 0;
	LDI  R30,LOW(0)
	STS  _Rx_Mc,R30
;     385     }
_0xE:
;     386 }
;     387 }
_0xB:
	RCALL __LOADLOCR2P
	LD   R30,Y+
	OUT  SREG,R30
	LD   R31,Y+
	LD   R30,Y+
	LD   R27,Y+
	LD   R26,Y+
	LD   R0,Y+
	RETI
;     388 
;     389 #ifndef _DEBUG_TERMINAL_IO_
;     390 // Get a character from the USART Receiver buffer
;     391 #define _ALTERNATE_GETCHAR_
;     392 #pragma used+
;     393 #pragma used-
;     394 #endif
;     395 
;     396 // USART Transmitter buffer
;     397 #define TX_BUFFER_SIZE 10
;     398 char tx_buffer[TX_BUFFER_SIZE];

	.DSEG
_tx_buffer:
	.BYTE 0xA
;     399 
;     400 #if TX_BUFFER_SIZE<256
;     401 unsigned char tx_wr_index,tx_rd_index,tx_counter;
_tx_wr_index:
	.BYTE 0x1
_tx_rd_index:
	.BYTE 0x1
_tx_counter:
	.BYTE 0x1
;     402 #else
;     403 unsigned int tx_wr_index,tx_rd_index,tx_counter;
;     404 #endif
;     405 
;     406 // USART Transmitter interrupt service routine
;     407 interrupt [USART_TXC] void usart_tx_isr(void)
;     408 {

	.CSEG
_usart_tx_isr:
	ST   -Y,R26
	ST   -Y,R30
	ST   -Y,R31
	IN   R30,SREG
	ST   -Y,R30
;     409 if (tx_counter != 0)
	LDS  R30,_tx_counter
	CPI  R30,0
	BREQ _0x1C
;     410    {
;     411    --tx_counter;
	SUBI R30,LOW(1)
	STS  _tx_counter,R30
;     412    UDR=tx_buffer[tx_rd_index];
	LDS  R30,_tx_rd_index
	LDI  R31,0
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	LD   R30,Z
	OUT  0xC,R30
;     413    Tx_TimeOut = 10;
	LDI  R30,LOW(10)
	STS  _Tx_TimeOut,R30
;     414    if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index=0;
	LDS  R26,_tx_rd_index
	SUBI R26,-LOW(1)
	STS  _tx_rd_index,R26
	CPI  R26,LOW(0xA)
	BRNE _0x1D
	LDI  R30,LOW(0)
	STS  _tx_rd_index,R30
;     415    }
_0x1D:
;     416 else
	RJMP _0x1E
_0x1C:
;     417    {
;     418 	fTranFinish = 1;
	SET
	BLD  R4,1
;     419 	TX_EN = 0;
	CBI  0x12,2
;     420    }
_0x1E:
;     421 }
	LD   R30,Y+
	OUT  SREG,R30
	LD   R31,Y+
	LD   R30,Y+
	LD   R26,Y+
	RETI
;     422 
;     423 #ifndef _DEBUG_TERMINAL_IO_
;     424 // Write a character to the USART Transmitter buffer
;     425 #define _ALTERNATE_PUTCHAR_
;     426 #endif
;     427 
;     428 // Standard Input/Output functions
;     429 #include <stdio.h>
;     430 
;     431 // Timer 0 overflow interrupt service routine
;     432 interrupt [TIM0_OVF] void timer0_ovf_isr(void)
;     433 {
_timer0_ovf_isr:
	ST   -Y,R26
	ST   -Y,R30
	IN   R30,SREG
	ST   -Y,R30
;     434     static char T_cycle;

	.DSEG
_T_cycle_S3:
	.BYTE 0x1

	.CSEG
;     435 // Place your code here
;     436 // timer 0 has 12MHz clock input
;     437 // Overflow cycle = 12000/50 = 240KHz
;     438 // PWM cycle = 240KHz /T_cycle = 2.4KHz if T_cycle=100
;     439 
;     440     TCNT0 = (unsigned char)(-50);
	LDI  R30,LOW(206)
	OUT  0x32,R30
;     441     if (++T_cycle == 101)
	LDS  R26,_T_cycle_S3
	SUBI R26,-LOW(1)
	STS  _T_cycle_S3,R26
	CPI  R26,LOW(0x65)
	BRNE _0x1F
;     442         {
;     443         T_cycle = 0;   // make fund cycle = 14*28*MC
	LDI  R30,LOW(0)
	STS  _T_cycle_S3,R30
;     444         PWM_Bass = 1;
	SBI  0x18,3
;     445         PWM_Volume = 1;
	SBI  0x18,4
;     446         PWM_Treble = 1;
	SBI  0x18,5
;     447         }
;     448     if (Bass_value == T_cycle) PWM_Bass = 0;
_0x1F:
	LDS  R30,_T_cycle_S3
	CP   R30,R6
	BRNE _0x20
	CBI  0x18,3
;     449     if (Treble_value == T_cycle) PWM_Treble = 0;
_0x20:
	LDS  R30,_T_cycle_S3
	CP   R30,R7
	BRNE _0x21
	CBI  0x18,5
;     450     if (Volume_value == T_cycle) PWM_Volume = 0;
_0x21:
	LDS  R30,_T_cycle_S3
	CP   R30,R9
	BRNE _0x22
	CBI  0x18,4
;     451 
;     452 }
_0x22:
	RJMP _0x212
;     453 
;     454 // Timer 2 output compare interrupt service routine
;     455 interrupt [TIM2_COMP] void timer2_comp_isr(void)
;     456 {
_timer2_comp_isr:
	ST   -Y,R26
	ST   -Y,R30
	IN   R30,SREG
	ST   -Y,R30
;     457     // 100us overflow interrupt
;     458     if (SendDelay != 0) SendDelay --;
	LDS  R30,_SendDelay
	CPI  R30,0
	BREQ _0x23
	SUBI R30,LOW(1)
	STS  _SendDelay,R30
;     459     if (++Delay1ms == 10)
_0x23:
	LDS  R26,_Delay1ms
	SUBI R26,-LOW(1)
	STS  _Delay1ms,R26
	CPI  R26,LOW(0xA)
	BRNE _0x24
;     460         {
;     461         Delay1ms = 0;
	LDI  R30,LOW(0)
	STS  _Delay1ms,R30
;     462         if (RxDelay != 0) RxDelay --;
	LDS  R30,_RxDelay
	CPI  R30,0
	BREQ _0x25
	SUBI R30,LOW(1)
	STS  _RxDelay,R30
	SUBI R30,-LOW(1)
;     463         }
_0x25:
;     464     if (++timer2_delay == 100)
_0x24:
	INC  R13
	LDI  R30,LOW(100)
	CP   R30,R13
	BRNE _0x26
;     465         {
;     466         timer2_delay = 0;
	CLR  R13
;     467         f10ms_ov = 1;
	SET
	BLD  R2,0
;     468         }
;     469 
;     470     //process Bell here
;     471     if (fBell_en)
_0x26:
	SBRS R2,5
	RJMP _0x27
;     472         {
;     473         if (--Bell_pulse == 0)
	LDS  R30,_Bell_pulse
	SUBI R30,LOW(1)
	STS  _Bell_pulse,R30
	CPI  R30,0
	BRNE _0x28
;     474             {
;     475             Bell_pulse = Bell_freq;
	LDS  R30,_Bell_freq
	STS  _Bell_pulse,R30
;     476             BELLOUT = ~BELLOUT;
	CLT
	SBIS 0x12,4
	SET
	IN   R26,0x12
	BLD  R26,4
	OUT  0x12,R26
;     477             }
;     478         }
_0x28:
;     479     else
	RJMP _0x29
_0x27:
;     480         {
;     481         BELLOUT = 0;
	CBI  0x12,4
;     482         }
_0x29:
;     483 
;     484 }
_0x212:
	LD   R30,Y+
	OUT  SREG,R30
	LD   R30,Y+
	LD   R26,Y+
	RETI
;     485 
;     486 #include <delay.h>
;     487 
;     488 #define ADC_VREF_TYPE 0x40
;     489 
;     490 // Read the AD conversion result
;     491 unsigned int read_adc(unsigned char adc_input)
;     492 {
_read_adc:
;     493 ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
;	adc_input -> Y+0
	LD   R30,Y
	ORI  R30,0x40
	OUT  0x7,R30
;     494 // Delay needed for the stabilization of the ADC input voltage
;     495 delay_us(10);
	__DELAY_USB 40
;     496 // Start the AD conversion
;     497 ADCSRA|=0x40;
	SBI  0x6,6
;     498 // Wait for the AD conversion to complete
;     499 while ((ADCSRA & 0x10)==0);
_0x2A:
	SBIS 0x6,4
	RJMP _0x2A
;     500 ADCSRA|=0x10;
	SBI  0x6,4
;     501 return ADCW;
	IN   R30,0x4
	IN   R31,0x4+1
	ADIW R28,1
	RET
;     502 }
;     503 /////////////////////////////////////////////////////////////////
;     504 ////////////////////////////////////////////////////
;     505 void ShiftData (char value_in)
;     506 {
_ShiftData:
;     507     char i;
;     508     for (i=0;i<8;i++)
	ST   -Y,R17
;	value_in -> Y+1
;	i -> R17
	LDI  R17,LOW(0)
_0x2E:
	CPI  R17,8
	BRSH _0x2F
;     509     {
;     510      LEDSDA = (value_in & 0x80);
	LDD  R30,Y+1
	BST  R30,7
	IN   R26,0x12
	BLD  R26,5
	OUT  0x12,R26
;     511      value_in <<= 1;
	LSL  R30
	STD  Y+1,R30
;     512     Nop;
	NOP
;     513     Nop;
	NOP
;     514     Nop;
	NOP
;     515      LEDSCL = 1;
	SBI  0x12,6
;     516      Nop;
	NOP
;     517      Nop;
	NOP
;     518      Nop;
	NOP
;     519      LEDSCL = 0;
	CBI  0x12,6
;     520     }
	SUBI R17,-1
	RJMP _0x2E
_0x2F:
;     521 }
	LDD  R17,Y+0
	ADIW R28,2
	RET
;     522 
;     523 /////////////////////////////////////////////////////////////////
;     524 void outled(void)
;     525 {
_outled:
;     526     static char LedMode;

	.DSEG
_LedMode_S7:
	.BYTE 0x1

	.CSEG
;     527 	char DataOut;
;     528 //    char temp;
;     529 //    if (fON_OFF == 0)
;     530 //        {
;     531 //         fVolume_AND = 0;
;     532 //         fBass_AND = 0;
;     533 //         fTreble_AND = 0;
;     534 //        }
;     535         switch (LedMode)
	ST   -Y,R17
;	DataOut -> R17
	LDS  R30,_LedMode_S7
;     536         {
;     537         case 0:
	CPI  R30,0
	BRNE _0x33
;     538         DataOut = MaledInv[Display[3]];
	__GETB1MN _Display,3
	LDI  R31,0
	SUBI R30,LOW(-_MaledInv*2)
	SBCI R31,HIGH(-_MaledInv*2)
	LPM  R17,Z
;     539         if (fSecond) DataOut &=  SEGDP_INV;
	SBRC R3,6
	ANDI R17,LOW(239)
;     540 //if (fSecond) DataOut &=  SEGDP;
;     541         if (!fBass_AND) DataOut = 0xff;
	SBRS R2,3
	LDI  R17,LOW(255)
;     542         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     543 		DataOut = 0x80;
	LDI  R17,LOW(128)
;     544         LedMode = 1;
	LDI  R30,LOW(1)
	RJMP _0x205
;     545         break;
;     546         case 1:
_0x33:
	CPI  R30,LOW(0x1)
	BRNE _0x36
;     547         DataOut = Maled[Display[4]];
	__GETB1MN _Display,4
	LDI  R31,0
	SUBI R30,LOW(-_Maled*2)
	SBCI R31,HIGH(-_Maled*2)
	LPM  R17,Z
;     548         if (fSecond) DataOut &=  SEGDP;
	SBRC R3,6
	ANDI R17,LOW(247)
;     549         if (!fVolume_AND) DataOut = 0xff;
	SBRS R2,2
	LDI  R17,LOW(255)
;     550         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     551 		DataOut = 0x80>>1;
	LDI  R17,LOW(64)
;     552         LedMode = 2;
	LDI  R30,LOW(2)
	RJMP _0x205
;     553         break;
;     554         case 2:
_0x36:
	CPI  R30,LOW(0x2)
	BRNE _0x39
;     555         DataOut = MaledInv[Display[5]];
	__GETB1MN _Display,5
	LDI  R31,0
	SUBI R30,LOW(-_MaledInv*2)
	SBCI R31,HIGH(-_MaledInv*2)
	LPM  R17,Z
;     556         if (!fVolume_AND) DataOut = 0xff;
	SBRS R2,2
	LDI  R17,LOW(255)
;     557         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     558 		DataOut = 0x80>>2;
	LDI  R17,LOW(32)
;     559         LedMode = 3;
	LDI  R30,LOW(3)
	RJMP _0x205
;     560         break;
;     561         case 3:
_0x39:
	CPI  R30,LOW(0x3)
	BRNE _0x3B
;     562         DataOut = Maled[Display[0]];
	LDS  R30,_Display
	LDI  R31,0
	SUBI R30,LOW(-_Maled*2)
	SBCI R31,HIGH(-_Maled*2)
	LPM  R17,Z
;     563         if (!fTreble_AND) DataOut = 0xff;
	SBRS R2,4
	LDI  R17,LOW(255)
;     564         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     565 		DataOut = 0x80>>3;
	LDI  R17,LOW(16)
;     566         LedMode = 4;
	LDI  R30,LOW(4)
	RJMP _0x205
;     567         break;
;     568         case 4:
_0x3B:
	CPI  R30,LOW(0x4)
	BRNE _0x3D
;     569         DataOut = MaledInv[Display[1]];
	__GETB1MN _Display,1
	LDI  R31,0
	SUBI R30,LOW(-_MaledInv*2)
	SBCI R31,HIGH(-_MaledInv*2)
	LPM  R17,Z
;     570         if (fSecond) DataOut &=  SEGDP_INV;
	SBRC R3,6
	ANDI R17,LOW(239)
;     571         if (!fTreble_AND) DataOut = 0xff;
	SBRS R2,4
	LDI  R17,LOW(255)
;     572         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     573 		DataOut = 0x80>>4;
	LDI  R17,LOW(8)
;     574         LedMode = 5;
	LDI  R30,LOW(5)
	RJMP _0x205
;     575         break;
;     576         case 5:
_0x3D:
	CPI  R30,LOW(0x5)
	BRNE _0x43
;     577         DataOut = Maled[Display[2]];
	__GETB1MN _Display,2
	LDI  R31,0
	SUBI R30,LOW(-_Maled*2)
	SBCI R31,HIGH(-_Maled*2)
	LPM  R17,Z
;     578 //if (fSecond) DataOut &=  SEGDP_INV;
;     579         if (fSecond) DataOut &=  SEGDP;
	SBRC R3,6
	ANDI R17,LOW(247)
;     580         if (!fBass_AND) DataOut = 0xff;
	SBRS R2,3
	LDI  R17,LOW(255)
;     581         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     582 		DataOut = 0x80>>5;
	LDI  R17,LOW(4)
;     583         LedMode = 0;
;     584         break;
;     585         default:
_0x43:
;     586         LedMode =0;
_0x206:
	LDI  R30,LOW(0)
_0x205:
	STS  _LedMode_S7,R30
;     587         }
;     588 
;     589 	if (fLedRed) DataOut |= 1;
	SBRC R3,7
	ORI  R17,LOW(1)
;     590  	if (fLedGreen) DataOut |= 2;
	SBRC R4,0
	ORI  R17,LOW(2)
;     591         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     592 // analogControl from bit7-2, loadreg from Bit1-0
;     593 		DataOut = ~AnalogControl;
	MOV  R30,R10
	COM  R30
	MOV  R17,R30
;     594 		DataOut &= 0xFC;
	ANDI R17,LOW(252)
;     595 		DataOut |= (Loadreg & 0x03);
	MOV  R30,R11
	ANDI R30,LOW(0x3)
	OR   R17,R30
;     596         ShiftData(DataOut);
	ST   -Y,R17
	RCALL _ShiftData
;     597 //        ShiftData((~AnalogControl) & (~0x03));
;     598         LATCH = 1;
	SBI  0x12,7
;     599         LATCH = 0;
	CBI  0x12,7
;     600 }
	LD   R17,Y+
	RET
;     601 
;     602 /////////////////////////////////////////////////////////////////
;     603 // description: chanel has 2 nibble:    chanel[7]: on_off data = 0: off, = 1 : on
;     604 //                                      chanel[4]: select output chanel: = 0: CHB, = 1: CHA
;     605 //                                      chanel[2:0]: chanel input select  from 1 to 8
;     606 //              on_off bit:         = 1: on the chanel to out, = 0 off the chanel.
;     607 
;     608 
;     609 /////////////////////////////////////////////////////////////////
;     610 /////////////////////////////////////////////////////////////////
;     611 void SendACK (void)
;     612 {
_SendACK:
;     613 	TX_EN = 1;
	SBI  0x12,2
;     614 	CRC = FixAdd;
	LDS  R30,_FixAdd
	STS  _CRC,R30
;     615 	CRC = CRC8_DATA[CRC];
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA*2)
	SBCI R31,HIGH(-_CRC8_DATA*2)
	LPM  R0,Z
	STS  _CRC,R0
;     616 	CRC ^= ACK;
	LDS  R26,_CRC
	LDI  R30,LOW(15)
	EOR  R30,R26
	STS  _CRC,R30
;     617 	CRC = CRC8_DATA[CRC];
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA*2)
	SBCI R31,HIGH(-_CRC8_DATA*2)
	LPM  R0,Z
	STS  _CRC,R0
;     618 	tx_rd_index = 1;
	LDI  R30,LOW(1)
	STS  _tx_rd_index,R30
;     619 	tx_counter = 2;
	LDI  R30,LOW(2)
	STS  _tx_counter,R30
;     620 	tx_buffer[0] = FixAdd;
	LDS  R30,_FixAdd
	STS  _tx_buffer,R30
;     621 	tx_buffer[1] = ACK;
	LDI  R30,LOW(15)
	__PUTB1MN _tx_buffer,1
;     622 	tx_buffer[2] = CRC;
	LDS  R30,_CRC
	__PUTB1MN _tx_buffer,2
;     623 	while (!fTranFinish);
_0x46:
	SBRS R4,1
	RJMP _0x46
;     624 	fTranFinish = 0;
	CLT
	BLD  R4,1
;     625 //	UCSRB &= ~1;              // TXB = 0
;     626 	UDR = tx_buffer[0];
	LDS  R30,_tx_buffer
	OUT  0xC,R30
;     627     Tx_TimeOut = 10;
	LDI  R30,LOW(10)
	STS  _Tx_TimeOut,R30
;     628 }
	RET
;     629 /////////////////////////////////////////////////////////////////
;     630 /////////////////////////////////////////////////////////////////
;     631 // send maximun TX_BUFFER_SIZE - 1 byte, the last byte is CRC
;     632 // Tx_counter is input
;     633 void SendBuffer (void)
;     634 {
_SendBuffer:
;     635 	TX_EN = 1;
	SBI  0x12,2
;     636 	CRC = 0;
	LDI  R30,LOW(0)
	STS  _CRC,R30
;     637 	for (tx_rd_index = 0;tx_rd_index < tx_counter;tx_rd_index++)
	STS  _tx_rd_index,R30
_0x4A:
	LDS  R30,_tx_counter
	LDS  R26,_tx_rd_index
	CP   R26,R30
	BRSH _0x4B
;     638 		{
;     639 		CRC ^= tx_buffer[tx_rd_index];
	LDS  R30,_tx_rd_index
	LDI  R31,0
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	LD   R30,Z
	LDS  R26,_CRC
	EOR  R30,R26
	STS  _CRC,R30
;     640 		CRC = CRC8_DATA[CRC];
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA*2)
	SBCI R31,HIGH(-_CRC8_DATA*2)
	LPM  R0,Z
	STS  _CRC,R0
;     641 		}
	LDS  R30,_tx_rd_index
	SUBI R30,-LOW(1)
	STS  _tx_rd_index,R30
	RJMP _0x4A
_0x4B:
;     642 	tx_buffer[tx_counter] = CRC;
	LDS  R30,_tx_counter
	LDI  R31,0
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	LDS  R26,_CRC
	STD  Z+0,R26
;     643 	tx_rd_index = 1;
	LDI  R30,LOW(1)
	STS  _tx_rd_index,R30
;     644 	while (!fTranFinish);
_0x4C:
	SBRS R4,1
	RJMP _0x4C
;     645 	fTranFinish = 0;
	CLT
	BLD  R4,1
;     646 //	UCSRB &= ~1;              // TXB = 0
;     647 	UDR = tx_buffer[0];		  // total byte to send = tx_counter = (data byte + CRC)
	LDS  R30,_tx_buffer
	OUT  0xC,R30
;     648     Tx_TimeOut = 10;
	LDI  R30,LOW(10)
	STS  _Tx_TimeOut,R30
;     649 }
	RET
;     650 /////////////////////////////////////////////////////////////////
;     651 /////////////////////////////////////////////////////////////////
;     652 unsigned char comp_time(const alarm_format ring_time)
;     653 {
;     654 	if ((currenttime.hour == ring_time.hour) || (currenttime.minute == ring_time.minute)) return 1;
;	ring_time -> Y+0
;     655 	else return 0;
;     656 
;     657 }
;     658 /////////////////////////////////////////////////////////////////
;     659 /////////////////////////////////////////////////////////////////
;     660 void main(void)
;     661 {
_main:
;     662 // Declare your local variables here
;     663  char temp,i,j;
;     664  unsigned int rSWdelay = 1;
;     665  char ADC_MC = 0, rSelectMode = 0, Config, Kount = 0;
;     666  int vAdcLight,vAdcVoice,vAdcRoom,vAdcAlum, temp_int;
;     667 
;     668  //char rDelay_blink = 0;
;     669  bit fBass_blink = 0,fTreble_blink = 0,fVolume_blink = 0, fTest = 1, fLightTest = 0;
;     670 
;     671 
;     672  char Volume_bk,Bass_bk,Treble_bk,Bell_Mc = 0,Alarm_delay, Bell_delay;
;     673  char Blink_Mc = 0, Blink_delay;
;     674 
;     675  char DelayN100ms = 1,rDelay100ms = 0, rDelay1s = 0, rDelay500ms = 0, Button_delay;
;     676  char AlarmByte[5];
;     677 
;     678  char AutolineDelay,Connectimeout,AutoLine_Mc = 0,oldAdcSW, ReadingLoop;
;     679 
;     680  char LimitMode;
;     681  char LimitVolHi;
;     682  char LimitVolLo;
;     683  char BellVolume;
;     684  char SwitchDelay = 20,SwitchDelay1 = 20;
;     685  char DispEqDelay = 10,EqMc = 0;
;     686  char Test = 0;
;     687  char SoundLevel;
;     688 
;     689 // Input/Output Ports initialization
;     690 // Port B initialization
;     691 // Func7=In Func6=In Func5=Out Func4=Out Func3=Out Func2=In Func1=In Func0=In
;     692 // State7=T State6=T State5=0 State4=0 State3=0 State2=0 State1=0 State0=0
;     693 PORTB=0x07;                 // = 1: pullup
	SBIW R28,46
	LDI  R24,45
	LDI  R26,LOW(1)
	LDI  R27,HIGH(1)
	LDI  R30,LOW(_0x53*2)
	LDI  R31,HIGH(_0x53*2)
	RCALL __INITLOCB
;	temp -> R17
;	i -> R16
;	j -> R19
;	rSWdelay -> R20,R21
;	ADC_MC -> R18
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(8)
	MOV  R15,R30
	LDI  R18,0
	LDI  R20,1
	LDI  R21,0
	LDI  R30,LOW(7)
	OUT  0x18,R30
;     694 DDRB=0x38;                  // = 0: IN
	LDI  R30,LOW(56)
	OUT  0x17,R30
;     695 
;     696 // Port C initialization
;     697 // Func6=In Func5=In Func4=In Func3=OUT Func2=In Func1=In Func0=In
;     698 // State6=T State5=P State4=0 State3=0 State2=0 State1=T State0=T
;     699 PORTC=0x10;	//
	LDI  R30,LOW(16)
	OUT  0x15,R30
;     700 DDRC=0x08;  // 0 = In
	LDI  R30,LOW(8)
	OUT  0x14,R30
;     701 
;     702 // Port D initialization
;     703 // Func7=Out Func6=Out Func5=Out Func4=Out Func3=In Func2=OUT Func1=Out Func0=In
;     704 // State7=0 State6=0 State5=0 State4=0 State3=P State2=P State1=0 State0=P
;     705 PORTD=0x09;
	LDI  R30,LOW(9)
	OUT  0x12,R30
;     706 DDRD=0xF6;
	LDI  R30,LOW(246)
	OUT  0x11,R30
;     707 
;     708 // Timer/Counter 0 initialization
;     709 // Clock source: System Clock
;     710 // Clock value: 12.000.000 kHz
;     711 TCCR0=0x01;
	LDI  R30,LOW(1)
	OUT  0x33,R30
;     712 TCNT0=0x00;
	LDI  R30,LOW(0)
	OUT  0x32,R30
;     713 
;     714 // Timer/Counter 1 initialization
;     715 // Clock source: System Clock
;     716 // Clock value: 1500.000 kHz
;     717 // Mode: Fast PWM top=00FFh
;     718 // OC1A output: Non-Inv.
;     719 // OC1B output: Non-Inv.
;     720 // Noise Canceler: Off
;     721 // Input Capture on Falling Edge
;     722 // Timer 1 Overflow Interrupt: Off
;     723 // Input Capture Interrupt: Off
;     724 // Compare A Match Interrupt: Off
;     725 // Compare B Match Interrupt: Off
;     726 /*
;     727 TCCR1A=0xA1;
;     728 TCCR1B=0x0A;
;     729 TCNT1H=0x00;
;     730 TCNT1L=0x00;
;     731 ICR1H=0x00;
;     732 ICR1L=0x00;
;     733 OCR1AH=0x00;
;     734 OCR1AL=0x00;
;     735 OCR1BH=0x00;
;     736 OCR1BL=0x00;
;     737   */
;     738 // Timer/Counter 2 initialization
;     739 // Clock source: System Clock
;     740 // Clock value: 1500.000 kHz
;     741 // Mode: CTC top=OCR2
;     742 // OC2 output: Disconnected
;     743 ASSR=0x00;
	OUT  0x22,R30
;     744 TCCR2=0x0A;
	LDI  R30,LOW(10)
	OUT  0x25,R30
;     745 TCNT2=0x00;
	LDI  R30,LOW(0)
	OUT  0x24,R30
;     746 OCR2=150-1;
	LDI  R30,LOW(149)
	OUT  0x23,R30
;     747 
;     748 // External Interrupt(s) initialization
;     749 // INT0: Off
;     750 // INT1: On
;     751 // INT1 Mode: Falling Edge
;     752 GICR|=0x80;
	IN   R30,0x3B
	ORI  R30,0x80
	OUT  0x3B,R30
;     753 MCUCR=0x08;
	LDI  R30,LOW(8)
	OUT  0x35,R30
;     754 GIFR=0x80;
	LDI  R30,LOW(128)
	OUT  0x3A,R30
;     755 
;     756 // Timer(s)/Counter(s) Interrupt(s) initialization
;     757 TIMSK=0x81;
	LDI  R30,LOW(129)
	OUT  0x39,R30
;     758 
;     759 // USART initialization
;     760 // Communication Parameters: 9 Data, 1 Stop, No Parity
;     761 // USART Receiver: On
;     762 // USART Transmitter: On
;     763 // USART Mode: Asynchronous
;     764 // USART Baud Rate: 19200
;     765 // UCSRA=0x00;
;     766 // UCSRB=0xDC;
;     767 // UCSRC=0x86;
;     768 // UBRRH=0x00;
;     769 // UBRRL=0x26;
;     770 
;     771 // USART initialization
;     772 // Communication Parameters: 8 Data, 1 Stop, No Parity
;     773 // USART Receiver: On
;     774 // USART Transmitter: On
;     775 // USART Mode: Asynchronous
;     776 // USART Baud Rate: 19200
;     777 UCSRA=0x00;
	LDI  R30,LOW(0)
	OUT  0xB,R30
;     778 UCSRB=0xD8;
	LDI  R30,LOW(216)
	OUT  0xA,R30
;     779 UCSRC=0x86;
	LDI  R30,LOW(134)
	OUT  0x20,R30
;     780 UBRRH=0x00;
	LDI  R30,LOW(0)
	OUT  0x20,R30
;     781 UBRRL=0x26;
	LDI  R30,LOW(38)
	OUT  0x9,R30
;     782 
;     783 
;     784 // Analog Comparator initialization
;     785 // Analog Comparator: Off
;     786 // Analog Comparator Input Capture by Timer/Counter 1: Off
;     787 ACSR=0x80;
	LDI  R30,LOW(128)
	OUT  0x8,R30
;     788 SFIOR=0x00;
	LDI  R30,LOW(0)
	OUT  0x30,R30
;     789 
;     790 // ADC initialization
;     791 // ADC Clock frequency: 750.000 kHz
;     792 // ADC Voltage Reference: AVCC pin
;     793 ADMUX=ADC_VREF_TYPE & 0xff;
	LDI  R30,LOW(64)
	OUT  0x7,R30
;     794 ADCSRA=0x84;
	LDI  R30,LOW(132)
	OUT  0x6,R30
;     795 
;     796 // Watchdog Timer initialization
;     797 // Watchdog Timer Prescaler: OSC/2048k
;     798 #pragma optsize-
;     799 WDTCR=0x1F;
	LDI  R30,LOW(31)
	OUT  0x21,R30
;     800 WDTCR=0x0F;
	LDI  R30,LOW(15)
	OUT  0x21,R30
;     801 #ifdef _OPTIMIZE_SIZE_
;     802 #pragma optsize+
;     803 #endif
;     804 
;     805 // Global enable interrupts
;     806 //#asm("sei")
;     807 
;     808 //off all the LED
;     809 fON_OFF = 0;
	CLT
	BLD  R3,1
;     810 outled();
	RCALL _outled
;     811 outled();
	RCALL _outled
;     812 outled();
	RCALL _outled
;     813 // init variable
;     814 //for (j=1;j<5;j++)
;     815 for (i=1;i<200;i++)
	LDI  R16,LOW(1)
_0x55:
	CPI  R16,200
	BRSH _0x56
;     816 	{
;     817 	delay_ms(3);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(3)
	LDI  R31,HIGH(3)
	ST   -Y,R31
	ST   -Y,R30
	RCALL _delay_ms
;     818 	#asm("WDR")
	WDR
;     819 	}
	SUBI R16,-1
	RJMP _0x55
_0x56:
;     820 
;     821 Volume_bk = eeVolume;
	LDI  R26,LOW(_eeVolume)
	LDI  R27,HIGH(_eeVolume)
	RCALL __EEPROMRDB
	STD  Y+32,R30
;     822 if (Volume_bk > 99)
	LDD  R26,Y+32
	CPI  R26,LOW(0x64)
	BRLO _0x57
;     823 	{
;     824 	Volume_bk = 56;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(56)
	STD  Y+32,R30
;     825 	eeVolume = 56;
	RJMP _0x207
;     826 	}
;     827 else if (Volume_bk == 0)
_0x57:
	LDD  R30,Y+32
	CPI  R30,0
	BRNE _0x59
;     828 	{
;     829 	Volume_bk = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	STD  Y+32,R30
;     830 	eeVolume = 1;
_0x207:
	LDI  R26,LOW(_eeVolume)
	LDI  R27,HIGH(_eeVolume)
	RCALL __EEPROMWRB
;     831 	}
;     832 
;     833 Bass_bk = eeBass;
_0x59:
	LDI  R26,LOW(_eeBass)
	LDI  R27,HIGH(_eeBass)
	RCALL __EEPROMRDB
	STD  Y+31,R30
;     834 if (Bass_bk > 99)
	LDD  R26,Y+31
	CPI  R26,LOW(0x64)
	BRLO _0x5A
;     835 	{
;     836 	 Bass_bk = 55;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(55)
	STD  Y+31,R30
;     837 	 eeBass = 55;
	LDI  R26,LOW(_eeBass)
	LDI  R27,HIGH(_eeBass)
	RCALL __EEPROMWRB
;     838 	}
;     839 if (Bass_bk == 0)
_0x5A:
	LDD  R30,Y+31
	CPI  R30,0
	BRNE _0x5B
;     840 	{
;     841 	 Bass_bk = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	STD  Y+31,R30
;     842 	 eeBass = 1;
	LDI  R26,LOW(_eeBass)
	LDI  R27,HIGH(_eeBass)
	RCALL __EEPROMWRB
;     843 	}
;     844 Treble_bk = eeTreble;
_0x5B:
	LDI  R26,LOW(_eeTreble)
	LDI  R27,HIGH(_eeTreble)
	RCALL __EEPROMRDB
	STD  Y+30,R30
;     845 if (Treble_bk > 99)
	LDD  R26,Y+30
	CPI  R26,LOW(0x64)
	BRLO _0x5C
;     846 	{
;     847 	 Treble_bk = 54;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(54)
	STD  Y+30,R30
;     848 	 eeTreble = 54;
	LDI  R26,LOW(_eeTreble)
	LDI  R27,HIGH(_eeTreble)
	RCALL __EEPROMWRB
;     849 	}
;     850 if (Treble_bk == 0)
_0x5C:
	LDD  R30,Y+30
	CPI  R30,0
	BRNE _0x5D
;     851 	{
;     852 	 Treble_bk = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	STD  Y+30,R30
;     853 	 eeTreble = 1;
	LDI  R26,LOW(_eeTreble)
	LDI  R27,HIGH(_eeTreble)
	RCALL __EEPROMWRB
;     854 	}
;     855 //for (i=1;i<10;i++)
;     856 //	{
;     857 //	if (eeFixAdd > MAXADDR)
;     858 //	}
;     859 FixAdd = 0xFF;
_0x5D:
	LDI  R30,LOW(255)
	STS  _FixAdd,R30
;     860 #asm("cli")
	cli
;     861 for (i=0;i<8;i++)
	LDI  R16,LOW(0)
_0x5F:
	CPI  R16,8
	BRSH _0x60
;     862     {
;     863     temp = eeFixAdd;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R26,LOW(_eeFixAdd)
	LDI  R27,HIGH(_eeFixAdd)
	RCALL __EEPROMRDB
	MOV  R17,R30
;     864     if ((temp == ~eeFixAdd_) && (temp > 0) && (temp < MAXADDR))
	LDI  R26,LOW(_eeFixAdd_)
	LDI  R27,HIGH(_eeFixAdd_)
	RCALL __EEPROMRDB
	COM  R30
	CP   R30,R17
	BRNE _0x62
	CPI  R17,1
	BRLO _0x62
	CPI  R17,180
	BRLO _0x63
_0x62:
	RJMP _0x61
_0x63:
;     865     	{
;     866     	FixAdd = temp;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	STS  _FixAdd,R17
;     867     	break;
	RJMP _0x60
;     868     	}
;     869 	delay_ms(3);
_0x61:
	LDI  R30,LOW(3)
	LDI  R31,HIGH(3)
	ST   -Y,R31
	ST   -Y,R30
	RCALL _delay_ms
;     870 	#asm("WDR")
	WDR
;     871 	}
	SUBI R16,-1
	RJMP _0x5F
_0x60:
;     872 
;     873 TX_EN = 0;
	CBI  0x12,2
;     874 
;     875 if (eeLimitMode > 4) eeLimitMode = 0;
	LDI  R26,LOW(_eeLimitMode)
	LDI  R27,HIGH(_eeLimitMode)
	RCALL __EEPROMRDB
	CPI  R30,LOW(0x5)
	BRLO _0x64
	LDI  R30,LOW(0)
	LDI  R26,LOW(_eeLimitMode)
	LDI  R27,HIGH(_eeLimitMode)
	RCALL __EEPROMWRB
;     876 LimitMode = eeLimitMode;
_0x64:
	LDI  R26,LOW(_eeLimitMode)
	LDI  R27,HIGH(_eeLimitMode)
	RCALL __EEPROMRDB
	STD  Y+9,R30
;     877 if (eeLimitVolHi > 99) eeLimitVolHi = 99;
	LDI  R26,LOW(_eeLimitVolHi)
	LDI  R27,HIGH(_eeLimitVolHi)
	RCALL __EEPROMRDB
	CPI  R30,LOW(0x64)
	BRLO _0x65
	LDI  R30,LOW(99)
	LDI  R26,LOW(_eeLimitVolHi)
	LDI  R27,HIGH(_eeLimitVolHi)
	RCALL __EEPROMWRB
;     878 LimitVolHi = eeLimitVolHi;
_0x65:
	LDI  R26,LOW(_eeLimitVolHi)
	LDI  R27,HIGH(_eeLimitVolHi)
	RCALL __EEPROMRDB
	STD  Y+8,R30
;     879 if (eeLimitVolLo > 99) eeLimitVolLo = 55;
	LDI  R26,LOW(_eeLimitVolLo)
	LDI  R27,HIGH(_eeLimitVolLo)
	RCALL __EEPROMRDB
	CPI  R30,LOW(0x64)
	BRLO _0x66
	LDI  R30,LOW(55)
	LDI  R26,LOW(_eeLimitVolLo)
	LDI  R27,HIGH(_eeLimitVolLo)
	RCALL __EEPROMWRB
;     880 LimitVolLo = eeLimitVolLo;
_0x66:
	LDI  R26,LOW(_eeLimitVolLo)
	LDI  R27,HIGH(_eeLimitVolLo)
	RCALL __EEPROMRDB
	STD  Y+7,R30
;     881 
;     882 Config = eeConfig;
	LDI  R26,LOW(_eeConfig)
	LDI  R27,HIGH(_eeConfig)
	RCALL __EEPROMRDB
	STD  Y+44,R30
;     883 if (Config & AUTO_ON_MIC)
	ANDI R30,LOW(0x10)
	BREQ _0x67
;     884     {
;     885 	fON_OFF = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R3,1
;     886 	AnalogControl = BITMICRO;
	LDI  R30,LOW(128)
	MOV  R10,R30
;     887     Volume_value = Volume_bk;
	LDD  R9,Y+32
;     888     Bass_value = Bass_bk;
	LDD  R6,Y+31
;     889     Treble_value = Treble_bk;
	LDD  R7,Y+30
;     890     }
;     891 else if (Config & AUTO_OFF)
	RJMP _0x68
_0x67:
	LDD  R30,Y+44
	ANDI R30,LOW(0x20)
	BREQ _0x69
;     892     {
;     893 	fON_OFF = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,1
;     894     status = 0;
	CLR  R8
;     895     Volume_value = 0;
	CLR  R9
;     896     Bass_value = 0;
	CLR  R6
;     897     Treble_value = 0;
	CLR  R7
;     898     }
;     899  else if (Config & AUTO_RESTORE)
	RJMP _0x6A
_0x69:
	LDD  R30,Y+44
	ANDI R30,LOW(0x40)
	BREQ _0x6B
;     900  	{
;     901  	 fON_OFF = eefON_OFF;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R26,LOW(_eefON_OFF)
	LDI  R27,HIGH(_eefON_OFF)
	RCALL __EEPROMRDB
	RCALL __BSTB1
	BLD  R3,1
;     902      Volume_value = Volume_bk;
	LDD  R9,Y+32
;     903      Bass_value = Bass_bk;
	LDD  R6,Y+31
;     904      Treble_value = Treble_bk;
	LDD  R7,Y+30
;     905 	 AnalogControl = eeAnalogControl;
	LDI  R26,LOW(_eeAnalogControl)
	LDI  R27,HIGH(_eeAnalogControl)
	RCALL __EEPROMRDB
	MOV  R10,R30
;     906  	}
;     907 BellVolume = eeBellVolume;
_0x6B:
_0x6A:
_0x68:
	LDI  R26,LOW(_eeBellVolume)
	LDI  R27,HIGH(_eeBellVolume)
	RCALL __EEPROMRDB
	STD  Y+6,R30
;     908 fAutoGain = eefAutoGain;
	LDI  R26,LOW(_eefAutoGain)
	LDI  R27,HIGH(_eefAutoGain)
	RCALL __EEPROMRDB
	RCALL __BSTB1
	BLD  R4,3
;     909 SoundLevel = eeSoundLevel;
	LDI  R26,LOW(_eeSoundLevel)
	LDI  R27,HIGH(_eeSoundLevel)
	RCALL __EEPROMRDB
	ST   Y,R30
;     910 #asm("sei")
	sei
;     911 /////////////////////////////////////////////////////////////////////////
;     912 // startup completely
;     913 /////////////////////////////////////////////////////////////////////////
;     914 while (1)
_0x6C:
;     915       {
;     916       // Place your code here
;     917       //////////////////////////////////////
;     918       // test IO port of system
;     919 
;     920       //////////////////////////////////////
;     921       // running realtime clock function
;     922       if (f10ms_ov)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SBRS R2,0
	RJMP _0x6F
;     923             {
;     924             f10ms_ov = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R2,0
;     925             //SendDelay --;
;     926          //   RxDelay --;
;     927             Bell_delay --;
	LDD  R30,Y+27
	SUBI R30,LOW(1)
	STD  Y+27,R30
;     928             Blink_delay --;
	LDD  R30,Y+25
	SUBI R30,LOW(1)
	STD  Y+25,R30
;     929             if (Tx_TimeOut != 0)
	LDS  R30,_Tx_TimeOut
	CPI  R30,0
	BREQ _0x70
;     930             	{
;     931             	Tx_TimeOut --;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SUBI R30,LOW(1)
	STS  _Tx_TimeOut,R30
;     932               	}
;     933             else
	RJMP _0x71
_0x70:
;     934             	{
;     935             	Tx_TimeOut = 4;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(4)
	STS  _Tx_TimeOut,R30
;     936             	 TX_EN = 0;
	CBI  0x12,2
;     937             	}
_0x71:
;     938 			if (bON_OFF == 0)
	SBIC 0x16,0
	RJMP _0x72
;     939 				{
;     940 				if (--SwitchDelay == 0)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+5
	SUBI R30,LOW(1)
	STD  Y+5,R30
	BRNE _0x73
;     941 					{
;     942 					fON_OFFsw = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R3,2
;     943 					}
;     944 				}
_0x73:
;     945 			else
	RJMP _0x74
_0x72:
;     946 				{
;     947 				 fON_OFFsw = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,2
;     948 				 SwitchDelay = 20;
	LDI  R30,LOW(20)
	STD  Y+5,R30
;     949 				}
_0x74:
;     950 			if (bSwitch == 0)
	SBIC 0x13,4
	RJMP _0x75
;     951 				{
;     952 				if (--SwitchDelay1 == 0)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+4
	SUBI R30,LOW(1)
	STD  Y+4,R30
	BRNE _0x76
;     953 					{
;     954 					fSwitch = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R4,6
;     955 					SwitchDelay1 = 10;
	LDI  R30,LOW(10)
	STD  Y+4,R30
;     956 					}
;     957 				}
_0x76:
;     958 			else
	RJMP _0x77
_0x75:
;     959 				{
;     960 				 fSwitch = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R4,6
;     961 				 SwitchDelay1 = 10;
	LDI  R30,LOW(10)
	STD  Y+4,R30
;     962 				}
_0x77:
;     963 
;     964             if (++rDelay100ms == 10)
	LDD  R26,Y+23
	SUBI R26,-LOW(1)
	STD  Y+23,R26
	CPI  R26,LOW(0xA)
	BRNE _0x78
;     965                 {
;     966                 if (++rDelay500ms == 5)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R26,Y+21
	SUBI R26,-LOW(1)
	STD  Y+21,R26
	CPI  R26,LOW(0x5)
	BRNE _0x79
;     967                 	{
;     968                 	 rDelay500ms = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+21,R30
;     969                 	 fSecond = !fSecond;
	LDI  R30,LOW(64)
	EOR  R3,R30
;     970                 	}
;     971                 AutolineDelay --;
_0x79:
	LDD  R30,Y+14
	SUBI R30,LOW(1)
	STD  Y+14,R30
;     972                 rDelay100ms = 0;     // delay 100ms section
	LDI  R30,LOW(0)
	STD  Y+23,R30
;     973                 DelayN100ms --;
	LDD  R30,Y+24
	SUBI R30,LOW(1)
	STD  Y+24,R30
;     974                 Alarm_delay --;
	LDD  R30,Y+28
	SUBI R30,LOW(1)
	STD  Y+28,R30
;     975 				fWriteAnalog = 1;
	SET
	BLD  R3,4
;     976                 if (Button_delay != 0) Button_delay --;
	LDD  R30,Y+20
	CPI  R30,0
	BREQ _0x7A
	SUBI R30,LOW(1)
	STD  Y+20,R30
;     977                 }
_0x7A:
;     978             if (++rDelay1s == 100)
_0x78:
	LDD  R26,Y+22
	SUBI R26,-LOW(1)
	STD  Y+22,R26
	CPI  R26,LOW(0x64)
	BREQ PC+2
	RJMP _0x7B
;     979                 {
;     980                 rDelay1s = 0;     // make 1s RTC  , delay 1s section
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+22,R30
;     981                 if (DispEqDelay != 0)
	LDD  R30,Y+3
	CPI  R30,0
	BREQ _0x7C
;     982                     {
;     983                 	if (--DispEqDelay==0)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SUBI R30,LOW(1)
	STD  Y+3,R30
	BRNE _0x7D
;     984                         {
;     985                         rSelectMode = 0;  // out off change (blink) mode
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+45,R30
;     986                         //rDelay_blink = 10;
;     987                         #asm("cli")
	cli
;     988                         eeBass = Bass_value;
	MOV  R30,R6
	LDI  R26,LOW(_eeBass)
	LDI  R27,HIGH(_eeBass)
	RCALL __EEPROMWRB
;     989                         eeTreble = Treble_value;
	MOV  R30,R7
	LDI  R26,LOW(_eeTreble)
	LDI  R27,HIGH(_eeTreble)
	RCALL __EEPROMWRB
;     990                         eeVolume = Volume_value;
	MOV  R30,R9
	LDI  R26,LOW(_eeVolume)
	LDI  R27,HIGH(_eeVolume)
	RCALL __EEPROMWRB
;     991                         #asm("sei")
	sei
;     992                         }
;     993                 	}
_0x7D:
;     994 				Connectimeout --;
_0x7C:
	LDD  R30,Y+13
	SUBI R30,LOW(1)
	STD  Y+13,R30
;     995                 if (++currenttime.second >= 60)
	__GETB1MN _currenttime,4
	SUBI R30,-LOW(1)
	__PUTB1MN _currenttime,4
	CPI  R30,LOW(0x3C)
	BRLO _0x7E
;     996                     {
;     997                        currenttime.second = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	__PUTB1MN _currenttime,4
;     998                     if (++currenttime.minute >= 60)
	__GETB1MN _currenttime,3
	SUBI R30,-LOW(1)
	__PUTB1MN _currenttime,3
	CPI  R30,LOW(0x3C)
	BRLO _0x7F
;     999                         {
;    1000                         currenttime.minute = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	__PUTB1MN _currenttime,3
;    1001                         if (++currenttime.hour >= 24)
	__GETB1MN _currenttime,2
	SUBI R30,-LOW(1)
	__PUTB1MN _currenttime,2
	CPI  R30,LOW(0x18)
	BRLO _0x80
;    1002                             {
;    1003                             currenttime.hour = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	__PUTB1MN _currenttime,2
;    1004                             if (++currenttime.day == 9)
	__GETB1MN _currenttime,1
	SUBI R30,-LOW(1)
	__PUTB1MN _currenttime,1
	CPI  R30,LOW(0x9)
	BRNE _0x81
;    1005                                 {
;    1006                                 currenttime.day = 2;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(2)
	__PUTB1MN _currenttime,1
;    1007                                 currenttime.week++;
	LDS  R30,_currenttime
	SUBI R30,-LOW(1)
	STS  _currenttime,R30
;    1008                                 }
;    1009                             }
_0x81:
;    1010                         }
_0x80:
;    1011                     }	// end of RTC time-day process
_0x7F:
;    1012                 }
_0x7E:
;    1013             } // end of 10ms condition (realtime clock)
_0x7B:
;    1014 
;    1015 /////////////////////////////////////////////////////////////
;    1016 // running flash segment LED
;    1017 /////////////////////////////////////////////////////////////
;    1018 
;    1019        if (rDelay1s < 20)
_0x6F:
	LDD  R26,Y+22
	CPI  R26,LOW(0x14)
	BRSH _0x82
;    1020             {
;    1021             if (fVolume_blink) fVolume_AND = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SBRS R15,2
	RJMP _0x83
	CLT
	BLD  R2,2
;    1022             if (fBass_blink) fBass_AND = 0;
_0x83:
	SBRS R15,0
	RJMP _0x84
	CLT
	BLD  R2,3
;    1023             if (fTreble_blink) fTreble_AND = 0;
_0x84:
	SBRS R15,1
	RJMP _0x85
	CLT
	BLD  R2,4
;    1024             }
_0x85:
;    1025        else if (rDelay1s < 50)
	RJMP _0x86
_0x82:
	LDD  R26,Y+22
	CPI  R26,LOW(0x32)
	BRLO _0x208
;    1026             {
;    1027             fVolume_AND = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
;    1028             fBass_AND = 1;
;    1029             fTreble_AND = 1;
;    1030             }
;    1031        else if (rDelay1s < 70)
	CPI  R26,LOW(0x46)
	BRSH _0x89
;    1032             {
;    1033             if (fVolume_blink) fVolume_AND = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SBRS R15,2
	RJMP _0x8A
	CLT
	BLD  R2,2
;    1034             if (fBass_blink) fBass_AND = 0;
_0x8A:
	SBRS R15,0
	RJMP _0x8B
	CLT
	BLD  R2,3
;    1035             if (fTreble_blink) fTreble_AND = 0;
_0x8B:
	SBRS R15,1
	RJMP _0x8C
	CLT
	BLD  R2,4
;    1036             }
_0x8C:
;    1037        else
	RJMP _0x8D
_0x89:
;    1038             {
;    1039             fVolume_AND = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
_0x208:
	SET
	BLD  R2,2
;    1040             fBass_AND = 1;
	BLD  R2,3
;    1041             fTreble_AND = 1;
	BLD  R2,4
;    1042             }
_0x8D:
_0x86:
;    1043 
;    1044 /////////////////////////////////////////////////////////////
;    1045 // System process, from read input to output LED
;    1046 /////////////////////////////////////////////////////////////
;    1047       ///////////////////////////////////////
;    1048       // FixAdd is calculated by:
;    1049       // Floor 0: from 1  to 20
;    1050       // Floor 1: from 21 to 40
;    1051       // Floor 2: from 41 to 60
;    1052       // Floor 3: from 61 to 80
;    1053       // Floor 4: from 81 to 100
;    1054       // Floor 5: from 101 to 120
;    1055       ///////////////////////////////////////
;    1056       ///////////////////////////////////////
;    1057 
;    1058       if (fSwitch)
	SBRS R4,6
	RJMP _0x8E
;    1059         {
;    1060         DispEqDelay = 5;       //reset to display Equalizer
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(5)
	STD  Y+3,R30
;    1061         if (Button_delay == 0)
	LDD  R30,Y+20
	CPI  R30,0
	BREQ PC+2
	RJMP _0x8F
;    1062         	{
;    1063     		Button_delay = 250;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(250)
	STD  Y+20,R30
;    1064         	if (LimitMode != 0)
	LDD  R30,Y+9
	CPI  R30,0
	BREQ _0x90
;    1065         		{
;    1066         		 LimitMode = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+9,R30
;    1067         		 break;
	RJMP _0x6E
;    1068         		}
;    1069         	if ((Volume_value < 6)  && (Treble_value < 10) && (Bass_value < 2))
_0x90:
	LDI  R30,LOW(6)
	CP   R9,R30
	BRSH _0x92
	LDI  R30,LOW(10)
	CP   R7,R30
	BRSH _0x92
	LDI  R30,LOW(2)
	CP   R6,R30
	BRLO _0x93
_0x92:
	RJMP _0x91
_0x93:
;    1070 //        	if ((Volume_value < 6))
;    1071         		{
;    1072         		 FixAdd = (Volume_value*20 + Bass_value*10 + Treble_value);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	MOV  R26,R9
	LDI  R30,LOW(20)
	MUL  R30,R26
	MOVW R30,R0
	MOV  R22,R30
	MOV  R26,R6
	LDI  R30,LOW(10)
	MUL  R30,R26
	MOVW R30,R0
	ADD  R30,R22
	ADD  R30,R7
	STS  _FixAdd,R30
;    1073                  #asm("cli")
	cli
;    1074                	 eeFixAdd = FixAdd;
	LDS  R30,_FixAdd
	LDI  R26,LOW(_eeFixAdd)
	LDI  R27,HIGH(_eeFixAdd)
	RCALL __EEPROMWRB
;    1075                	 eeFixAdd_ = ~FixAdd;
	COM  R30
	LDI  R26,LOW(_eeFixAdd_)
	LDI  R27,HIGH(_eeFixAdd_)
	RCALL __EEPROMWRB
;    1076                  #asm("sei")
	sei
;    1077         		 Volume_value = 5;
	LDI  R30,LOW(5)
	MOV  R9,R30
;    1078         		 Bass_value = 5;
	MOV  R6,R30
;    1079         		 Treble_value = 5;
	RJMP _0x209
;    1080         		}
;    1081         	else
_0x91:
;    1082         		{
;    1083         	    switch (Volume_value)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	MOV  R30,R9
;    1084         	    	{
;    1085         	    	case 6:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,LOW(0x6)
	BRNE _0x98
;    1086         			if ((Treble_value == 6) && (Bass_value == 6))
	LDI  R30,LOW(6)
	CP   R30,R7
	BRNE _0x9A
	CP   R30,R6
	BREQ _0x9B
_0x9A:
	RJMP _0x99
_0x9B:
;    1087         	    		{
;    1088                	 		Volume_value = FixAdd / 20;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDS  R26,_FixAdd
	LDI  R30,LOW(20)
	RCALL __DIVB21U
	MOV  R9,R30
;    1089                	 		Bass_value = FixAdd % 20;
	LDS  R26,_FixAdd
	LDI  R30,LOW(20)
	RCALL __MODB21U
	MOV  R6,R30
;    1090                	 		Treble_value = Bass_value % 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __MODB21U
	MOV  R7,R30
;    1091                	 		Bass_value = Bass_value / 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	MOV  R6,R30
;    1092         	    		}
;    1093         	  		else
	RJMP _0x9C
_0x99:
;    1094         	  			{
;    1095 	        		 	Volume_value = 2;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(2)
	MOV  R9,R30
;    1096     	    		 	Bass_value = 2;
	MOV  R6,R30
;    1097         			 	Treble_value = 2;
	MOV  R7,R30
;    1098         	  			}
_0x9C:
;    1099         	    	break;
	RJMP _0x97
;    1100         	    	case 7:                   //7-x-x
_0x98:
	CPI  R30,LOW(0x7)
	BRNE _0x9D
;    1101 	               	 Volume_value = Config;
	LDD  R9,Y+44
;    1102     	           	 Bass_value = AnalogControl;
	MOV  R6,R10
;    1103         	       	 Treble_value = LimitVolLo;
	LDD  R7,Y+7
;    1104         	    	break;
	RJMP _0x97
;    1105         	    	case 8:
_0x9D:
	CPI  R30,LOW(0x8)
	BREQ PC+2
	RJMP _0xBD
;    1106         			if (Bass_value == 8)
	LDI  R30,LOW(8)
	CP   R30,R6
	BRNE _0x9F
;    1107         	    		{
;    1108                			Volume_value = 5;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(5)
	MOV  R9,R30
;    1109                			Bass_value = 5;
	MOV  R6,R30
;    1110                			switch (Treble_value)
	MOV  R30,R7
;    1111                				{
;    1112                				case 0:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BREQ _0x20A
;    1113 			            	AnalogControl |= BITMICRO;
;    1114             				break;
;    1115             				case 1:
	CPI  R30,LOW(0x1)
	BRNE _0xA4
;    1116 			            	AnalogControl |= BITANALOG1;
	LDI  R30,LOW(8)
	RJMP _0x20B
;    1117             				break;
;    1118             				case 2:
_0xA4:
	CPI  R30,LOW(0x2)
	BRNE _0xA5
;    1119 			            	AnalogControl |= BITANALOG2;
	LDI  R30,LOW(16)
	RJMP _0x20B
;    1120             				break;
;    1121             				case 3:
_0xA5:
	CPI  R30,LOW(0x3)
	BRNE _0xA6
;    1122 			            	AnalogControl |= BITANALOG3;
	LDI  R30,LOW(64)
	RJMP _0x20B
;    1123             				break;
;    1124             				case 4:
_0xA6:
	CPI  R30,LOW(0x4)
	BRNE _0xA7
;    1125 			            	AnalogControl |= BITANALOG4;
	LDI  R30,LOW(32)
	RJMP _0x20B
;    1126             				break;
;    1127                				case 5:
_0xA7:
	CPI  R30,LOW(0x5)
	BRNE _0xA8
;    1128 			            	AnalogControl &= (~BITMICRO);
	LDI  R30,LOW(127)
	AND  R10,R30
;    1129             				break;
	RJMP _0xA2
;    1130             				case 6:
_0xA8:
	CPI  R30,LOW(0x6)
	BRNE _0xA9
;    1131 			            	AnalogControl &= (~BITANALOG1);
	LDI  R30,LOW(247)
	AND  R10,R30
;    1132             				break;
	RJMP _0xA2
;    1133             				case 7:
_0xA9:
	CPI  R30,LOW(0x7)
	BRNE _0xAA
;    1134 			            	AnalogControl &= (~BITANALOG2);
	LDI  R30,LOW(239)
	AND  R10,R30
;    1135             				break;
	RJMP _0xA2
;    1136             				case 8:
_0xAA:
	CPI  R30,LOW(0x8)
	BRNE _0xAB
;    1137 			            	AnalogControl &= (~BITANALOG3);
	LDI  R30,LOW(191)
	AND  R10,R30
;    1138             				break;
	RJMP _0xA2
;    1139             				case 9:
_0xAB:
	CPI  R30,LOW(0x9)
	BRNE _0xAD
;    1140 			            	AnalogControl &= (~BITANALOG4);
	LDI  R30,LOW(223)
	AND  R10,R30
;    1141             				break;
	RJMP _0xA2
;    1142             				default:
_0xAD:
;    1143 			            	AnalogControl |= BITMICRO;
_0x20A:
	LDI  R30,LOW(128)
_0x20B:
	OR   R10,R30
;    1144             				}
_0xA2:
;    1145             			eeAnalogControl = AnalogControl;
	MOV  R30,R10
	LDI  R26,LOW(_eeAnalogControl)
	LDI  R27,HIGH(_eeAnalogControl)
	RCALL __EEPROMWRB
;    1146             			Treble_value = 7;
	LDI  R30,LOW(7)
	RJMP _0x20C
;    1147           	    		}
;    1148         			else if (Bass_value == 7)
_0x9F:
	LDI  R30,LOW(7)
	CP   R30,R6
	BRNE _0xAF
;    1149         				{
;    1150                			Volume_value = 4;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(4)
	MOV  R9,R30
;    1151                			Bass_value = 4;
	MOV  R6,R30
;    1152         				fAutoGain = 1;
	SET
	BLD  R4,3
;    1153         				#asm("cli")
	cli
;    1154         				eefAutoGain = 1;
	LDI  R30,LOW(1)
	LDI  R26,LOW(_eefAutoGain)
	LDI  R27,HIGH(_eefAutoGain)
	RCALL __EEPROMWRB
;    1155         				#asm("sei")
	sei
;    1156         				}
;    1157         			else if (Bass_value == 6)
	RJMP _0xB0
_0xAF:
	LDI  R30,LOW(6)
	CP   R30,R6
	BRNE _0xB1
;    1158         				{
;    1159                			Volume_value = 3;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(3)
	MOV  R9,R30
;    1160                			Bass_value = 3;
	MOV  R6,R30
;    1161         				fAutoGain = 0;
	CLT
	BLD  R4,3
;    1162         				fLightTest = 0;
	BLD  R15,4
;    1163         				#asm("cli")
	cli
;    1164         				eefAutoGain = 0;
	LDI  R30,LOW(0)
	LDI  R26,LOW(_eefAutoGain)
	LDI  R27,HIGH(_eefAutoGain)
	RCALL __EEPROMWRB
;    1165         				#asm("sei")
	sei
;    1166         				}
;    1167         			else if (Bass_value == 5)
	RJMP _0xB2
_0xB1:
	LDI  R30,LOW(5)
	CP   R30,R6
	BRNE _0xB3
;    1168         				{
;    1169         				fLightTest = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R15,4
;    1170                			Volume_value = 3;
	LDI  R30,LOW(3)
	MOV  R9,R30
;    1171                			Bass_value = 3;
	MOV  R6,R30
;    1172                			Treble_value = 3;
	RJMP _0x20C
;    1173         				}
;    1174         			else if (Bass_value == 4)
_0xB3:
	LDI  R30,LOW(4)
	CP   R30,R6
	BREQ PC+2
	RJMP _0xB5
;    1175         				{
;    1176         				if (Treble_value == 0)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	TST  R7
	BRNE _0xB6
;    1177         					{
;    1178         					 Config &= (~AUTO_OFF);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+44
	ANDI R30,0xDF
	STD  Y+44,R30
;    1179         					 Config &= (~AUTO_RESTORE);
	ANDI R30,0xBF
	STD  Y+44,R30
;    1180         					 Config |= AUTO_ON_MIC;
	ORI  R30,0x10
	STD  Y+44,R30
;    1181         					 eeConfig = Config;
	LDI  R26,LOW(_eeConfig)
	LDI  R27,HIGH(_eeConfig)
	RCALL __EEPROMWRB
;    1182 	        				 Volume_value = 5;
	LDI  R30,LOW(5)
	MOV  R9,R30
;    1183     	    				 Bass_value = 5;
	MOV  R6,R30
;    1184         					 Treble_value = 7;
	LDI  R30,LOW(7)
	RJMP _0x20D
;    1185         					}
;    1186         				else if (Treble_value == 1)
_0xB6:
	LDI  R30,LOW(1)
	CP   R30,R7
	BRNE _0xB8
;    1187         					{
;    1188         					 Config |= (AUTO_OFF);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+44
	ORI  R30,0x20
	STD  Y+44,R30
;    1189         					 Config &= (~AUTO_RESTORE);
	ANDI R30,0xBF
	STD  Y+44,R30
;    1190         					 Config &= (~AUTO_ON_MIC);
	ANDI R30,0xEF
	STD  Y+44,R30
;    1191         					 eeConfig = Config;
	LDI  R26,LOW(_eeConfig)
	LDI  R27,HIGH(_eeConfig)
	RCALL __EEPROMWRB
;    1192 	        				 Volume_value = 5;
	LDI  R30,LOW(5)
	MOV  R9,R30
;    1193     	    				 Bass_value = 5;
	MOV  R6,R30
;    1194         					 Treble_value = 7;
	LDI  R30,LOW(7)
	RJMP _0x20D
;    1195         					}
;    1196         				else if (Treble_value == 2)
_0xB8:
	LDI  R30,LOW(2)
	CP   R30,R7
	BRNE _0xBA
;    1197         					{
;    1198         					 Config &= (~AUTO_OFF);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+44
	ANDI R30,0xDF
	STD  Y+44,R30
;    1199         					 Config |= (AUTO_RESTORE);
	ORI  R30,0x40
	STD  Y+44,R30
;    1200         					 Config &= (~AUTO_ON_MIC);
	ANDI R30,0xEF
	STD  Y+44,R30
;    1201         					 eeConfig = Config;
	LDI  R26,LOW(_eeConfig)
	LDI  R27,HIGH(_eeConfig)
	RCALL __EEPROMWRB
;    1202 	        				 Volume_value = 5;
	LDI  R30,LOW(5)
	MOV  R9,R30
;    1203     	    				 Bass_value = 5;
	MOV  R6,R30
;    1204         					 Treble_value = 7;
	LDI  R30,LOW(7)
	RJMP _0x20D
;    1205         					}
;    1206         				else
_0xBA:
;    1207         					{
;    1208 	        				 Volume_value = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	MOV  R9,R30
;    1209     	    				 Bass_value = 1;
	MOV  R6,R30
;    1210         					 Treble_value = 1;
_0x20D:
	MOV  R7,R30
;    1211         					}
;    1212         				}
;    1213         			else
	RJMP _0xBC
_0xB5:
;    1214         				{
;    1215         				 Volume_value = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	MOV  R9,R30
;    1216         				 Bass_value = 1;
	MOV  R6,R30
;    1217         				 Treble_value = 1;
_0x20C:
	MOV  R7,R30
;    1218         				}
_0xBC:
_0xB2:
_0xB0:
;    1219         	    	break;
	RJMP _0x97
;    1220         	    	default:
_0xBD:
;    1221         		 	Volume_value = 1;
	LDI  R30,LOW(1)
	MOV  R9,R30
;    1222         		 	Bass_value = 1;
	MOV  R6,R30
;    1223         		 	Treble_value = 1;
_0x209:
	MOV  R7,R30
;    1224         	    	}
_0x97:
;    1225         		}
;    1226 /*        	else if ((Volume_value == 7)  && (Treble_value == 7) && (Bass_value == 7))
;    1227         	    {
;    1228                	 Volume_value = Config;
;    1229                	 Bass_value = LimitVolHi;
;    1230                	 Treble_value = LimitVolLo;
;    1231         	    }*/
;    1232         	}
;    1233         }
_0x8F:
;    1234       else
	RJMP _0xBE
_0x8E:
;    1235        	{
;    1236        	 Button_delay  = 50;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(50)
	STD  Y+20,R30
;    1237        	}
_0xBE:
;    1238 
;    1239       if (fON_OFFsw)
	SBRS R3,2
	RJMP _0xBF
;    1240        	{
;    1241        	fON_OFFsw = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,2
;    1242        	fON_OFF = !fON_OFF;
	LDI  R30,LOW(2)
	EOR  R3,R30
;    1243         #asm("cli")
	cli
;    1244         eefON_OFF = fON_OFF;
	LDI  R30,0
	SBRC R3,1
	LDI  R30,1
	LDI  R26,LOW(_eefON_OFF)
	LDI  R27,HIGH(_eefON_OFF)
	RCALL __EEPROMWRB
;    1245         #asm("sei")
	sei
;    1246         if (fON_OFF) AnalogControl |= BITMICRO;
	SBRS R3,1
	RJMP _0xC0
	LDI  R30,LOW(128)
	OR   R10,R30
;    1247        	}
_0xC0:
;    1248 
;    1249       ///////////////////////////////////////
;    1250       ///////////////////////////////////////
;    1251 
;    1252 
;    1253 		if (fON_OFF)                   //system is ON
_0xBF:
	SBRS R3,1
	RJMP _0xC1
;    1254             {
;    1255             fLedGreen = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R4,0
;    1256             bONpower = 1;
	SBI  0x15,3
;    1257             //process for display time OR Equalizer
;    1258             fEncodeSedge = fEncodeSold &&(!EncodeS);	//falling edge
	SBRS R4,5
	RJMP _0xC2
	SBIC 0x16,1
	RJMP _0xC2
	LDI  R30,1
	RJMP _0xC3
_0xC2:
	LDI  R30,0
_0xC3:
	RCALL __BSTB1
	BLD  R4,4
;    1259             fEncodeSold = EncodeS;
	CLT
	SBIC 0x16,1
	SET
	BLD  R4,5
;    1260             if (fSwitch && (!fSwitchOld))
	SBRS R4,6
	RJMP _0xC5
	SBRS R4,7
	RJMP _0xC6
_0xC5:
	RJMP _0xC4
_0xC6:
;    1261              	{
;    1262              	 if (++EqMc == 4) EqMc = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R26,Y+2
	SUBI R26,-LOW(1)
	STD  Y+2,R26
	CPI  R26,LOW(0x4)
	BRNE _0xC7
	LDI  R30,LOW(0)
	STD  Y+2,R30
;    1263              	}
_0xC7:
;    1264             if (fEncodeSedge)			// falling edge of clock
_0xC4:
	SBRS R4,4
	RJMP _0xC8
;    1265             	{
;    1266             	DispEqDelay = 10;       //reset to display Equalizer
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(10)
	STD  Y+3,R30
;    1267             	}
;    1268             if (DispEqDelay == 0)		// display time
_0xC8:
	LDD  R30,Y+3
	CPI  R30,0
	BRNE _0xC9
;    1269             	{
;    1270            		 fVolume_blink = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R15,2
;    1271            		 fBass_blink = 0;
	BLD  R15,0
;    1272            		 fTreble_blink = 0;
	BLD  R15,1
;    1273 				 Display[0] = currenttime.second % 10;
	__GETB2MN _currenttime,4
	LDI  R30,LOW(10)
	RCALL __MODB21U
	STS  _Display,R30
;    1274      			 Display[1] = (currenttime.second) / 10;
	__GETB2MN _currenttime,4
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,1
;    1275      			 Display[2] = currenttime.minute % 10;
	__GETB2MN _currenttime,3
	LDI  R30,LOW(10)
	RCALL __MODB21U
	__PUTB1MN _Display,2
;    1276      			 Display[3] = currenttime.minute / 10;
	__GETB2MN _currenttime,3
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,3
;    1277      			 Display[4] = currenttime.hour % 10;
	__GETB2MN _currenttime,2
	LDI  R30,LOW(10)
	RCALL __MODB21U
	__PUTB1MN _Display,4
;    1278      			 Display[5] = currenttime.hour / 10;
	__GETB2MN _currenttime,2
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,5
;    1279      			 EqMc = 0;
	RJMP _0x20E
;    1280             	}
;    1281             else        				//Display Equalizer
_0xC9:
;    1282             	{
;    1283             	fSecond = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,6
;    1284 				 Display[0] = Treble_value % 10;
	MOV  R26,R7
	LDI  R30,LOW(10)
	RCALL __MODB21U
	STS  _Display,R30
;    1285      			 Display[1] = Treble_value / 10;
	MOV  R26,R7
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,1
;    1286      			 Display[2] = Bass_value % 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __MODB21U
	__PUTB1MN _Display,2
;    1287      			 Display[3] = Bass_value / 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,3
;    1288      			 Display[4] = Volume_value % 10;
	MOV  R26,R9
	LDI  R30,LOW(10)
	RCALL __MODB21U
	__PUTB1MN _Display,4
;    1289      			 Display[5] = Volume_value / 10;
	MOV  R26,R9
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,5
;    1290             	switch (EqMc)
	LDD  R30,Y+2
;    1291             		{
;    1292             		 case 0:     		//no change
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BRNE _0xCE
;    1293             		 fVolume_blink = 0;
	BLD  R15,2
;    1294             		 fBass_blink = 0;
	BLD  R15,0
;    1295             		 fTreble_blink = 0;
	BLD  R15,1
;    1296             		 if (fEncodeSedge) EqMc = 1;
	SBRS R4,4
	RJMP _0xCF
	LDI  R30,LOW(1)
	STD  Y+2,R30
;    1297             		 break;
_0xCF:
	RJMP _0xCD
;    1298             		 case 1:     		//volume
_0xCE:
	CPI  R30,LOW(0x1)
	BRNE _0xD0
;    1299             		 fVolume_blink = 1;
	SET
	BLD  R15,2
;    1300             		 fBass_blink = 0;
	CLT
	BLD  R15,0
;    1301             		 fTreble_blink = 0;
	BLD  R15,1
;    1302             		 if (LimitMode == 3) break;     // fix all value
	LDD  R26,Y+9
	CPI  R26,LOW(0x3)
	BRNE _0xD1
	RJMP _0xCD
;    1303             		 if (fEncodeSedge) Volume_value += (EncodeC ? -1 : 1);
_0xD1:
	SBRS R4,4
	RJMP _0xD2
	SBIS 0x16,2
	RJMP _0xD3
	LDI  R30,LOW(255)
	RJMP _0xD4
_0xD3:
	LDI  R30,LOW(1)
_0xD4:
	ADD  R9,R30
;    1304             		 if (Volume_value == 100) Volume_value = 99;
_0xD2:
	LDI  R30,LOW(100)
	CP   R30,R9
	BRNE _0xD6
	LDI  R30,LOW(99)
	MOV  R9,R30
;    1305             		 if (Volume_value > 100)  Volume_value = 0;
_0xD6:
	LDI  R30,LOW(100)
	CP   R30,R9
	BRSH _0xD7
	CLR  R9
;    1306            		     if (LimitMode == 1)	// limit volume at high level
_0xD7:
	LDD  R26,Y+9
	CPI  R26,LOW(0x1)
	BRNE _0xD8
;    1307       					{
;    1308       	 				if (Volume_value > LimitVolHi) Volume_value = LimitVolHi;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+8
	CP   R30,R9
	BRSH _0xD9
	LDD  R9,Y+8
;    1309       					}
_0xD9:
;    1310       			     else if (LimitMode == 2) // limit volume at high & Low level
	RJMP _0xDA
_0xD8:
	LDD  R26,Y+9
	CPI  R26,LOW(0x2)
	BRNE _0xDB
;    1311       					{
;    1312       	 				if (Volume_value > LimitVolHi) Volume_value = LimitVolHi;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+8
	CP   R30,R9
	BRSH _0xDC
	LDD  R9,Y+8
;    1313       	 				if (Volume_value < LimitVolLo) Volume_value = LimitVolLo;
_0xDC:
	LDD  R30,Y+7
	CP   R9,R30
	BRSH _0xDD
	LDD  R9,Y+7
;    1314       					}
_0xDD:
;    1315             		 break;
_0xDB:
_0xDA:
	RJMP _0xCD
;    1316             		 case 2:            // Bass
_0xD0:
	CPI  R30,LOW(0x2)
	BRNE _0xDE
;    1317             		 fVolume_blink = 0;
	CLT
	BLD  R15,2
;    1318             		 fBass_blink = 1;
	SET
	BLD  R15,0
;    1319             		 fTreble_blink = 0;
	CLT
	BLD  R15,1
;    1320             		 if ((LimitMode == 3) || (LimitMode == 4)) break; 	// fix all & eq
	LDD  R26,Y+9
	CPI  R26,LOW(0x3)
	BREQ _0xE0
	CPI  R26,LOW(0x4)
	BRNE _0xDF
_0xE0:
	RJMP _0xCD
;    1321             		 if (fEncodeSedge) Bass_value += (EncodeC ? -1 : 1);
_0xDF:
	SBRS R4,4
	RJMP _0xE2
	SBIS 0x16,2
	RJMP _0xE3
	LDI  R30,LOW(255)
	RJMP _0xE4
_0xE3:
	LDI  R30,LOW(1)
_0xE4:
	ADD  R6,R30
;    1322             		 if (Bass_value == 100) Bass_value = 99;
_0xE2:
	LDI  R30,LOW(100)
	CP   R30,R6
	BRNE _0xE6
	LDI  R30,LOW(99)
	MOV  R6,R30
;    1323             		 if (Bass_value > 100)  Bass_value = 0;
_0xE6:
	LDI  R30,LOW(100)
	CP   R30,R6
	BRSH _0xE7
	CLR  R6
;    1324             		 break;
_0xE7:
	RJMP _0xCD
;    1325             		 case 3:			// Trebles
_0xDE:
	CPI  R30,LOW(0x3)
	BRNE _0xF2
;    1326             		 fVolume_blink = 0;
	CLT
	BLD  R15,2
;    1327             		 fBass_blink = 0;
	BLD  R15,0
;    1328             		 fTreble_blink = 1;
	SET
	BLD  R15,1
;    1329             		 if ((LimitMode == 3) || (LimitMode == 4)) break;
	LDD  R26,Y+9
	CPI  R26,LOW(0x3)
	BREQ _0xEA
	CPI  R26,LOW(0x4)
	BRNE _0xE9
_0xEA:
	RJMP _0xCD
;    1330             		 if (fEncodeSedge) Treble_value += (EncodeC ? -1 : 1);
_0xE9:
	SBRS R4,4
	RJMP _0xEC
	SBIS 0x16,2
	RJMP _0xED
	LDI  R30,LOW(255)
	RJMP _0xEE
_0xED:
	LDI  R30,LOW(1)
_0xEE:
	ADD  R7,R30
;    1331             		 if (Treble_value == 100) Treble_value = 99;
_0xEC:
	LDI  R30,LOW(100)
	CP   R30,R7
	BRNE _0xF0
	LDI  R30,LOW(99)
	MOV  R7,R30
;    1332             		 if (Treble_value > 100)  Treble_value = 0;
_0xF0:
	LDI  R30,LOW(100)
	CP   R30,R7
	BRSH _0xF1
	CLR  R7
;    1333             		 break;
_0xF1:
	RJMP _0xCD
;    1334             		 default:
_0xF2:
;    1335             		 EqMc = 0;
_0x20E:
	LDI  R30,LOW(0)
	STD  Y+2,R30
;    1336             		}
_0xCD:
;    1337 
;    1338             	}
;    1339 //            if (fEncodeSedge && EncodeC) Kount --;      // counter clockwise rotation
;    1340 //            if (fEncodeSedge && (!EncodeC)) Kount ++;	// clockwise rotation
;    1341 
;    1342             }
;    1343   		else						// System is OFF
	RJMP _0xF3
_0xC1:
;    1344   			{
;    1345   			bONpower = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CBI  0x15,3
;    1346   			fLedGreen = 0; 			//turnoff the display
	CLT
	BLD  R4,0
;    1347             fVolume_AND = 0;
	BLD  R2,2
;    1348             fBass_AND = 0;
	BLD  R2,3
;    1349             fTreble_AND = 0;
	BLD  R2,4
;    1350             fSecond = 0;
	BLD  R3,6
;    1351 			// auto gain control test
;    1352 			if (fLightTest)
	SBRS R15,4
	RJMP _0xF4
;    1353 				{
;    1354 	 			temp = (char) (vAdcVoice >> 2);
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+39
	LDD  R31,Y+39+1
	RCALL __ASRW2
	MOV  R17,R30
;    1355 	 			Display[2] = temp / 100;
	MOV  R26,R17
	LDI  R30,LOW(100)
	RCALL __DIVB21U
	__PUTB1MN _Display,2
;    1356 	 			Display[1] = (temp % 100) / 10;
	MOV  R26,R17
	LDI  R30,LOW(100)
	RCALL __MODB21U
	MOV  R26,R30
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,1
;    1357 	 			Display[0] = temp % 10;
	MOV  R26,R17
	LDI  R30,LOW(10)
	RCALL __MODB21U
	STS  _Display,R30
;    1358 	 			temp = (char) (vAdcLight >> 2);
	LDD  R30,Y+41
	LDD  R31,Y+41+1
	RCALL __ASRW2
	MOV  R17,R30
;    1359 	 			Display[5] = temp / 100;
	MOV  R26,R17
	LDI  R30,LOW(100)
	RCALL __DIVB21U
	__PUTB1MN _Display,5
;    1360 	 			Display[4] = (temp % 100) / 10;
	MOV  R26,R17
	LDI  R30,LOW(100)
	RCALL __MODB21U
	MOV  R26,R30
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	__PUTB1MN _Display,4
;    1361 	 			Display[3] = temp % 10;
	MOV  R26,R17
	LDI  R30,LOW(10)
	RCALL __MODB21U
	__PUTB1MN _Display,3
;    1362             	fVolume_AND = 1;
	SET
	BLD  R2,2
;    1363             	fBass_AND = 1;
	BLD  R2,3
;    1364             	fTreble_AND = 1;
	BLD  R2,4
;    1365 				}
;    1366             }
_0xF4:
_0xF3:
;    1367 	fSwitchOld = fSwitch;
	BST  R4,6
	BLD  R4,7
;    1368 
;    1369       ///////////////////////////////////////
;    1370       ///////////////////////////////////////
;    1371 
;    1372       ///////////////////////////////////////
;    1373       // process Bell of PINGPONG sound
;    1374       ///////////////////////////////////////
;    1375 
;    1376        switch (Bell_Mc)
	LDD  R30,Y+29
;    1377          {
;    1378           case 0:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BRNE _0xF8
;    1379           fBell_en = 0;
	CLT
	BLD  R2,5
;    1380           break;
	RJMP _0xF7
;    1381           case 1:
_0xF8:
	CPI  R30,LOW(0x1)
	BRNE _0xF9
;    1382 //          if (fPingPong)
;    1383             {
;    1384             fBackup = fON_OFF;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	BST  R3,1
	BLD  R3,5
;    1385             fON_OFF = 1;
	SET
	BLD  R3,1
;    1386             fBell_en = 0;
	CLT
	BLD  R2,5
;    1387             Volume_bk = Volume_value;
	STD  Y+32,R9
;    1388             Bass_bk = Bass_value;
	STD  Y+31,R6
;    1389             Treble_bk = Treble_value;
	STD  Y+30,R7
;    1390             Volume_value = BellVolume;
	LDD  R9,Y+6
;    1391             Bass_value = 3;
	LDI  R30,LOW(3)
	MOV  R6,R30
;    1392             Treble_value = 3;
	MOV  R7,R30
;    1393 //            ChanelA = BELL2 | CHANEL_ON | CHANELA;
;    1394 //            analog_ctr(ChanelA);
;    1395 //            ChanelB = BELL2 | CHANEL_ON | CHANELB;
;    1396 //            analog_ctr(ChanelB);
;    1397 			AnalogControl |= BITBELL;
	LDI  R30,LOW(4)
	OR   R10,R30
;    1398             Bell_Mc = 2;
	LDI  R30,LOW(2)
	STD  Y+29,R30
;    1399             Bell_freq = 6;
	LDI  R30,LOW(6)
	STS  _Bell_freq,R30
;    1400             Bell_delay = 100;
	LDI  R30,LOW(100)
	STD  Y+27,R30
;    1401             }
;    1402           break;
	RJMP _0xF7
;    1403           case 2:       // end of init time
_0xF9:
	CPI  R30,LOW(0x2)
	BRNE _0xFA
;    1404           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0xFB
;    1405             {
;    1406              fBell_en = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R2,5
;    1407              Bell_delay = 50;
	LDI  R30,LOW(50)
	STD  Y+27,R30
;    1408              Bell_freq = 6;
	LDI  R30,LOW(6)
	STS  _Bell_freq,R30
;    1409              Bell_Mc = 3;
	LDI  R30,LOW(3)
	STD  Y+29,R30
;    1410             }
;    1411           break;
_0xFB:
	RJMP _0xF7
;    1412           case 3:       // end of ping
_0xFA:
	CPI  R30,LOW(0x3)
	BRNE _0xFC
;    1413           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0xFD
;    1414             {
;    1415              Bell_delay = 56;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(56)
	STD  Y+27,R30
;    1416              Bell_freq = 8;
	LDI  R30,LOW(8)
	STS  _Bell_freq,R30
;    1417              Bell_Mc = 4;
	LDI  R30,LOW(4)
	STD  Y+29,R30
;    1418             }
;    1419           break;
_0xFD:
	RJMP _0xF7
;    1420           case 4:          //end of pong
_0xFC:
	CPI  R30,LOW(0x4)
	BRNE _0xFE
;    1421           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0xFF
;    1422             {
;    1423              Bell_delay = 70;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(70)
	STD  Y+27,R30
;    1424              Bell_freq = 6;
	LDI  R30,LOW(6)
	STS  _Bell_freq,R30
;    1425              fBell_en = 0;
	CLT
	BLD  R2,5
;    1426              Bell_Mc = 5;
	LDI  R30,LOW(5)
	STD  Y+29,R30
;    1427             }
;    1428           break;
_0xFF:
	RJMP _0xF7
;    1429           case 5:          //end of stop time
_0xFE:
	CPI  R30,LOW(0x5)
	BRNE _0x100
;    1430           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0x101
;    1431             {
;    1432              Bell_delay = 50;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(50)
	STD  Y+27,R30
;    1433              Bell_freq = 6;
	LDI  R30,LOW(6)
	STS  _Bell_freq,R30
;    1434              fBell_en = 1;
	SET
	BLD  R2,5
;    1435              Bell_Mc = 6;
	STD  Y+29,R30
;    1436             }
;    1437           break;
_0x101:
	RJMP _0xF7
;    1438           case 6:          //end of ping
_0x100:
	CPI  R30,LOW(0x6)
	BRNE _0x102
;    1439           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0x103
;    1440             {
;    1441              Bell_delay = 56;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(56)
	STD  Y+27,R30
;    1442              Bell_freq = 8;
	LDI  R30,LOW(8)
	STS  _Bell_freq,R30
;    1443              Bell_Mc = 7;
	LDI  R30,LOW(7)
	STD  Y+29,R30
;    1444             }
;    1445           break;
_0x103:
	RJMP _0xF7
;    1446           case 7:          //end of pong
_0x102:
	CPI  R30,LOW(0x7)
	BRNE _0x104
;    1447           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0x105
;    1448             {
;    1449              Bell_delay = 50;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(50)
	STD  Y+27,R30
;    1450              Bell_freq = 6;
	LDI  R30,LOW(6)
	STS  _Bell_freq,R30
;    1451              fBell_en = 0;
	CLT
	BLD  R2,5
;    1452              fPingPong = 0;
	BLD  R2,6
;    1453              Bell_Mc = 8;
	LDI  R30,LOW(8)
	STD  Y+29,R30
;    1454             }
;    1455           break;
_0x105:
	RJMP _0xF7
;    1456           case 8:          //end of stop time
_0x104:
	CPI  R30,LOW(0x8)
	BRNE _0x108
;    1457           if (Bell_delay == 0)
	LDD  R30,Y+27
	CPI  R30,0
	BRNE _0x107
;    1458             {
;    1459             Bell_Mc = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+29,R30
;    1460             Volume_value = Volume_bk;
	LDD  R9,Y+32
;    1461             Bass_value = Bass_bk;
	LDD  R6,Y+31
;    1462             Treble_value = Treble_bk;
	LDD  R7,Y+30
;    1463 //            ChanelA = BELL2 | CHANEL_OFF | CHANELA;
;    1464 //            analog_ctr(ChanelA);
;    1465 //            ChanelB = BELL2 | CHANEL_OFF | CHANELB;
;    1466 //            analog_ctr(ChanelB);
;    1467 			AnalogControl &= (~BITBELL);
	LDI  R30,LOW(251)
	AND  R10,R30
;    1468             fON_OFF = fBackup;
	BST  R3,5
	BLD  R3,1
;    1469             }
;    1470           break;
_0x107:
	RJMP _0xF7
;    1471           default:
_0x108:
;    1472           Bell_Mc = 0;
	LDI  R30,LOW(0)
	STD  Y+29,R30
;    1473           }
_0xF7:
;    1474       ///////////////////////////////////////
;    1475       ///////////////////////////////////////
;    1476        switch (Blink_Mc)
	LDD  R30,Y+26
;    1477          {
;    1478           case 0:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BRNE _0x10C
;    1479           if (fBlinkRED)
	SBRS R3,0
	RJMP _0x10D
;    1480             {
;    1481             Blink_Mc = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	STD  Y+26,R30
;    1482             fBlinkRED = 0;
	CLT
	BLD  R3,0
;    1483             }
;    1484           break;
_0x10D:
	RJMP _0x10B
;    1485           case 1:
_0x10C:
	CPI  R30,LOW(0x1)
	BRNE _0x10E
;    1486           fLedRed = 1;
	SET
	BLD  R3,7
;    1487           Blink_Mc = 2;
	LDI  R30,LOW(2)
	STD  Y+26,R30
;    1488           Blink_delay = 10;    //200ms
	LDI  R30,LOW(10)
	STD  Y+25,R30
;    1489           break;
	RJMP _0x10B
;    1490           case 2:
_0x10E:
	CPI  R30,LOW(0x2)
	BRNE _0x10F
;    1491           if (Blink_delay == 0)
	LDD  R30,Y+25
	CPI  R30,0
	BRNE _0x110
;    1492             {
;    1493              fLedRed = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,7
;    1494              Blink_delay = 60;    //600ms
	LDI  R30,LOW(60)
	STD  Y+25,R30
;    1495              Blink_Mc = 3;
	LDI  R30,LOW(3)
	STD  Y+26,R30
;    1496             }
;    1497           break;
_0x110:
	RJMP _0x10B
;    1498           case 3:
_0x10F:
	CPI  R30,LOW(0x3)
	BRNE _0x113
;    1499           if (Blink_delay == 0)
	LDD  R30,Y+25
	CPI  R30,0
	BRNE _0x112
;    1500             {
;    1501              Blink_Mc = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STD  Y+26,R30
;    1502             }
;    1503           break;
_0x112:
	RJMP _0x10B
;    1504           default:
_0x113:
;    1505           Blink_Mc = 0;
	LDI  R30,LOW(0)
	STD  Y+26,R30
;    1506           }
_0x10B:
;    1507 
;    1508 ///////////////////////////////////////////////////////////
;    1509 ///////////////////////////////////////////////////////////
;    1510       ///////////////////////////////////////
;    1511       // process for RS485 Line select
;    1512       ///////////////////////////////////////
;    1513       //running auto line select mode if enable
;    1514       if (Config & CHANEL_AUTO)
	LDD  R30,Y+44
	ANDI R30,LOW(0x8)
	BRNE PC+2
	RJMP _0x114
;    1515 		{
;    1516 		if (fRx_receive) AutolineDelay = 100;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SBRS R5,0
	RJMP _0x115
	LDI  R30,LOW(100)
	STD  Y+14,R30
;    1517       	switch (AutoLine_Mc)
_0x115:
	LDD  R30,Y+12
;    1518       		{
;    1519       		 case 0:		// load backup value
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BRNE _0x119
;    1520       		 #asm("cli")
	cli
;    1521       		 temp = eeAutoline_bk;
	LDI  R26,LOW(_eeAutoline_bk)
	LDI  R27,HIGH(_eeAutoline_bk)
	RCALL __EEPROMRDB
	MOV  R17,R30
;    1522       		 #asm("sei")
	sei
;    1523       		 Loadreg |=  (CS_LINE1_ | CS_LINE2_);    //off 2 chanel
	LDI  R30,LOW(3)
	OR   R11,R30
;    1524       		 Loadreg &= (temp | (~CS_LINE12_));
	MOV  R30,R17
	ORI  R30,LOW(0xFC)
	AND  R11,R30
;    1525       		 AutolineDelay = 100;
	LDI  R30,LOW(100)
	STD  Y+14,R30
;    1526       		 AutoLine_Mc ++;
	LDD  R30,Y+12
	SUBI R30,-LOW(1)
	STD  Y+12,R30
;    1527       		 if (temp == ~CS_LINE12_)   // if 2 line connected, run Line 1
	CPI  R17,252
	BRNE _0x11A
;    1528       		 	{
;    1529       		 	 Loadreg |= CS_LINE1_;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(2)
	OR   R11,R30
;    1530       		 	 Loadreg &= ~CS_LINE2_;
	LDI  R30,LOW(254)
	AND  R11,R30
;    1531       		 	 }
;    1532       		 break;
_0x11A:
	RJMP _0x118
;    1533       		 case 1:
_0x119:
	CPI  R30,LOW(0x1)
	BRNE _0x11B
;    1534       		 if (AutolineDelay == 0)	// no network detected  run line1
	LDD  R30,Y+14
	CPI  R30,0
	BRNE _0x11C
;    1535       		 	{
;    1536       		 	 Loadreg |= CS_LINE2_;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(1)
	OR   R11,R30
;    1537       		 	 Loadreg &= ~CS_LINE1_;
	LDI  R30,LOW(253)
	AND  R11,R30
;    1538 	      		 AutolineDelay = 100;
	LDI  R30,LOW(100)
	STD  Y+14,R30
;    1539 	      		 AutoLine_Mc ++;
	LDD  R30,Y+12
	SUBI R30,-LOW(1)
	STD  Y+12,R30
;    1540 	      		 #asm("cli")
	cli
;    1541 	      		 eeAutoline_bk = ~CS_LINE1_;
	LDI  R30,LOW(253)
	LDI  R26,LOW(_eeAutoline_bk)
	LDI  R27,HIGH(_eeAutoline_bk)
	RCALL __EEPROMWRB
;    1542 	      		 #asm("sei")
	sei
;    1543       		 	}
;    1544       		 break;
_0x11C:
	RJMP _0x118
;    1545       		 case 2:
_0x11B:
	CPI  R30,LOW(0x2)
	BRNE _0x11F
;    1546       		 if (AutolineDelay == 0)	// no network detected  run line2
	LDD  R30,Y+14
	CPI  R30,0
	BRNE _0x11E
;    1547       		 	{
;    1548       		 	 Loadreg |= CS_LINE1_;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(2)
	OR   R11,R30
;    1549       		 	 Loadreg &= ~CS_LINE2_;
	LDI  R30,LOW(254)
	AND  R11,R30
;    1550 	      		 AutolineDelay = 100;
	LDI  R30,LOW(100)
	STD  Y+14,R30
;    1551 	      		 AutoLine_Mc = 1;
	LDI  R30,LOW(1)
	STD  Y+12,R30
;    1552 	      		 #asm("cli")
	cli
;    1553 	      		 eeAutoline_bk = ~CS_LINE2_;
	LDI  R30,LOW(254)
	LDI  R26,LOW(_eeAutoline_bk)
	LDI  R27,HIGH(_eeAutoline_bk)
	RCALL __EEPROMWRB
;    1554 	      		 #asm("sei")
	sei
;    1555       		 	}
;    1556       		 break;
_0x11E:
	RJMP _0x118
;    1557       		 default:
_0x11F:
;    1558       		 AutoLine_Mc = 0;
	LDI  R30,LOW(0)
	STD  Y+12,R30
;    1559       		}
_0x118:
;    1560       	}
;    1561   	else
	RJMP _0x120
_0x114:
;    1562   		{
;    1563   		 if ((Config & 0x03) == CHANEL_1)
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+44
	ANDI R30,LOW(0x3)
	CPI  R30,LOW(0x1)
	BREQ _0x20F
;    1564   		 	{
;    1565   		 	 Loadreg &= ~CS_LINE1_;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
;    1566   		 	 Loadreg |= CS_LINE2_;
;    1567   		 	}
;    1568   		 else if ((Config & 0x03) == CHANEL_2)
	LDD  R30,Y+44
	ANDI R30,LOW(0x3)
	CPI  R30,LOW(0x2)
	BRNE _0x123
;    1569   		 	{
;    1570   		 	 Loadreg &= ~CS_LINE2_;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(254)
	AND  R11,R30
;    1571   		 	 Loadreg |= CS_LINE1_;
	LDI  R30,LOW(2)
	RJMP _0x210
;    1572   		 	}
;    1573   		 else
_0x123:
;    1574   		 	{
;    1575   		 	 Loadreg &= ~CS_LINE1_;		// default using Line 1
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
_0x20F:
	LDI  R30,LOW(253)
	AND  R11,R30
;    1576   		 	 Loadreg |= CS_LINE2_;
	LDI  R30,LOW(1)
_0x210:
	OR   R11,R30
;    1577   		 	}
;    1578   		}
_0x120:
;    1579 	 Loadreg |= CS_LINE2_;
	LDI  R30,LOW(1)
	OR   R11,R30
;    1580 	 Loadreg &= ~CS_LINE1_;     // forced to line 1
	LDI  R30,LOW(253)
	AND  R11,R30
;    1581 
;    1582   ///////////////////////////////////////////////////////////////////////
;    1583 
;    1584   //           #asm ("cli")
;    1585         if (RxDelay == 0)                   // reset the Rx state machine
	LDS  R30,_RxDelay
	CPI  R30,0
	BRNE _0x125
;    1586             {
;    1587              Rx_Mc = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(0)
	STS  _Rx_Mc,R30
;    1588              RxDelay --;
	LDS  R30,_RxDelay
	SUBI R30,LOW(1)
	STS  _RxDelay,R30
;    1589    //          UCSRA |= BIT0;                 // turn on address mode
;    1590             }
;    1591    //          #asm ("sei")
;    1592         if (fRx_receive)
_0x125:
	SBRS R5,0
	RJMP _0x126
;    1593             {
;    1594              if ((rx_buffer_out[0] != 0xFF) && (Config & ACK_ENABLE)) fSendACK = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDS  R26,_rx_buffer_out
	CPI  R26,LOW(0xFF)
	BREQ _0x128
	LDD  R30,Y+44
	ANDI R30,LOW(0x80)
	BRNE _0x129
_0x128:
	RJMP _0x127
_0x129:
	SET
	BLD  R3,3
;    1595              fRx_receive = 0;               // process for RX data
_0x127:
	CLT
	BLD  R5,0
;    1596              i = rx_buffer_out[1];
	__GETBRMN 16,_rx_buffer_out,1
;    1597              fBlinkRED = 1;
	SET
	BLD  R3,0
;    1598              switch (i)  // process for command from master
	MOV  R30,R16
;    1599                     {
;    1600                      case vSYNC:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,0
	BRNE _0x12D
;    1601                      break;
	RJMP _0x12C
;    1602                      case vBELL_ON:
_0x12D:
	CPI  R30,LOW(0x1)
	BRNE _0x12E
;    1603                      Bell_Mc = 1;
	LDI  R30,LOW(1)
	STD  Y+29,R30
;    1604                      break;
	RJMP _0x12C
;    1605                      case vALARM_ON:
_0x12E:
	CPI  R30,LOW(0x2)
	BRNE _0x12F
;    1606                      break;
	RJMP _0x12C
;    1607                      case vALARM_HALF:
_0x12F:
	CPI  R30,LOW(0x9)
	BRNE _0x130
;    1608                      break;
	RJMP _0x12C
;    1609                      case vALARM_ONE:
_0x130:
	CPI  R30,LOW(0xB)
	BRNE _0x131
;    1610                      break;
	RJMP _0x12C
;    1611                      case vALARM_BELL_ON:
_0x131:
	CPI  R30,LOW(0x3)
	BRNE _0x132
;    1612                      Bell_Mc = 1;
	LDI  R30,LOW(1)
	STD  Y+29,R30
;    1613                      Alarm_Mc = 1;
	STS  _Alarm_Mc,R30
;    1614                      AlarmByte[0] = rx_buffer_out[2]; // ON time Nx100ms
	__GETB1MN _rx_buffer_out,2
	STD  Y+15,R30
;    1615                      AlarmByte[1] = rx_buffer_out[3]; // OFF time
	__GETB1MN _rx_buffer_out,3
	STD  Y+16,R30
;    1616                      AlarmByte[2] = rx_buffer_out[4]; // ON time
	__GETB1MN _rx_buffer_out,4
	STD  Y+17,R30
;    1617                      AlarmByte[3] = rx_buffer_out[5]; // OFF time
	__GETB1MN _rx_buffer_out,5
	STD  Y+18,R30
;    1618                      AlarmByte[4] = rx_buffer_out[6]; // OFF time
	__GETB1MN _rx_buffer_out,6
	STD  Y+19,R30
;    1619                      break;
	RJMP _0x12C
;    1620                      case vUPDATE_TIME:
_0x132:
	CPI  R30,LOW(0x4)
	BRNE _0x133
;    1621                      currenttime.second = rx_buffer_out[2]; // ON time Nx100ms
	__GETB1MN _rx_buffer_out,2
	__PUTB1MN _currenttime,4
;    1622                      currenttime.minute = rx_buffer_out[3]; // OFF time
	__GETB1MN _rx_buffer_out,3
	__PUTB1MN _currenttime,3
;    1623                      currenttime.hour   = rx_buffer_out[4]; // ON time
	__GETB1MN _rx_buffer_out,4
	__PUTB1MN _currenttime,2
;    1624                      currenttime.day    = rx_buffer_out[5]; // OFF time
	__GETB1MN _rx_buffer_out,5
	__PUTB1MN _currenttime,1
;    1625                      currenttime.week   = rx_buffer_out[6]; // OFF time
	__GETB1MN _rx_buffer_out,6
	STS  _currenttime,R30
;    1626                      break;
	RJMP _0x12C
;    1627                      case vUPDATE_ADDR:
_0x133:
	CPI  R30,LOW(0xC)
	BRNE _0x134
;    1628 //                      if (rx_buffer_out[0] == 0xFF) break;
;    1629 //                      FixAdd = rx_buffer_out[2];
;    1630 // 	      		     #asm("cli")
;    1631 //                    	 eeFixAdd = FixAdd;
;    1632 //                    	 eeFixAdd_ = ~FixAdd;
;    1633 // 	      		     #asm("sei")
;    1634                      break;
	RJMP _0x12C
;    1635                      case vCONFIG:    // config: auto power on Mode, line select mode, line select chanel
_0x134:
	CPI  R30,LOW(0xF)
	BRNE _0x135
;    1636 	      		     #asm("cli")
	cli
;    1637                      eeConfig = rx_buffer_out[2];  	// BIT7: fACK_en, BIT6: AutoMIC, BIT5: AUTO_OFF, BIT4: LAST state
	__GETB1MN _rx_buffer_out,2
	LDI  R26,LOW(_eeConfig)
	LDI  R27,HIGH(_eeConfig)
	RCALL __EEPROMWRB
;    1638                      Config = rx_buffer_out[2];        // Line select: BIT3 = 1: auto select, = 0: manual with BIT1:0- 2 relay control
	__GETB1MN _rx_buffer_out,2
	STD  Y+44,R30
;    1639                      BellVolume = rx_buffer_out[3];
	__GETB1MN _rx_buffer_out,3
	STD  Y+6,R30
;    1640                      eeBellVolume = rx_buffer_out[3];
	__GETB1MN _rx_buffer_out,3
	LDI  R26,LOW(_eeBellVolume)
	LDI  R27,HIGH(_eeBellVolume)
	RCALL __EEPROMWRB
;    1641 	      		     #asm("sei")
	sei
;    1642                      break;
	RJMP _0x12C
;    1643                      case vON_DEVICE:
_0x135:
	CPI  R30,LOW(0x6)
	BRNE _0x136
;    1644                      if (!fON_OFF)
	SBRC R3,1
	RJMP _0x137
;    1645                      fON_OFF = 1;
	SET
	BLD  R3,1
;    1646 	      		     #asm("cli")
_0x137:
	cli
;    1647                      eefON_OFF = 1;
	LDI  R30,LOW(1)
	LDI  R26,LOW(_eefON_OFF)
	LDI  R27,HIGH(_eefON_OFF)
	RCALL __EEPROMWRB
;    1648 	      		     #asm("sei")
	sei
;    1649                      break;
	RJMP _0x12C
;    1650                      case vOFF_DEVICE:
_0x136:
	CPI  R30,LOW(0x7)
	BRNE _0x138
;    1651                    	 fON_OFF = 0;
	CLT
	BLD  R3,1
;    1652 	      		     #asm("cli")
	cli
;    1653                    	 eefON_OFF = 0;
	LDI  R30,LOW(0)
	LDI  R26,LOW(_eefON_OFF)
	LDI  R27,HIGH(_eefON_OFF)
	RCALL __EEPROMWRB
;    1654 	      		     #asm("sei")
	sei
;    1655                      break;
	RJMP _0x12C
;    1656                      case vUPDATE_AMPLI:
_0x138:
	CPI  R30,LOW(0x8)
	BRNE _0x139
;    1657 	      		     #asm("cli")
	cli
;    1658 	      		     DispEqDelay = 10;
	LDI  R30,LOW(10)
	STD  Y+3,R30
;    1659                      eeVolume = rx_buffer_out[2];
	__GETB1MN _rx_buffer_out,2
	LDI  R26,LOW(_eeVolume)
	LDI  R27,HIGH(_eeVolume)
	RCALL __EEPROMWRB
;    1660                      eeBass = rx_buffer_out[3];
	__GETB1MN _rx_buffer_out,3
	LDI  R26,LOW(_eeBass)
	LDI  R27,HIGH(_eeBass)
	RCALL __EEPROMWRB
;    1661                      eeTreble = rx_buffer_out[4];
	__GETB1MN _rx_buffer_out,4
	LDI  R26,LOW(_eeTreble)
	LDI  R27,HIGH(_eeTreble)
	RCALL __EEPROMWRB
;    1662                      LimitMode = rx_buffer_out[5];     	// limit mode = 0: no limit, = 1: limit high, = 2 limit LO & HI
	__GETB1MN _rx_buffer_out,5
	STD  Y+9,R30
;    1663                      eeLimitMode = LimitMode;  			// = 3: FIX value ON ampli, = 4: FIX BASS-TREBLE only
	LDI  R26,LOW(_eeLimitMode)
	LDI  R27,HIGH(_eeLimitMode)
	RCALL __EEPROMWRB
;    1664                      LimitVolHi = rx_buffer_out[6];
	__GETB1MN _rx_buffer_out,6
	STD  Y+8,R30
;    1665                      eeLimitVolHi = LimitVolHi;
	LDI  R26,LOW(_eeLimitVolHi)
	LDI  R27,HIGH(_eeLimitVolHi)
	RCALL __EEPROMWRB
;    1666                      LimitVolLo = 0;
	LDI  R30,LOW(0)
	STD  Y+7,R30
;    1667                      eeLimitVolLo = LimitVolLo;
	LDI  R26,LOW(_eeLimitVolLo)
	LDI  R27,HIGH(_eeLimitVolLo)
	RCALL __EEPROMWRB
;    1668 	      		     #asm("sei")
	sei
;    1669                      if (fON_OFF)
	SBRS R3,1
	RJMP _0x13A
;    1670                      	{
;    1671                      	Volume_value = rx_buffer_out[2];
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	__GETBRMN 9,_rx_buffer_out,2
;    1672                      	Bass_value = rx_buffer_out[3];
	__GETBRMN 6,_rx_buffer_out,3
;    1673                      	Treble_value = rx_buffer_out[4];
	__GETBRMN 7,_rx_buffer_out,4
;    1674                      	}
;    1675                      Volume_bk = rx_buffer_out[2];
_0x13A:
	__GETB1MN _rx_buffer_out,2
	STD  Y+32,R30
;    1676                      Bass_bk   = rx_buffer_out[3];
	__GETB1MN _rx_buffer_out,3
	STD  Y+31,R30
;    1677                      Treble_bk = rx_buffer_out[4];
	__GETB1MN _rx_buffer_out,4
	STD  Y+30,R30
;    1678                      break;
	RJMP _0x12C
;    1679                      case vANALOG_SELECT:
_0x139:
	CPI  R30,LOW(0xA)
	BRNE _0x13B
;    1680                      AnalogControl = rx_buffer_out[2];
	__GETBRMN 10,_rx_buffer_out,2
;    1681 	      		     fAutoGain = rx_buffer_out[3];
	__GETB1MN _rx_buffer_out,3
	RCALL __BSTB1
	BLD  R4,3
;    1682 	      		     SoundLevel = rx_buffer_out[4];
	__GETB1MN _rx_buffer_out,4
	ST   Y,R30
;    1683 	      		     #asm("cli")
	cli
;    1684 	      		     eefAutoGain = fAutoGain;
	LDI  R30,0
	SBRC R4,3
	LDI  R30,1
	LDI  R26,LOW(_eefAutoGain)
	LDI  R27,HIGH(_eefAutoGain)
	RCALL __EEPROMWRB
;    1685                      eeAnalogControl = AnalogControl;
	MOV  R30,R10
	LDI  R26,LOW(_eeAnalogControl)
	LDI  R27,HIGH(_eeAnalogControl)
	RCALL __EEPROMWRB
;    1686                      eeSoundLevel = SoundLevel;
	LD   R30,Y
	LDI  R26,LOW(_eeSoundLevel)
	LDI  R27,HIGH(_eeSoundLevel)
	RCALL __EEPROMWRB
;    1687 	      		     #asm("sei")
	sei
;    1688 //                     ChanelA = rx_buffer_out[2];
;    1689 //                     ChanelB = rx_buffer_out[3];
;    1690 //                     eeChanelA = ChanelA;
;    1691 //                     eeChanelB = ChanelB;
;    1692                      break;
	RJMP _0x12C
;    1693                      case vREAD_STATUS:
_0x13B:
	CPI  R30,LOW(0xE)
	BRNE _0x13C
;    1694                      fSendACK = 0;
	CLT
	BLD  R3,3
;    1695                      if (rx_buffer_out[0] != 0xFF)      //return data
	LDS  R26,_rx_buffer_out
	CPI  R26,LOW(0xFF)
	BREQ _0x13D
;    1696                      	{
;    1697                      	 fSendStatus = 1;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	SET
	BLD  R4,2
;    1698                      // send tx_counter + 1 byte including CRC, no trailing address
;    1699                      	}
;    1700                      else
	RJMP _0x13E
_0x13D:
;    1701                      	{
;    1702                          DispEqDelay = 10;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(10)
	STD  Y+3,R30
;    1703                      	 Volume_value = FixAdd / 20;
	LDS  R26,_FixAdd
	LDI  R30,LOW(20)
	RCALL __DIVB21U
	MOV  R9,R30
;    1704                      	 Bass_value = FixAdd % 20;
	LDS  R26,_FixAdd
	LDI  R30,LOW(20)
	RCALL __MODB21U
	MOV  R6,R30
;    1705                      	 Treble_value = Bass_value % 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __MODB21U
	MOV  R7,R30
;    1706                      	 Bass_value = Bass_value / 10;
	MOV  R26,R6
	LDI  R30,LOW(10)
	RCALL __DIVB21U
	MOV  R6,R30
;    1707                      	}
_0x13E:
;    1708                      break;
	RJMP _0x12C
;    1709                      case vREAD_SENSOR:
_0x13C:
	CPI  R30,LOW(0x10)
	BRNE _0x140
;    1710                      status_AND = 0;
	LDI  R30,LOW(0)
	STS  _status_AND,R30
;    1711                      fSendSense = 1;
	SET
	BLD  R2,1
;    1712                      fSendACK = 0;
	CLT
	BLD  R3,3
;    1713                      break;
;    1714                      default:
_0x140:
;    1715                     }        // end of switch
_0x12C:
;    1716             }    // end of fRxReceive
;    1717 		if (!(fSendACK || fSendStatus || fSendSense)) SendDelay = 200;	// 20ms delay
_0x126:
	SBRC R3,3
	RJMP _0x142
	SBRC R4,2
	RJMP _0x142
	SBRS R2,1
	RJMP _0x143
_0x142:
	RJMP _0x141
_0x143:
	LDI  R30,LOW(200)
	STS  _SendDelay,R30
;    1718 		if (fSendSense  && (SendDelay == 0))
_0x141:
	SBRS R2,1
	RJMP _0x145
	LDS  R26,_SendDelay
	CPI  R26,LOW(0x0)
	BREQ _0x146
_0x145:
	RJMP _0x144
_0x146:
;    1719 			{
;    1720 			 fSendSense = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R2,1
;    1721          	 fSendStatus = 0;
	BLD  R4,2
;    1722         	 SendDelay = 200;
	LDI  R30,LOW(200)
	STS  _SendDelay,R30
;    1723              tx_buffer[0] = FixAdd;
	LDS  R30,_FixAdd
	STS  _tx_buffer,R30
;    1724              tx_buffer[1] = (unsigned char)(vAdcLight >> 8);
	LDD  R30,Y+41
	LDD  R31,Y+41+1
	RCALL __ASRW8
	__PUTB1MN _tx_buffer,1
;    1725              tx_buffer[2] = (unsigned char)(vAdcLight & 0xFF);
	LDD  R30,Y+41
	__PUTB1MN _tx_buffer,2
;    1726              tx_buffer[3] = (unsigned char)(vAdcVoice >> 8);
	LDD  R30,Y+39
	LDD  R31,Y+39+1
	RCALL __ASRW8
	__PUTB1MN _tx_buffer,3
;    1727              tx_buffer[4] = (unsigned char)(vAdcVoice & 0xFF);
	LDD  R30,Y+39
	__PUTB1MN _tx_buffer,4
;    1728              tx_buffer[5] = (unsigned char)(vAdcAlum >> 8);
	LDD  R30,Y+35
	LDD  R31,Y+35+1
	RCALL __ASRW8
	__PUTB1MN _tx_buffer,5
;    1729              tx_buffer[6] = (unsigned char)(vAdcAlum & 0xFF);
	LDD  R30,Y+35
	__PUTB1MN _tx_buffer,6
;    1730              tx_counter = 7;
	LDI  R30,LOW(7)
	STS  _tx_counter,R30
;    1731              SendBuffer();
	RCALL _SendBuffer
;    1732           	 status_AND = 0xFF;
	LDI  R30,LOW(255)
	STS  _status_AND,R30
;    1733 			}
;    1734   		if (fSendStatus && (SendDelay == 0))
_0x144:
	SBRS R4,2
	RJMP _0x148
	LDS  R26,_SendDelay
	CPI  R26,LOW(0x0)
	BREQ _0x149
_0x148:
	RJMP _0x147
_0x149:
;    1735          	{
;    1736         	 fSendACK = 0;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CLT
	BLD  R3,3
;    1737         	 SendDelay = 200;
	LDI  R30,LOW(200)
	STS  _SendDelay,R30
;    1738          	 fSendStatus = 0;
	BLD  R4,2
;    1739              tx_buffer[0] = FixAdd;
	LDS  R30,_FixAdd
	STS  _tx_buffer,R30
;    1740              if (fON_OFF)
	SBRS R3,1
	RJMP _0x14A
;    1741                 {
;    1742                 tx_buffer[2] = Volume_value;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	__PUTBMRN _tx_buffer,2,9
;    1743                 tx_buffer[3] = Bass_value;
	__PUTBMRN _tx_buffer,3,6
;    1744                 tx_buffer[4] = Treble_value;
	__PUTBMRN _tx_buffer,4,7
;    1745                 }
;    1746              else
	RJMP _0x14B
_0x14A:
;    1747              	{
;    1748                  tx_buffer[2] = Volume_bk;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDD  R30,Y+32
	__PUTB1MN _tx_buffer,2
;    1749                  tx_buffer[3] = Bass_bk;
	LDD  R30,Y+31
	__PUTB1MN _tx_buffer,3
;    1750                  tx_buffer[4] = Treble_bk;
	LDD  R30,Y+30
	__PUTB1MN _tx_buffer,4
;    1751               	}
_0x14B:
;    1752              tx_buffer[5] = Config;
	LDD  R30,Y+44
	__PUTB1MN _tx_buffer,5
;    1753              tx_buffer[1] = (LimitMode << 4);		// limit mode and fON_OFF
	LDD  R30,Y+9
	SWAP R30
	ANDI R30,0xF0
	__PUTB1MN _tx_buffer,1
;    1754              if (fON_OFF) tx_buffer[1] |= 0x80;
	SBRS R3,1
	RJMP _0x14C
	__POINTW1MN _tx_buffer,1
	MOVW R26,R30
	LD   R30,X
	ORI  R30,0x80
	ST   X,R30
;    1755              tx_buffer[6] = LimitVolHi;
_0x14C:
	LDD  R30,Y+8
	__PUTB1MN _tx_buffer,6
;    1756 //             tx_buffer[5] = ChanelA;
;    1757 //             tx_buffer[6] = ChanelB;
;    1758              tx_counter = 7; // send tx_counter + 1 byte
	LDI  R30,LOW(7)
	STS  _tx_counter,R30
;    1759              SendBuffer();
	RCALL _SendBuffer
;    1760 // buff(0): address of device
;    1761 // buff(1): bit7: fON_OFF, bit 6,5,4: limit mode, bit3:0 - none
;    1762 // buff(2): volume
;    1763 // buff(3): bass
;    1764 // buff(4): treble
;    1765 // buff(5): config BIT7: fACK_en, BIT6:4 auto startup option
;    1766 			//Line select: BIT3 = 1: auto select, = 0: manual with BIT1:0- 2 relay control
;    1767 // buff(6): limit vol Hi and Limit vol Lo
;    1768             }
;    1769 		if (fSendACK && (SendDelay == 0))
_0x147:
	SBRS R3,3
	RJMP _0x14E
	LDS  R26,_SendDelay
	CPI  R26,LOW(0x0)
	BREQ _0x14F
_0x14E:
	RJMP _0x14D
_0x14F:
;    1770         	{
;    1771         	SendDelay = 100;
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	LDI  R30,LOW(100)
	STS  _SendDelay,R30
;    1772         	fSendACK = 0;
	CLT
	BLD  R3,3
;    1773             SendACK();
	RCALL _SendACK
;    1774             }
;    1775       ///////////////////////////////////////
;    1776 ////////////////////////////////////////////////////////////
;    1777       /////////////////////////////////////
;    1778       /////////////////////////////////////
;    1779       #asm("WDR")
_0x14D:
	WDR
;    1780       outled();
	RCALL _outled
;    1781       switch (ADC_MC)
	MOV  R30,R18
;    1782         {
;    1783         case ADC_LIGHT:
;	rSelectMode -> Y+45
;	Config -> Y+44
;	Kount -> Y+43
;	vAdcLight -> Y+41
;	vAdcVoice -> Y+39
;	vAdcRoom -> Y+37
;	vAdcAlum -> Y+35
;	temp_int -> Y+33
;	fBass_blink -> R15.0
;	fTreble_blink -> R15.1
;	fVolume_blink -> R15.2
;	fTest -> R15.3
;	fLightTest -> R15.4
;	Volume_bk -> Y+32
;	Bass_bk -> Y+31
;	Treble_bk -> Y+30
;	Bell_Mc -> Y+29
;	Alarm_delay -> Y+28
;	Bell_delay -> Y+27
;	Blink_Mc -> Y+26
;	Blink_delay -> Y+25
;	DelayN100ms -> Y+24
;	rDelay100ms -> Y+23
;	rDelay1s -> Y+22
;	rDelay500ms -> Y+21
;	Button_delay -> Y+20
;	AlarmByte -> Y+15
;	AutolineDelay -> Y+14
;	Connectimeout -> Y+13
;	AutoLine_Mc -> Y+12
;	oldAdcSW -> Y+11
;	ReadingLoop -> Y+10
;	LimitMode -> Y+9
;	LimitVolHi -> Y+8
;	LimitVolLo -> Y+7
;	BellVolume -> Y+6
;	SwitchDelay -> Y+5
;	SwitchDelay1 -> Y+4
;	DispEqDelay -> Y+3
;	EqMc -> Y+2
;	Test -> Y+1
;	SoundLevel -> Y+0
	CPI  R30,LOW(0x5)
	BRNE _0x153
;    1784         vAdcLight = read_adc(ADC_MC);
	ST   -Y,R18
	RCALL _read_adc
	STD  Y+41,R30
	STD  Y+41+1,R31
;    1785         ADC_MC = ADC_VOICE;
	LDI  R18,LOW(2)
;    1786         break;
	RJMP _0x152
;    1787         case ADC_VOICE:
_0x153:
	CPI  R30,LOW(0x2)
	BRNE _0x154
;    1788         vAdcVoice = read_adc(ADC_MC);
	ST   -Y,R18
	RCALL _read_adc
	STD  Y+39,R30
	STD  Y+39+1,R31
;    1789 
;    1790         ADC_MC = ADC_ROOM;
	LDI  R18,LOW(1)
;    1791         break;
	RJMP _0x152
;    1792         case ADC_ROOM:
_0x154:
	CPI  R30,LOW(0x1)
	BRNE _0x155
;    1793         vAdcRoom = read_adc(ADC_MC);
	ST   -Y,R18
	RCALL _read_adc
	STD  Y+37,R30
	STD  Y+37+1,R31
;    1794 
;    1795         ADC_MC = ADC_ALUM;
	LDI  R18,LOW(0)
;    1796         break;
	RJMP _0x152
;    1797         case ADC_ALUM:
_0x155:
	CPI  R30,0
	BRNE _0x157
;    1798         vAdcAlum = read_adc(ADC_MC);
	ST   -Y,R18
	RCALL _read_adc
	STD  Y+35,R30
	STD  Y+35+1,R31
;    1799 
;    1800         ADC_MC = ADC_LIGHT;
;    1801         break;
;    1802         default:
_0x157:
;    1803         ADC_MC = ADC_LIGHT;
_0x211:
	LDI  R18,LOW(5)
;    1804         }
_0x152:
;    1805       };
	RJMP _0x6C
_0x6E:
;    1806 }
	ADIW R28,46
_0x158:
	RJMP _0x158

	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x80
	.EQU __sm_mask=0x70
	.EQU __sm_powerdown=0x20
	.EQU __sm_powersave=0x30
	.EQU __sm_standby=0x60
	.EQU __sm_ext_standby=0x70
	.EQU __sm_adc_noise_red=0x10
	.SET power_ctrl_reg=mcucr
	#endif

_isdigit:
	ldi  r30,1
	ld   r31,y+
	cpi  r31,'0'
	brlo __isdigit0
	cpi  r31,'9'+1
	brlo __isdigit1
__isdigit0:
	clr  r30
__isdigit1:
	ret

_isspace:
	ldi  r30,1
	ld   r31,y+
	cpi  r31,' '
	breq __isspace1
	cpi  r31,9
	brlo __isspace0
	cpi  r31,14
	brlo __isspace1
__isspace0:
	clr  r30
__isspace1:
	ret

_isxdigit:
	ldi  r30,1
	ld   r31,y+
	subi r31,0x30
	brcs __isxdigit0
	cpi  r31,10
	brcs __isxdigit1
	andi r31,0x5f
	subi r31,7
	cpi  r31,10
	brcs __isxdigit0
	cpi  r31,16
	brcs __isxdigit1
__isxdigit0:
	clr  r30
__isxdigit1:
	ret

_strlen:
	ld   r26,y+
	ld   r27,y+
	clr  r30
	clr  r31
__strlen0:
	ld   r22,x+
	tst  r22
	breq __strlen1
	adiw r30,1
	rjmp __strlen0
__strlen1:
	ret

_strlenf:
	clr  r26
	clr  r27
	ld   r30,y+
	ld   r31,y+
__strlenf0:
	lpm  r0,z+
	tst  r0
	breq __strlenf1
	adiw r26,1
	rjmp __strlenf0
__strlenf1:
	movw r30,r26
	ret

_delay_ms:
	ld   r30,y+
	ld   r31,y+
	adiw r30,0
	breq __delay_ms1
__delay_ms0:
	__DELAY_USW 0xBB8
	wdr
	sbiw r30,1
	brne __delay_ms0
__delay_ms1:
	ret

__ASRW2:
	ASR  R31
	ROR  R30
	ASR  R31
	ROR  R30
	RET

__ASRW8:
	MOV  R30,R31
	CLR  R31
	SBRC R30,7
	SER  R31
	RET

__DIVB21U:
	CLR  R0
	LDI  R25,8
__DIVB21U1:
	LSL  R26
	ROL  R0
	SUB  R0,R30
	BRCC __DIVB21U2
	ADD  R0,R30
	RJMP __DIVB21U3
__DIVB21U2:
	SBR  R26,1
__DIVB21U3:
	DEC  R25
	BRNE __DIVB21U1
	MOV  R30,R26
	MOV  R26,R0
	RET

__MODB21U:
	RCALL __DIVB21U
	MOV  R30,R26
	RET

__EEPROMRDB:
	SBIC EECR,EEWE
	RJMP __EEPROMRDB
	PUSH R31
	IN   R31,SREG
	CLI
	OUT  EEARL,R26
	OUT  EEARH,R27
	SBI  EECR,EERE
	IN   R30,EEDR
	OUT  SREG,R31
	POP  R31
	RET

__EEPROMWRB:
	SBIC EECR,EEWE
	RJMP __EEPROMWRB
	IN   R25,SREG
	CLI
	OUT  EEARL,R26
	OUT  EEARH,R27
	SBI  EECR,EERE
	IN   R24,EEDR
	CP   R30,R24
	BREQ __EEPROMWRB0
	OUT  EEDR,R30
	SBI  EECR,EEMWE
	SBI  EECR,EEWE
__EEPROMWRB0:
	OUT  SREG,R25
	RET

__BSTB1:
	CLT
	TST  R30
	BREQ PC+2
	SET
	RET

__SAVELOCR6:
	ST   -Y,R21
__SAVELOCR5:
	ST   -Y,R20
__SAVELOCR4:
	ST   -Y,R19
__SAVELOCR3:
	ST   -Y,R18
__SAVELOCR2:
	ST   -Y,R17
	ST   -Y,R16
	RET

__LOADLOCR6:
	LDD  R21,Y+5
__LOADLOCR5:
	LDD  R20,Y+4
__LOADLOCR4:
	LDD  R19,Y+3
__LOADLOCR3:
	LDD  R18,Y+2
__LOADLOCR2:
	LDD  R17,Y+1
	LD   R16,Y
	RET

__LOADLOCR2P:
	LD   R16,Y+
	LD   R17,Y+
	RET

__INITLOCB:
__INITLOCW:
	ADD R26,R28
	ADC R27,R29
__INITLOC0:
	LPM  R0,Z+
	ST   X+,R0
	DEC  R24
	BRNE __INITLOC0
	RET

;END OF CODE MARKER
__END_OF_CODE:
