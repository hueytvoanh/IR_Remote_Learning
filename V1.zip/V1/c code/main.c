#include <mega8.h>

//using internal clk source
// CLK SEL: 0100
// CLKOPT : 1 (unpro)

#include <delay.h>

#define Nop #asm("NOP")

const unsigned char     VERSION[8]={'F','O','R','T','E','K','1','F'};
const unsigned char     NAME[] = "PDE Gift";
const unsigned char     NAME_CMD[] = "AT+NAME=";
// version C: bo sung token          
// version E: chinh hien thi bao ACCU
#define vLOW_LEVEL  0x63
#define vMID_LEVEL  0x6d                    
#define I_LOW       0x1d
#define V_HIGH_CHR  0x75    //temp set
#define vSYNCKOUNT  100
#define vLOSTKOUNT  180     // 120 * vSYNCKOUNT * 100ms timeout = 30min


#define bStsLed     PORTD.4
#define bSts1Led    PORTC.4
#define bSts2Led    PORTC.3
#define bIr         PIND.3
#define bSw         PINC.2
#define bOpt        PINB.7

#define bLatch  PORTB.4
#define LEDSDA  PORTB.3
#define LEDSCL  PORTB.5

#define bBuzz   PORTB.0
//#define bCHR_PWM    PORTB.1
//#define bFAN_PWM    PORTB.2

#define BIT0    0x01
#define BIT1    0x02
#define BIT2    0x04
#define BIT3    0x08
#define BIT4    0x10
#define BIT5    0x20
#define BIT6    0x40
#define BIT7    0x80

#define SEGA	~(0x01 << 7)
#define SEGB	~(0x01 << 6)
#define SEGC	~(0x01 << 5)
#define SEGD	~(0x01 << 4)
#define SEGE	~(0x01 << 3)
#define SEGF	~(0x01 << 2)
#define SEGG	~(0x01 << 1)
#define SEGDP_INV	~(0x01 << 0)
                              
#define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
#define LEDNUM1		SEGB & SEGC
#define LEDNUM2		SEGA & SEGB &  SEGD & SEGE & SEGG
#define LEDNUM3		SEGA & SEGB & SEGC & SEGD & SEGG
#define LEDNUM4		SEGB & SEGC & SEGG & SEGF
#define LEDNUM5		SEGA & SEGC & SEGD & SEGG & SEGF
#define LEDNUM6		SEGA & SEGG & SEGC & SEGD & SEGE & SEGF
#define LEDNUM7		SEGA & SEGB & SEGC
#define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUM9		SEGA & SEGB & SEGC & SEGD & SEGF  & SEGG
#define LEDNUMA		SEGA & SEGB & SEGC & SEGE & SEGF  & SEGG
#define LEDNUMB		SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMC		SEGA & SEGD & SEGE & SEGF
#define LEDNUMD		SEGB & SEGC & SEGD & SEGE & SEGG
#define LEDNUME		SEGA & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMF		SEGA & SEGE & SEGF  & SEGG
#define LEDNUM16	SEGG
#define LEDNUM17	0xFF

const unsigned char   AUTO_FAN[28]={120,0,60,-2,30,-4,60,0,60,-2,60,0,60,2,60,0,60,-2,40,-4,60,0,60,-2,120,0,60,2}; //{TIME - SPEED}

const unsigned char   FAN[6]={BIT2,BIT1,BIT6,BIT5,BIT4,BIT3};
const unsigned char   TEST[8]={~BIT0,~BIT1,~BIT2,~BIT3,~BIT4,~BIT5,~BIT6,~BIT7};

const unsigned char   MaledInv[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,
								    LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};   

const char CRC8_DATA[256]={
        0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
		0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e,	0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
		0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0,	0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
		0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,	0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
		0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,	0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
		0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58,	0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
		0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6,	0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
		0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b,	0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
		0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f,	0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
		0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92,	0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
		0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c,	0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
		0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1,	0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
		0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49,	0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
		0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,	0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
		0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a,	0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
		0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7,	0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35};
                       
#ifndef RXB8
#define RXB8 1
#endif

#ifndef TXB8
#define TXB8 0
#endif

#ifndef UPE
#define UPE 2
#endif

#ifndef DOR
#define DOR 3
#endif

#ifndef FE
#define FE 4
#endif

#ifndef UDRE
#define UDRE 5
#endif

#ifndef RXC
#define RXC 7
#endif
#define vFRAMELEN 16

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<DOR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)

// USART Receiver buffer
#define MAXREMOTE   1
#define MAXBUTTON   6
        
// Declare your global variables here

char    IrMc = 0,SPIid = 0,SPI_L,SPI_H,SPI_data,Kount100us;
char    LedBuff[12],FanSet = 6,BatPWM = 1,LightValue,LightPWM;
char    BatT, IbatIn, IbatOut, Vbat, ADid = 0;
char    RandData,RandSend,CYCLE = 5,TestIr;
char    NameMc = 0,SyncKount,LostKount,IrByte,BitKount,IrTimeOut;
char    NameBuffer[10],IrData[8],RemoteData[2*MAXBUTTON*MAXREMOTE+1],StoreId;
char    BuzzFreq;

eeprom char RemoteRom[2*MAXBUTTON*MAXREMOTE+2];
int     IrInt;//,IrData16[2];

char    Rx_Mc = 0,tx_counter,RxDelay = 0;
char    setminute, sethour,Mode = 0;
bit     f1ms_ov,fDisplayMode,fON_OFF = 1,fChangeName = 0,fRxReceived = 0;
bit     fStsLed,fSound,fSwing,fTimerOn,fDisplayOn = 1,fSts1Led,fIrReceived;
// This flag is set on USART Receiver buffer overflow
bit     fRx_receive = 0,fTranFinish = 1,fProtect = 0, fSts2Led,fPulse,fRC5;
//bit     fSound;
		
#define DIG1    LedBuff[0]
#define DIG2    LedBuff[1]
#define DIG3    LedBuff[2]
#define DIG4    LedBuff[3]
#define DIG5    LedBuff[4]
#define DIG6    LedBuff[5]
#define DIG7    LedBuff[6]
#define Hbyte   LedBuff[7]
#define Kbyte   LedBuff[8]
#define Jbyte   LedBuff[9]
#define Lbyte   LedBuff[10]
#define Sbyte   LedBuff[11]

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
// External Interrupt 1 service routine

interrupt [EXT_INT1] void ext_int1_isr(void)
{
// Place your code here
 char temp,i;
//    fIntSts = !fIntSts;
//bStsLed = !bStsLed;
    temp = Kount100us;
    Kount100us = 0;       
    IrTimeOut = 20;
    switch (IrMc)
        {
        case 0:  
   //     fRC5 = 0;
        IrMc = 1;
        break;
        case 1:        
        if ((temp > 70) && (temp < 170)) // start bit condition, NEC code
            {
            BitKount = 0;
            IrMc = 2;  
            IrByte = 0;
//fStsLed = 1;        
            } 
        else if ((temp > 10) && (temp < 23))   //change config to receive toggle bit
            {   
            MCUCR=(0<<ISC11) | (1<<ISC10) | (0<<ISC01) | (0<<ISC00);    //any change 
            BitKount = 0;
            IrMc = 30; //senko remote format     
//            IrMc = 10;  // RC5 reading
 //           fPulse = 1;  
            IrInt = 0;
            }  
        else 
            {
            IrMc = 0;
// TestIr = temp/10;
            }
        break;             
        case 2:           //reading full byte 1 (address)
        if ((temp > 28) || (temp < 8))    
            {
            IrMc = 0;   //invalid bit
            }                        
        else
            {     
            IrByte >>= 1;  
            if (temp > 17) IrByte |= 0x80;
            if (++BitKount == 8)
                {
                IrData[0] = IrByte;
                BitKount = 0;
                IrByte = 0;
                IrMc = 3;
                }
            }
        break;
        case 3:           //reading full byte 2 (address_)  
        if ((temp > 28) || (temp < 8))    
            {
            IrMc = 0;   //invalid bit
            }                        
        else
            {     
            IrByte >>= 1;  
            if (temp > 17) IrByte |= 0x80;
            if (++BitKount == 8)
                {
                IrData[1] = IrByte;
                BitKount = 0;
                IrByte = 0;
                IrMc = 4;
               }
            }
        break;          
        case 4:           //reading full byte 3 (data)
        if ((temp > 28) || (temp < 8))    
            {
            IrMc = 0;   //invalid bit
            }                        
        else
            {     
            IrByte >>= 1;  
            if (temp > 17) IrByte |= 0x80;
            if (++BitKount == 8)
                {
                IrData[2] = IrByte;
                BitKount = 0;
                IrByte = 0;
                IrMc = 5;
               }
            }
        break;  
        case 5:           //reading full byte 4 (data_)
        if ((temp > 28) || (temp < 8))    
            {
            IrMc = 0;   //invalid bit
            }                        
        else
            {     
            IrByte >>= 1;  
            if (temp > 17) IrByte |= 0x80;
            if (++BitKount == 8)
                {
                IrData[3] = IrByte;         
//                fStsLed = 0;
//                for (i=0;i<4;i++)
//                    {       
//                    if (IrData[i+4] != IrData[i]) fStsLed = 1;
//                    IrData[i+4] = IrData[i];
//                    }
                if ((IrData[0] ^ IrData[1] == 0xFF) && (IrData[2] ^ IrData[3] == 0xFF)) 
                    {
                    //fStsLed = 1;
                    fIrReceived = 1;
                    IrData[1] = IrData[2];   
                    fRC5 = 0;
                    }
                BitKount = 0;
                IrByte = 0;
                IrMc = 0;    
                }
            }
        break;
        case 10:             //mid1 state     
            if ((temp > 4) && (temp < 15))  //short P
                {
                IrMc = 11;  // start1 state  
                fPulse = 0; 
                BitKount ++;
                } 
            else if ((temp >= 15) && (temp < 23))  // long P
                {
                IrMc = 12;  // Mid0 state
                BitKount ++;
                fPulse = 0;
                } 
        break;             
        case 11:             //start1 state
        if ((temp > 4) && (temp < 13))   // short S
            {
            fPulse = 1;
            BitKount++;    //emit 1
            IrMc =  10;
            }
        break;             
        case 12:        // Mid 0
        if ((temp > 4) && (temp < 13))   // short S
            {
            fPulse = 1;
            //BitKount++;    //emit 1
            IrMc =  13;
            }   
        else if ((temp > 13) && (temp < 23))   // long S
            {
            BitKount ++;    // emit 1
            IrMc = 10;  // to Mid1 state 
            fPulse = 1;                
            } 
        break;
        case 13:   // start0
        if ((temp > 4) && (temp < 13))   // short P
            {
            fPulse = 0;
            BitKount++;    //emit 0
            IrMc =  12;
            }     
        break; 
        case 20:   
        fRC5 = 1;   
        IrTimeOut = 8;  //8ms for stop reading
        if (BitKount < 20)
            {                          
            BitKount ++;
            }
        else
            {
            IrMc = 255;
            }
        break;
/////////////////////////////////////////////////        
        case 30:     // read the pulse
        fRC5 = 1;   
        IrTimeOut = 5;  //8ms for stop reading      
        if (temp > 3 && temp < 15)  //valid signal  
            {
            IrInt <<= 1;
            if (temp > 8) IrInt |= 1;  // bit 1  
            BitKount ++;
            if (BitKount < 11)
                {         
                IrMc = 31;  // bypass next Space
                }
            else
                {
              //  if (IrData16[0] != IrInt) fStsLed = 1;   
              //  IrData16[0] = IrInt;
                fIrReceived = 1;         
                fRC5 = 1;
                IrData[0] = (IrInt & 0xFF00)>>8;
                IrData[1] = (IrInt & 0x00ff);
             //   IrData[2] = 0;
             //   IrData[3] = 0;
                MCUCR = (1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);    //falling adge
                IrMc = 0;
                }
            }
        else
            {
        //    IrMc = 255; // = 0 as normal
            }
        break;
        case 31:     // read the space, do nothing
   //     fRC5 = 1;   
        IrTimeOut = 5;  //8ms for stop reading      
        IrMc = 30;
        break;  

        case 255:   // receiver halted
        break;
        }
 
 //   bStsLed = !bStsLed;
}
  
// This flag is set on USART Receiver buffer overflow
//bit rx_buffer_overflow;

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

// USART Receiver buffer

#define RX_BUFFER_SIZE 20
char rx_buffer[RX_BUFFER_SIZE];
char rx_buffer_out[RX_BUFFER_SIZE];

#if RX_BUFFER_SIZE<256
unsigned char rx_wr_index,rx_rd_index;//,rx_counter;
#else
unsigned int rx_wr_index,rx_rd_index;//,rx_counter;
#endif


/////////////////////////////////////////////////////
/////////////////////////////////////////////////////

// Data frame format for network                                                   
// using fix size data frame: 
// Header: | Slave address or 0xFF | command | data bytes | CRC (include command) |
//size of frame = RX_BUFFER_SIZE including address, command, data and CRC bytes

/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
// USART Receiver interrupt service routine
interrupt [USART_RXC] void usart_rx_isr(void)
{
char status1,data;
status1=UCSRA;
data=UDR;                               

if ((status1 & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
{
switch (Rx_Mc)   
    {    
    case 0:
        {
         rx_buffer[0]=data;   //store number of byte  
         rx_wr_index=1;
         Rx_Mc = 1;   
         RxDelay = 40;
        }
    break;
    case 1:         // receiving data frame
    rx_buffer[rx_wr_index]=data;                                         
    RxDelay = 40;     
    ++rx_wr_index;
    if ((rx_wr_index == RX_BUFFER_SIZE) ||(rx_wr_index == rx_buffer[0]))
       {                                
            {
            fRx_receive = 1;
            for (rx_wr_index=0;rx_wr_index<RX_BUFFER_SIZE;rx_wr_index++)      //double buffer purpose
                {
                rx_buffer_out[rx_wr_index] = rx_buffer[rx_wr_index];
                } 
            }
       Rx_Mc = 0;
       };
    break; 
    default:
    Rx_Mc = 0; 
    }
}
}

#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
#pragma used-
#endif

// USART Transmitter buffer
#define TX_BUFFER_SIZE 50
char tx_buffer[TX_BUFFER_SIZE];

#if TX_BUFFER_SIZE<256
unsigned char tx_wr_index,tx_rd_index,tx_counter;
#else
unsigned int tx_wr_index,tx_rd_index,tx_counter;
#endif

// USART Transmitter interrupt service routine
interrupt [USART_TXC] void usart_tx_isr(void)
{
if (tx_counter != 0)
   {      
 //  fStsLed = 1;  

   --tx_counter;
   UDR=tx_buffer[tx_rd_index];
//   Tx_TimeOut = 10;
   if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index=0;
   }  
else 
   {          
 //   fStsLed = 0;
	fTranFinish = 1;
   }
}


#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#pragma used+

#pragma used-
#endif

// Standard Input/Output functions
//#include <stdio.h>

// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
// Reinitialize Timer 0 value
TCNT0=-125-2;     // 1ms interrupt
// Place your code here
    f1ms_ov = 1;   
    if (--IrTimeOut == 0)  //80ms timeout
        {        
        MCUCR=(1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);    //falling adge
        IrMc = 0;            
        }
}

// Timer2 output compare interrupt service routine
interrupt [TIM2_COMP] void timer2_comp_isr(void)
{
// Place your code here
    Kount100us ++;          
    if (fSound)
        {
        if (++BuzzFreq == 4)
            {
            BuzzFreq = 0;
            bBuzz = !bBuzz;
            }
        }  
    else
        {
        bBuzz = 0;
        BuzzFreq = 0;
        }
//    bBuzz
  //  bStsLed = !bStsLed;
}

//#define ADC_VREF_TYPE 0xE0
#define ADC_VREF_TYPE 0x60

// Read the 8 most significant bits
// of the AD conversion result
unsigned char read_adc(unsigned char adc_input)
{
ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;
return ADCH;
}
//////////////////////////////////////////////////////////////
void ADC()
{
    switch (ADid)
    {
    case 0:
       IbatIn = read_adc(0);
       ADid ++;
    break;     
    case 1:
       IbatOut = read_adc(7);
       ADid ++;
    break;     
    case 2:
       Vbat = read_adc(1);
       ADid ++;
    break;     
    case 3:
       BatT = read_adc(6);
       ADid = 0;
    break;     
    default:
       ADid = 0;
    }

}
// SPI interrupt service routine
interrupt [SPI_STC] void spi_isr(void)
{

}

//////////////////////////////////////////////////////////
void send_data (char bytesend)
{              
char i,checksum;         
    {        
	tx_rd_index = 1;
	tx_counter = bytesend;  
	tx_buffer[0] = bytesend;
    checksum = 0;
    for (i=0;i<bytesend-1;i++)
        {
        checksum ^= tx_buffer[i];
        }           
    tx_buffer[bytesend-1] = checksum;
	UDR = tx_buffer[0];
    tx_counter--;
    }
}
void send_pkg (char bytesend)
{
    while (!fTranFinish);          // send back data
    fTranFinish = 0;       
	tx_rd_index = 1;
	tx_counter = bytesend;  
	UDR = tx_buffer[0];
    tx_counter--;
}
void send_status(void)
{
    while (!fTranFinish);          // send back data
    fTranFinish = 0;
    tx_buffer[2] = RandSend; // send data
    tx_buffer[3] = 4; // send data
    tx_buffer[5] = fON_OFF ? 1:0;            
    tx_buffer[6] = FanSet;
    tx_buffer[7] = fTimerOn? 1:0;
    tx_buffer[8] = sethour;
    tx_buffer[9] = setminute;
    tx_buffer[10] = Mode & 0x01;
    tx_buffer[11] = fSwing? 1: 0;
    tx_buffer[12] = LightValue;   
    tx_buffer[13] = fDisplayOn;
    tx_buffer[14] = ((Mode & 0x02) == 0x02)? 1: 0;// bit1 of Mode is sleep
//                   tx_buffer[14] = (Mode & 0x02) >> 1;// bit1 of Mode is sleep
    send_data(16);

}
void ChangeName(void)   // run under 100ms timer
{
char i;
const char *ptr;
 switch (NameMc)
    {
     case 0:
     if (fChangeName) 
        {
        NameMc = 1; 
        SyncKount = 0;
        }
     //if fSyncApp NameMc = 10;   // sync app
     if (++SyncKount == vSYNCKOUNT) 
        {
        SyncKount = 0;
        NameMc = 10;    // send sync command
        }
     break;
     case 1:       // send AT command
     if (++SyncKount == 20) // send name after 2 second
        {          
         tx_buffer[0] = 'A';
         tx_buffer[1] = 'T';
         fRxReceived = 0;
         SyncKount = 0;
         send_pkg(2);
         NameMc = 2;   
         }
     break;          
     case 2:
     if (fRxReceived)
        {
        if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
            {
            NameMc = 3;
            }      
        if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      // app present
            {
            SyncKount = 0;
            LostKount = 0;
            NameMc = 0;     //reinit the change name process
            }           
        }
     if (++SyncKount == 10)    // timeout
        {
        SyncKount = 0;
        NameMc = 0;     //reinit the change name process
        }
     break;
     case 3:    
     //rx_buffer[0] = 0xFF; 
     //fSound = 1; 
     ptr = NAME_CMD;    
     for (i=0;i<8;i++)
        {
        tx_buffer[i] = *ptr++;
        }
     ptr = NameBuffer;     
     SyncKount = i; // = 8 for 8 byte saved
     for (i=0;i<10;i++)         // max byte to send
        {
        if (*ptr != 0) 
            {
            tx_buffer[i+8] = *ptr++;      
            SyncKount ++;
            }
        else
            {
            break;
            }
        }
     fRxReceived = 0;
     send_pkg(SyncKount);
     NameMc = 4;   
     SyncKount = 0;
     fChangeName = 0;
     break;
     case 4:
     if (fRxReceived)
        {
   //     DIG6 = MaledInv[(rx_buffer[0] & 0xf0) >> 4];
   //     DIG7 = MaledInv[rx_buffer[0] & 0x0F];
        if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
            {
            NameMc = 5;       
    //        fStsLed = 1;
            SyncKount = 0;
            }
        }    
     if (++SyncKount == 10)
        {
        NameMc = 5;        
        SyncKount = 18;
        }
     break;
     case 5:                 
     if (++SyncKount == 20)
        {
        fStsLed = 0;
        NameMc = 0;  
        SyncKount = 0;
        fSound = 1;
        }     
     break;      
     ///////////////////////////////////////////// 
     case 10:       // sync app
//     fsyncApp = 0;
//     fStsLed = 1;
     NameMc = 11;
     break;
     case 11:       // send AT command      
     fStsLed = 0;    
     tx_buffer[0] = 'A';
     tx_buffer[1] = 'T';
     fRxReceived = 0;
     send_pkg(2);
     NameMc = 12;
     SyncKount = 0;
     break;          
     case 12:
     if (fRxReceived)
        {
        if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      // app present
            {
            LostKount = 0;
            }         
        else if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K') LostKount ++;     //no - app
        SyncKount = 0;
        NameMc = 0;
        }                 
     else
        {
        if (++SyncKount == 10)
            {
           // LostKount ++;
            SyncKount = 0;
            NameMc = 0;
            }
        } 
     if (LostKount == vLOSTKOUNT)  //reset the BLE 200 * 5s
        {
         tx_buffer[0] = 'A';
         tx_buffer[1] = 'T';
         tx_buffer[2] = '+';
         tx_buffer[3] = 'R';
         tx_buffer[4] = 'E';
         tx_buffer[5] = 'S';
         tx_buffer[6] = 'E';
         tx_buffer[7] = 'T';
         fRxReceived = 0;
         send_pkg(8);
         NameMc = 13;
         SyncKount = 0;        
        }         
     break;
     case 13:
     if (fRxReceived)
        {
        LostKount = 0;
        SyncKount = 0;
        NameMc = 0;
        if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')     //reset OK
            {
      //      fStsLed = 1;
            NameMc = 14;
            }
        }                 
     else
        {
        if (++SyncKount == 10) // no-reply
            {
            SyncKount = 0;
            NameMc = 0;
            }
        }              
     break; 
     case 14:
     if (++SyncKount == 20)
        {
        fStsLed = 0;
        NameMc = 0;
        }
     break;   
     default:
     NameMc = 0;
    }
}                                          
///////////////////////////////////////////////////////////
char load_eeprom()
{
char i,crc,retry,zero;

// first byte of block is StoreId (pos for new remote

    zero = 1;
    retry = 0;
    do {      // save section
        crc = 0;        

        StoreId = RemoteRom[0];
        crc = CRC8_DATA[crc ^ StoreId];

        for (i=0;i<2*MAXBUTTON*MAXREMOTE + 1;i++)
            {
            RemoteData[i] = RemoteRom[i+1];
            if (RemoteData[i] != 0) zero = 0;
            crc = CRC8_DATA[crc ^ RemoteData[i]];
            }
        if (zero)    // force load default
            {
            retry = 35;
            crc = 1;
            }      
        }
    while ((++retry < 30) && (crc != 0));
    return crc;
}

char save_eeprom()
{
char i,crc,retry;

    retry = 0;
    do {      // save section
        crc = 0;        
        RemoteRom[0] = StoreId;
        crc = CRC8_DATA[crc ^ StoreId];
        for (i=0;i<2*MAXBUTTON*MAXREMOTE;i++)
            {
            RemoteRom[i+1] = RemoteData[i];
            crc = CRC8_DATA[crc ^ RemoteData[i]];
            }      
        RemoteRom[2*MAXBUTTON*MAXREMOTE + 1] = crc;  
            // verify section
        delay_ms(100);
        crc = 0;
        for (i=0;i<2*MAXBUTTON*MAXREMOTE + 2;i++)
            {
            crc = CRC8_DATA[crc ^ RemoteRom[i]];
            }              
        }
    while ((++retry < 10) && (crc != 0));
    return crc;
}
//------------------------------------------------------------
char check_IR(void)
{
char i,j;
// input IrData[1:0]
// compare to RemoteData[]
// compare each remote, and return the matched button of that remote 
    for (i=0;i<MAXREMOTE;i++)
        {
        for (j=0;j<MAXBUTTON;j++)
            {
            if ((IrData[0] == RemoteData[i*MAXBUTTON*2+j*2]) && (IrData[1] == RemoteData[i*MAXBUTTON*2 + j*2 + 1]))
                {
                return (j+1);
                }           
            }
        }                   
    return 0;
}
//------------------------------------------------------------
void out7seg(void)
{
// shiftout 4 byte of data
char i,j;
char temp;
    for (j=0;j<4;j++)
    {
        temp = LedBuff[j];    
        if (j == 0)
            {
     //       if (Status == 2) temp &= SEGDP_INV;
            }                                  
        else if (j == 2)
            {
     //       if (Status == 1) temp &= SEGDP_INV;
            }    
        else if (j == 1)
            {
      //      if (fMpptPos)  temp &= SEGDP_INV;
            }
        for (i=0;i<8;i++)
        {
         LEDSDA = !(temp & 0x80);
         temp <<= 1;
        Nop;
        Nop;
        Nop;
         LEDSCL = 1;         
         Nop;
         Nop;
         Nop;
         LEDSCL = 0;
        }            
    }
    bLatch = 1;
    Nop;
    bLatch = 0;

}
// end of out7seg
//------------------------------------------------------------
void main(void)
{
// Declare your local variables here
char delay100ms, delay500ms=0, TestValue, i, second, minute, hour, FanRun;
char sounddelay, timerdispdelay, ModeMinute,ModeHour,AutoFanId = 0,AutoFanTime = 1;
char touch_o = 0,touch_e = 0,IfullSec = 0,StsDelay,SwMc = 0;
char delay10ms = 0, IrMode = 0, Button, ButtonId, RepeatKount,Button_reset,Button_old,RepeatTimeout;
char LedPwm = 0,Sts2Delay;
int ButDelay;
bit f1s, fTimerDisp = 0,fBatCharge = 1;
{
// Input/Output Ports initialization
// Port B initialization
// Func7=IN Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out 
// State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0 
PORTB=0x80;
DDRB=0x7F;

// Port C initialization
// Func6=In Func5=In Func4=out Func3=out Func2=In Func1=In Func0=In 
// State6=P State5=T State4=P State3=P State2=P State1=T State0=T 
PORTC=0x7C;
DDRC=0x18;

// Port D initialization
// Func7=in Func6=Out Func5=in Func4=out Func3=In Func2=out Func1=in Func0=In 
// State7=0 State6=0 State5=0 State4=P State3=P State2=P State1=0 State0=P 
PORTD=0xFF;
DDRD=0x54;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 125.000 kHz
TCCR0=0x03;
TCNT0=0x12;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 8000.000 kHz
// Mode: Ph. & fr. cor. PWM top=ICR1
// OC1A output: Disconnected
// OC1B output: Non-Inverted PWM
// Noise Canceler: On
// Input Capture on Falling Edge
// Timer Period: 0.03175 ms
// Output Pulse(s):
// OC1B Period: 0.03175 ms Width: 0.02 ms
// Timer1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (1<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
TCCR1B=(1<<ICNC1) | (0<<ICES1) | (1<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (1<<CS10);
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x7F;
OCR1AH=0x00;
OCR1AL=0x50;
OCR1BH=0x00;
OCR1BL=0x50;

// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 250.000 kHz
// Mode: CTC top=OCR2A
// OC2 output: Disconnected
// Timer Period: 0.1 ms
ASSR=0<<AS2;
TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (1<<CTC2) | (0<<CS22) | (1<<CS21) | (1<<CS20);
TCNT2=0x00;
OCR2=0x18;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=(1<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (1<<TOIE0);

// External Interrupt(s) initialization
// INT0: Off
// INT1: On
// INT1 Mode: Falling Edge
//GICR|=0x80;
//MCUCR=0x08;
//GIFR=0x80;

// External Interrupt(s) initialization
// INT0: Off
// INT1: On
// INT1 Mode: Falling Edge
GICR|=(1<<INT1) | (0<<INT0);
MCUCR=(1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
GIFR=(1<<INTF1) | (0<<INTF0);

// External Interrupt(s) initialization
// INT0: Off
// INT1: On
// INT1 Mode: Any change
//GICR|=(1<<INT1) | (0<<INT0);
//MCUCR=(0<<ISC11) | (1<<ISC10) | (0<<ISC01) | (0<<ISC00);
//GIFR=(1<<INTF1) | (0<<INTF0);


// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 9600
UCSRA=0x00;
UCSRB=0xD8;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;

// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 62.500 kHz
// ADC Voltage Reference: AVCC pin
// Only the 8 most significant bits of
// the AD conversion result are used
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x87;

// SPI initialization
// SPI Type: Master
// SPI Clock Rate: 500.000 kHz
// SPI Clock Phase: Cycle Start
// SPI Clock Polarity: Low
// SPI Data Order: MSB First
SPCR=0xD1;
SPSR=0x00;
}
//i2c_init();

/* globally enable interrupts */
#asm("sei")

TestValue = 1;
second = 0;

minute = 42;
hour = 9;
setminute = 50;
sethour = 9;
BatPWM = 12;
FanSet = 6;
FanRun = FanSet;
Mode = 0;
fTimerOn = 0;
fDisplayMode = 1;
Vbat = 250; // disable auto protect when init
bSts2Led = 0;
bStsLed = 0;
fON_OFF = 0;
//bSts2Led = 1;
if (load_eeprom() != 0)
    {
    StoreId = 0;
    for (i=0;i<2*MAXBUTTON*MAXREMOTE+1;i++)
        {
        RemoteData[i] = 0;
        }                 
    save_eeprom();
    fSts2Led = 1;
    }
//bSts2Led = 0;
fSts2Led = 0;

while (1)
      {
      // Place your code here 
//      if (fIrReceived)
//        {
//        fIrReceived = 0;
//        
//
//       if (fRC5)
//            {
//            if (IrData16[0] != IrData16[1])
//                {
//                if (++FanSet == 10) FanSet = 9;
//                }                              
//            else
//                {
//                if (FanSet-- == 0) FanSet = 0;
//                }
//            IrData16[1] = IrData16[0];    
//            }
//        }
      if (f1ms_ov)
        {                  
        f1ms_ov = 0;
        if (++RandData == 255) RandData = 1;   
        if (RxDelay != 0) 
            {
            if (--RxDelay == 0)
                {
                Rx_Mc = 0; 
                fRxReceived = 1;
                }
            }    
        if (++delay100ms == 100)
            {
            delay100ms = 0;           
            ADC();   
            if (++LedPwm == 10)
                {
                LedPwm = 0;
                }          
            if (FanSet > LedPwm)
                {
    //            if (fON_OFF) fSts1Led = 1;
                }            
            else
                {
      //          fSts1Led = 0;
                }
              
            if (fStsLed == 1)
                {
                if (--StsDelay == 0) 
                    {
                    fStsLed = 0;
                    StsDelay = 2;
                    }
                }
            else
                {
                StsDelay = 3;
                }         
        //    if (fSts2Led == 1) fSts2Led = 0;
            ChangeName();
            if (++delay500ms == 5)
                {
                delay500ms = 0;    
     //           fSts1Led = !fSts1Led;
                if (--timerdispdelay == 0) fTimerDisp = 0;    
                if (TestIr > 0)
                    {
                    TestIr --;
                    fSts2Led = 1;
                    }
                f1s = !f1s;
                if (f1s)
                    {
                    second ++;
                    IfullSec++;
                    if (second > 59) 
                        {
                        second = 0;       
                        if (++minute > 59) 
                            {
                            minute = 0;
                            if (++hour == 24) hour = 0;
                            }
                        // sleep timer process
                        if (Mode >= 2)
                            {
                            if (ModeMinute-- == 0)
                                {
                                ModeMinute = 59;
                                if (FanSet > 1) FanSet --;
                                FanRun = FanSet;
                                if (ModeHour-- == 0)
                                    {
                                    fON_OFF = 0;
                                    }
                                }
                            }     
                        if (fTimerOn)
                            {
                            if ((hour == sethour) && (minute == setminute))
                                {
                                fON_OFF = 0;
                                fTimerOn = 0; 
                                RandSend = 0;  
                                send_status();
                                }
                            }
                        }     
                    }   
                }          
            TestValue *= 2;
            if (TestValue == 0) TestValue = 1;
/////////////////////////////// input process @ 100ms ///////////////////////
// OUTPUT control for ON/OFF //////////////////////////
             if (fON_OFF)
                { 
                //////////////////////////////// mode process
                 switch (Mode)  
                    {
                    case 0:
                    FanRun = FanSet; 
                    break;
                    case 1:     // natural fan    
                    if (--AutoFanTime == 0)
                        {
                         AutoFanTime = AUTO_FAN[AutoFanId++];
                         FanRun = FanSet + AUTO_FAN[AutoFanId++];  
                         if (FanRun > 127) 
                            {
                            FanRun = 0;
                            }           
                         else if (FanRun > 9)
                            {
                            FanRun = 9;
                            }
                         if (AutoFanId >= 28) AutoFanId = 0;
                        }
                    break;
                    case 2:
                    FanRun = FanSet; 
                    break;
                    case 3:
                    if (--AutoFanTime == 0)
                        {
                         AutoFanTime = AUTO_FAN[AutoFanId++];
                         FanRun = FanSet + AUTO_FAN[AutoFanId++];  
                         if (FanRun > 127) 
                            {
                            FanRun = 0;
                            }           
                         else if (FanRun > 9)
                            {
                            FanRun = 9;
                            }
                         if (AutoFanId >= 28) AutoFanId = 0;
                        }
                    break;
                    default:
                    Mode = 0;
                    }     
// FAN SPEED CONTROL PWM //////////////////////////////
                if (FanRun == 0)
                    {
                    OCR1BL = 0;
                    }
                else
                    {   
                        { // dung so 8 lam so lon nhat
//                        OCR1BL = 15 + (FanRun-1) * 2;       // so 3 la so nho nhat.so 5 la so lon nhat.
                        OCR1BL = 73 + FanRun * 6; // total 127, from 70
                        }
                    }
                if (FanSet == 0) fSwing = 0;   
                }
             else        // fON_OFF = 0
                {
                OCR1BL = 0;       // so 3 la so nho nhat.so 5 la so lon nhat.
//                LightValue = 0;
                if (Mode >= 2) Mode -= 2;   // stop the sleep mode       
//                BatPWM = 15; 
//                fDisplayOn = 1;      
                }                   
// battery control section, voltage control
            }
        if (fRx_receive)
            {
            fRx_receive = 0;
            LostKount = 0; 
            SyncKount = 0;  // reset the sync signal MC
//            if ((rx_buffer_out[0] == 8) || (rx_buffer_out[0] == vFRAMELEN))    
            if ((fProtect == 0) && (rx_buffer_out[0] == vFRAMELEN))    
                {// process for received data
                //fSound = 1;
                switch (rx_buffer_out[3])
                    {      
                    case 1: //getting the version 
                    hour = rx_buffer_out[5];
                    minute = rx_buffer_out[6];
                    second = rx_buffer_out[7];
                    while (!fTranFinish);          // send back data
                    fTranFinish = 0;
                    tx_buffer[3] = 11; // send data
                    for (i=0;i<8;i++)
                        {
                        tx_buffer[5+i] = VERSION[i];            
                        }
                    send_data(16);      
                    break;
                    case 2:       // app getting data, sendback     
                    if (RandSend != RandData)
                        {
                        RandSend = RandData;
                        }
                    else
                        {
                        RandSend = RandData ^ 0x7E;
                        }
                    send_status();
                    break;
                    case 3:    // update data for FAN
                    if (rx_buffer_out[2] == RandSend)
                        {
                        fON_OFF = rx_buffer_out[5];
                        FanSet = rx_buffer_out[6];
                        fTimerOn = rx_buffer_out[7];
                        sethour = rx_buffer_out[8];
                        setminute = rx_buffer_out[9];
                        Mode = rx_buffer_out[10];       // single mode
                        fSwing = rx_buffer_out[11];
                        LightValue = rx_buffer_out[12];
                        fDisplayOn =  rx_buffer_out[13];
                        if (rx_buffer_out[14] == 1)     // sleep
                            {
                            Mode |= 0x02;
                            }
                        else
                            {
                            Mode &= (~0x02);
                            }
                        fSound = 1;
                        }
                    else
                        {     // send error message
                        while (!fTranFinish);          // send back data
                        fTranFinish = 0;
                        tx_buffer[2] = 0; // send data
                        tx_buffer[3] = 0; // send data
                        tx_buffer[5] = fON_OFF ? 1:0;            
                        tx_buffer[6] = FanSet;
                        tx_buffer[7] = fTimerOn? 1:0;
                        tx_buffer[8] = sethour;
                        tx_buffer[9] = setminute;
                        tx_buffer[10] = Mode && 0x01;
                        tx_buffer[11] = fSwing? 1: 0;
                        tx_buffer[12] = LightValue;   
                        tx_buffer[13] = fDisplayOn;
                        tx_buffer[14] = (Mode && 0x02)? 1: 0;// bit1 of Mode is sleep
                        send_data(16);
                        }
                    break;
                    case 8:     // rename the FAN 
                  //  NameBuffer[0] = 'P';
                  //  NameBuffer[1] = 'D';
                  //  NameBuffer[2] = 'e';
                    for (i=0;i<10;i++)  // copy 10 byte to NameBuffer
                        {
                        NameBuffer[i] = rx_buffer_out[i+5];
                        }
        
                    while (!fTranFinish);          // send back data
                    fTranFinish = 0;
                    tx_buffer[3] = 9; // send disconnect command
                    send_data(16);   
                    fChangeName = 1;   
                    break;                   
                    }     // end of switch case
                }
            }   // end of rx_receive bit
        if (++delay10ms == 10)
            {
            delay10ms = 0;  // run for IR process  
            if (fSound)
                {
                if (++sounddelay == 30)
                    {
                    fSound = 0;                   
                    send_status();
                    }
                }         
            else
                {
                sounddelay = 0;                                          
                }
             
            if (--Button_reset == 0) Button_old = 0xff;   
            if (fSts2Led)
                {
                if (--Sts2Delay == 0) fSts2Led = 0;
                }
            else
                {
                Sts2Delay = 20;
                }           
            switch (IrMode) // process for recieving IR data 
                {
                case 0: // normal mode
                fStsLed = fON_OFF;
                StsDelay = 2;
                if (fIrReceived)
                    {
                    fIrReceived = 0;                
                    Button_reset = 20;
                    Button = check_IR();  // = 0: not match, = 1-MAXBUTTON: return button value 
                    if (Mode != 0)
                        {
                        fSts1Led = fON_OFF;
                        }           
                    else
                        {
                        fSts1Led = 0;
                        }
                    if (Button != Button_old)
                        {            
                        if (fON_OFF || (Button > 4) || (Button == 0))
                            {    
                            fSts2Led = 1; 
                            switch (Button)
                                {
                                case 0:
                                ButDelay = 0;    // timeout for repeat pressing button 
                                IrData[4] = IrData[0];
                                IrData[5] = IrData[1];
                                RepeatKount = 0;
                                if (bOpt == 0) IrMode = 1;     // checking IR storing condition
                                break;
                                case 1: // off button
                                fSound = 1;
                                fON_OFF = 0;    // control everything
                                break;                               
                                case 2:   // lamp button
                                fSound = 1;
                                if (++LightValue == 4) LightValue = 0;
                                break;                  
                                case 3:      // mode button
                                fSound = 1;
                                if (++Mode == 2) Mode = 0;
                                break;
                                case 4: // timer button -> swing 
                                fSound = 1;
                                fSwing = !fSwing;
                                break;    
                                case 5: // swing -> DEC button
                                fSound = 1;
                                if (FanSet-- == 0) 
                                    {
                                    FanSet = 0;
                                    fON_OFF = 0;
                                    }
                                else
                                    {
                                    fON_OFF = 1;
                                    }
                                break;        // ON/Speed -> INC                
                                case 6:
                                fSound = 1;
                                if (++FanSet >= 10) FanSet = 9; 
                                fON_OFF = 1;
                                break;
                                }
                            }
                        }
                    Button_old = Button;
                    }   
                if (bSw == 0) 
                    {
                    if (++ButDelay > 250)
                        {
                        IrMode = 11;  
                        RepeatKount = 0;
                        ButDelay = 0;

//                        IrMode = 2;    
 //                       ButDelay = 0;
   //                     ButtonId = 0;
                        }
                    }      
                else
                    {
                    ButDelay = 0;
                    }                                                                  
                break; 
                case 1:     // check IRstoring condition for repeat every
                if (++ButDelay > 100) IrMode = 0;   // exit when timeout
                if (fIrReceived)
                    {
                    fIrReceived = 0;
                    if ((IrData[4] != IrData[0]) || (IrData[5] != IrData[1])) 
                        {
                        ButDelay = 0;                
                        fStsLed = 1;
                        if (++RepeatKount == 8)
                            {
                            IrMode = 11;  
                            RepeatKount = 0;
                            ButDelay = 0;
                            } 
                        }               
                    IrData[4] = IrData[0];
                    IrData[5] = IrData[1];
                    }                
                break;
                case 11:        
                if (++ButDelay == 10)
                    {
                    ButDelay = 0;
                    fSts2Led = !fSts2Led;
                    if (++RepeatKount == 30)
                        {
                        IrMode = 2;
                        ButtonId = 0;   
                        fIrReceived = 0;
                        }
                    }
                break;   
                case 2:     //store IR data 
                fSts2Led = 1;
                if (fIrReceived)
                    {
                    fIrReceived = 0; 
                    ButDelay = 0;               
            //        Button_reset = 30;
            //        i = Set_IR(ButtonId);     // check for exist and store, return 1 if new, 0 if old 
            //        Button = check_IR();  // = 0: not match, = 1-MAXBUTTON: return button value      
                    i = ButtonId;
                    if (i != 0) i--;
                    if ((IrData[0] != RemoteData[StoreId*MAXBUTTON*2 + i*2]) || (IrData[1] != RemoteData[StoreId*MAXBUTTON*2 + i*2 + 1]))
                        {
                        RemoteData[StoreId*MAXBUTTON*2 + ButtonId*2] = IrData[0];
                        RemoteData[StoreId*MAXBUTTON*2 + ButtonId*2 + 1] = IrData[1];
                        fStsLed = 1;
                        if (++ButtonId == MAXBUTTON)  // save data
                            {
                            if (++StoreId == MAXREMOTE) StoreId = 0;
                            save_eeprom();    
                            IrMode = 4;
                            ButDelay = 0;        
                            RepeatKount = 0;
                            }
                        }
                    }
             //   if (bSw == 1) IrMode = 0;                   
                if (++ButDelay > 500) 
                    {
                    if (bSw == 0)
                        {
                        IrMode = 5; // clear all IR data
                        }
                    else
                        {
                        IrMode = 0;
                        }
                    }
                break;
                case 3:
                if (bSw == 1)
                    {
                    IrMode = 0;
                    fSts2Led = 0;
                    } 
                if (++RepeatTimeout == 20)    //200ms
                    {
                    RepeatTimeout = 0; 
                    fSts2Led = 1;
                    }
                break;    
                case 4:
                if (++ButDelay == 10)
                    {
                    ButDelay = 0;
                    fSts2Led = !fSts2Led;
                    if (++RepeatKount == 30)
                        {
                        IrMode = 3;
                        ButtonId = 0;   
                        fIrReceived = 0;
                        }
                    }
                break;   
                case 5:
                for (i=0;i<MAXREMOTE*MAXBUTTON;i++)
                    {
                        RemoteData[i] = 0;
                    }              
                save_eeprom();                        
                ButDelay = 0;
                RepeatKount = 0;
                IrMode = 6; // inform all cleared
                break;                           
                case 6:
                if (++ButDelay == 10)
                    {
                    ButDelay = 0;
                    fSts2Led = !fSts2Led;
                    if (++RepeatKount == 40)
                        {
                        IrMode = 0;
         //               ButtonId = 0;   
                        fIrReceived = 0;
                        }
                    }                
                break;
                default:
                break; 
                }
            }
            
bSts1Led = fSts1Led;
bSts2Led = fSts2Led;
bStsLed = fStsLed;
        } // end of 1ms timer     
      }    // end of while loop
}