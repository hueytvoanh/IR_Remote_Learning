/*****************************************************
This program was produced by the
CodeWizardAVR V1.25.6 Standard
Automatic Program Generator
� Copyright 1998-2007 Pavel Haiduc, HP InfoTech s.r.l.
http://www.hpinfotech.com

Project : Controller
Version : A
Date    : 9/2/2009
Author  : Thien Duy
Company : TDT
Comments:


Chip type           : ATmega8
Program type        : Application
Clock frequency     : 12.000000 MHz
Memory model        : Small
External SRAM size  : 0
Data Stack size     : 256
*****************************************************/

#include <mega8.h>
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x80
	.EQU __sm_mask=0x70
	.EQU __sm_powerdown=0x20
	.EQU __sm_powersave=0x30
	.EQU __sm_standby=0x60
	.EQU __sm_ext_standby=0x70
	.EQU __sm_adc_noise_red=0x10
	.SET power_ctrl_reg=mcucr
	#endif


// External Interrupt 1 service routine
interrupt [EXT_INT1] void ext_int1_isr(void)
{
// Place your code here

}
///////////////////////////////////////////////////////
//Hardware define

#define LATCH   	PORTD.7
#define LEDSCL  	PORTD.6
#define LEDSDA  	PORTD.5
#define BELLOUT    	PORTD.4
#define TX_EN   	PORTD.2

#define bONpower		PORTC.3
#define bSwitch		PINC.4

#define PWM_Bass    PORTB.3
#define PWM_Treble  PORTB.5
#define PWM_Volume  PORTB.4

#define EncodeS		PINB.1
#define EncodeC		PINB.2
#define bON_OFF		PINB.0

///////////////////////////////////////////////////////
#define RXB8 1
#define TXB8 0
#define UPE 2
#define OVR 3
#define FE 4
#define UDRE 5
#define RXC 7
#define Nop #asm("NOP")

#define PINGPONG    0x02
#define FAN_        0x04
#define CS_LINE2_   0x01
#define CS_LINE1_   0x02
#define CS_LINE12_  0x03
#define SOUNDON     0x20
#define ALARM       0x40
#define AMP_PW      0x80

#define ADC_LIGHT   5
#define ADC_VOICE   2
#define ADC_ROOM    1
#define ADC_ALUM    0

#define CHANEL_ON   0x80
#define CHANEL_OFF  0x00
#define CHANELA     0x10
#define CHANELB     0x00

#define ANALOG1     3
#define ANALOG2     2
#define ANALOG3     1
#define ANALOG4     0
#define MIC_FRONT   6
#define MIC_BACK    7
#define BELL1       5
#define BELL2       4

#define AUTO_ON_MIC 	0x10
#define AUTO_OFF		0x20
#define AUTO_RESTORE	0x40
#define ACK_ENABLE		0x80

#define CHANEL_AUTO		0x08
#define CHANEL_OFFALL	0x00
#define CHANEL_1		0x01
#define CHANEL_2		0x02
#define CHANEL_12		0x03

#define GREEN       2
#define RED         1

#define vSYNC           0
#define vBELL_ON        1
#define vALARM_ON       2
#define vALARM_BELL_ON  3
#define vUPDATE_TIME    4
#define vSTARTUP_MODE   5
#define vON_DEVICE      6
#define vOFF_DEVICE     7
#define vUPDATE_AMPLI   8
#define vALARM_HALF     9
#define vANALOG_SELECT  10
#define vALARM_ONE		11
#define vUPDATE_ADDR	12
#define vREAD_STATUS	14
#define vCONFIG			15
#define vREAD_SENSOR	16

#define ACK				0x0f

#define BIT0    0x01
#define BIT1    0x02
#define BIT2    0x04
#define BIT3    0x08
#define BIT4    0x10
#define BIT5    0x20
#define BIT6    0x40
#define BIT7    0x80

#define MAXADDR	180

#define ALARM1RING	14
#define ALARM2RING	8
#define ALARM4RING	1

#define FRAMING_ERROR (1<<FE)
#define PARITY_ERROR (1<<UPE)
#define DATA_OVERRUN (1<<OVR)
#define DATA_REGISTER_EMPTY (1<<UDRE)
#define RX_COMPLETE (1<<RXC)

 typedef struct {
                    unsigned char week;
                    unsigned char day;
                    unsigned char hour;
                    unsigned char minute;
                    unsigned char second;
                    } time_format;

 typedef struct {
                    unsigned char hour;
                    unsigned char minute;
                    } alarm_format;

/////////////////////////////////////////////////////////////////
// Declare your global variables here

eeprom char eeTreble = 8, eeBass = 6, eeVolume = 8, eeFixAdd = 255, eeFixAdd_ = ~255;
eeprom char eeLimitMode = 0;
eeprom char eeLimitVolHi = 7;
eeprom char eeLimitVolLo = 3;
eeprom char eeConfig = AUTO_RESTORE | CHANEL_1;
eeprom char eeChanelA = MIC_FRONT | CHANEL_ON | CHANELA;
eeprom char eeChanelB = MIC_FRONT | CHANEL_ON | CHANELB;
eeprom char eefON_OFF = 1;
eeprom char eeAutoline_bk = ~CS_LINE1_;
eeprom char eeBellVolume = 3;
eeprom char eeAnalogControl = BIT7 | BIT3 | BIT4;          // BITMICRO   + BITANALOG1
eeprom char eefAutoGain = 1;
eeprom char eeSoundLevel = 100;			// 8 bit sound level


char Treble_value, Bass_value, Volume_value, status=0,Loadreg = ~CS_LINE1_;
char AnalogControl=0, Display[6];

char timer2_delay = 0,test,SendDelay,status_AND = 0xFF;
char Rx_Mc = 0, FixAdd, RxDelay = 2,Delay1ms;
bit f10ms_ov = 0,fSendSense = 0;
bit fVolume_AND = 1, fBass_AND = 1, fTreble_AND = 1;

bit fBell_en = 0, fPingPong = 0,fRx_error = 0,fBlinkRED =0, fON_OFF = 1,fON_OFFsw = 0;
bit fSendACK,fWriteAnalog, fBackup,fSecond,fLedRed,fLedGreen;
bit fTranFinish = 1,fSendStatus = 0, fAutoGain = 0;
bit fEncodeSedge,fEncodeSold, fSwitch = 0,fSwitchOld = 0;

char Bell_pulse = 1, Bell_freq = 10, Alarm_Mc = 0;

char CRC,Tx_TimeOut = 10;

//bit fBellOn, fAnalog1, fAnalog2, fAnalog3, fAnalog4, fMicro;
#define BITBELL		BIT2
#define BITANALOG1	BIT3
#define BITANALOG2	BIT4
#define BITANALOG4	BIT5
#define BITANALOG3	BIT6
#define BITMICRO	BIT7

time_format currenttime = {1,2,0,0,0};

#define SEGA	~(0x01 << 2)
#define SEGB	~(0x01 << 3)
#define SEGC	~(0x01 << 5)
#define SEGD	~(0x01 << 6)
#define SEGE	~(0x01 << 7)
#define SEGF	~(0x01 << 1)
#define SEGG	~(0x01 << 0)
#define SEGDP_INV	~(0x01 << 4)

#define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
#define LEDNUM1		SEGE & SEGF
#define LEDNUM2		SEGA & SEGB & SEGD & SEGE & SEGG
#define LEDNUM3		SEGA & SEGD & SEGE & SEGF & SEGG
#define LEDNUM4		              SEGC        & SEGE & SEGF  & SEGG
#define LEDNUM5		SEGA &        SEGC & SEGD &        SEGF  & SEGG
#define LEDNUM6		SEGA & SEGB & SEGC & SEGD &        SEGF  & SEGG
#define LEDNUM7		                     SEGD & SEGE & SEGF
#define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUM9		SEGA &        SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMA		       SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMB		SEGA & SEGB & SEGC &               SEGF  & SEGG
#define LEDNUMC		SEGA & SEGB & SEGC & SEGD
#define LEDNUMD		SEGA & SEGB &               SEGE & SEGF  & SEGG
#define LEDNUME		SEGA & SEGB & SEGC & SEGD &                SEGG
#define LEDNUMF		       SEGB & SEGC & SEGD &                SEGG
#define LEDNUM16	SEGG
#define LEDNUM17	0xFF

//#define BIT0    0x01
//#define BIT1    0x02
//#define BIT2    0x04
//#define BIT3    0x08
//#define BIT4    0x10
//#define BIT5    0x20
//#define BIT6    0x40
//#define BIT7    0x80

const unsigned char   MaledInv[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,
								 LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};

#define SEGA	~(0x01 << 5)
#define SEGB	~(0x01 << 4)
#define SEGC	~(0x01 << 2)
#define SEGD	~(0x01 << 1)
#define SEGE	~(0x01 << 0)
#define SEGF	~(0x01 << 6)
#define SEGG	~(0x01 << 7)
#define SEGDP	~(0x01 << 3)

#define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
#define LEDNUM1		SEGB & SEGC
#define LEDNUM2		SEGA & SEGB &  SEGD & SEGE & SEGG
#define LEDNUM3		SEGA & SEGB & SEGC & SEGD & SEGG
#define LEDNUM4		SEGB & SEGC & SEGG & SEGF
#define LEDNUM5		SEGA & SEGC & SEGD & SEGG & SEGF
#define LEDNUM6		SEGA & SEGG & SEGC & SEGD & SEGE & SEGF
#define LEDNUM7		SEGA & SEGB & SEGC
#define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUM9		SEGA & SEGB & SEGC & SEGD & SEGF  & SEGG
#define LEDNUMA		SEGA & SEGB & SEGC & SEGE & SEGF  & SEGG
#define LEDNUMB		SEGC & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMC		SEGA & SEGD & SEGE & SEGF
#define LEDNUMD		SEGB & SEGC & SEGD & SEGE & SEGG
#define LEDNUME		SEGA & SEGD & SEGE & SEGF  & SEGG
#define LEDNUMF		SEGA & SEGE & SEGF  & SEGG
#define LEDNUM16	SEGG
#define LEDNUM17	0xFF



const unsigned char   Maled[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,
								    LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};
const char MapAddr[8] = {0, 4, 2, 6, 1, 5, 3, 7};
const char CRC8_DATA[256]={
		0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
		0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e,	0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
		0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0,	0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
		0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,	0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
		0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,	0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
		0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58,	0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
		0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6,	0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
		0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b,	0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
		0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f,	0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
		0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92,	0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
		0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c,	0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
		0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1,	0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
		0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49,	0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
		0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,	0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
		0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a,	0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
		0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7,	0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35};

/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
// data structure
// time format: second : minute : hour : day : date : month
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////

// USART Receiver buffer
#define RX_BUFFER_SIZE 8
char rx_buffer[RX_BUFFER_SIZE];
char rx_buffer_out[RX_BUFFER_SIZE];

#if RX_BUFFER_SIZE<256
unsigned char rx_wr_index,rx_rd_index;//,rx_counter;
#else
unsigned int rx_wr_index,rx_rd_index;//,rx_counter;
#endif

// This flag is set on USART Receiver buffer overflow
bit fRx_receive = 0;

/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
// Data frame format for network
// using fix size data frame: restart if lost of data byte
// Header: | Slave address or 0xFF | command | data bytes | CRC (include command) |
//size of frame = RX_BUFFER_SIZE including address, command, data and CRC bytes

/////////////////////////////////////////////////////
/////////////////////////////////////////////////////
// USART Receiver interrupt service routine
interrupt [USART_RXC] void usart_rx_isr(void)
{
char status1,data;
status1=UCSRA;
data=UDR;
//test = data;
//fBlinkRED = 1;
if ((status1 & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
{
switch (Rx_Mc)
    {
    case 0:
        {
 //        UCSRA &= ~BIT0;       // turn off address mode
         rx_buffer[0]=data;   //store the address byte
         rx_wr_index=1;
         CRC = data;
         CRC = CRC8_DATA[CRC];
         Rx_Mc = 1;
         RxDelay = 5;
        }

    break;
    case 1:         // receiving data frame
    rx_buffer[rx_wr_index]=data;
    RxDelay = 5;
    CRC ^= data;
    CRC = CRC8_DATA[CRC];
    if (++rx_wr_index == RX_BUFFER_SIZE)
       {
  //  if ((data == FixAdd) || (data == 0xFF))
       if ((CRC == 0) && ((rx_buffer[0] == FixAdd) || (rx_buffer[0] == 0xFF)))
            {
            fRx_receive = 1;
            for (rx_wr_index=0;rx_wr_index<RX_BUFFER_SIZE;rx_wr_index++)      //double buffer purpose
                {
                rx_buffer_out[rx_wr_index] = rx_buffer[rx_wr_index];
                }
            }
       else
            {
             fRx_error = 1;
            }
       Rx_Mc = 0;
//       UCSRA |= BIT0;       // turn on address mode
       };
    break;
    default:
    Rx_Mc = 0;
    }
}
}

#ifndef _DEBUG_TERMINAL_IO_
// Get a character from the USART Receiver buffer
#define _ALTERNATE_GETCHAR_
#pragma used+
#pragma used-
#endif

// USART Transmitter buffer
#define TX_BUFFER_SIZE 10
char tx_buffer[TX_BUFFER_SIZE];

#if TX_BUFFER_SIZE<256
unsigned char tx_wr_index,tx_rd_index,tx_counter;
#else
unsigned int tx_wr_index,tx_rd_index,tx_counter;
#endif

// USART Transmitter interrupt service routine
interrupt [USART_TXC] void usart_tx_isr(void)
{
if (tx_counter != 0)
   {
   --tx_counter;
   UDR=tx_buffer[tx_rd_index];
   Tx_TimeOut = 10;
   if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index=0;
   }
else
   {
	fTranFinish = 1;
	TX_EN = 0;
   }
}

#ifndef _DEBUG_TERMINAL_IO_
// Write a character to the USART Transmitter buffer
#define _ALTERNATE_PUTCHAR_
#endif

// Standard Input/Output functions
#include <stdio.h>

// Timer 0 overflow interrupt service routine
interrupt [TIM0_OVF] void timer0_ovf_isr(void)
{
    static char T_cycle;
// Place your code here
// timer 0 has 12MHz clock input
// Overflow cycle = 12000/50 = 240KHz
// PWM cycle = 240KHz /T_cycle = 2.4KHz if T_cycle=100

    TCNT0 = (unsigned char)(-50);
    if (++T_cycle == 101)
        {
        T_cycle = 0;   // make fund cycle = 14*28*MC
        PWM_Bass = 1;
        PWM_Volume = 1;
        PWM_Treble = 1;
        }
    if (Bass_value == T_cycle) PWM_Bass = 0;
    if (Treble_value == T_cycle) PWM_Treble = 0;
    if (Volume_value == T_cycle) PWM_Volume = 0;

}

// Timer 2 output compare interrupt service routine
interrupt [TIM2_COMP] void timer2_comp_isr(void)
{
    // 100us overflow interrupt
    if (SendDelay != 0) SendDelay --;
    if (++Delay1ms == 10)
        {
        Delay1ms = 0;
        if (RxDelay != 0) RxDelay --;
        }
    if (++timer2_delay == 100)
        {
        timer2_delay = 0;
        f10ms_ov = 1;
        }

    //process Bell here
    if (fBell_en)
        {
        if (--Bell_pulse == 0)
            {
            Bell_pulse = Bell_freq;
            BELLOUT = ~BELLOUT;
            }
        }
    else
        {
        BELLOUT = 0;
        }

}

#include <delay.h>

#define ADC_VREF_TYPE 0x40

// Read the AD conversion result
unsigned int read_adc(unsigned char adc_input)
{
ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
// Delay needed for the stabilization of the ADC input voltage
delay_us(10);
// Start the AD conversion
ADCSRA|=0x40;
// Wait for the AD conversion to complete
while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;
return ADCW;
}
/////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////
void ShiftData (char value_in)
{
    char i;
    for (i=0;i<8;i++)
    {
     LEDSDA = (value_in & 0x80);
     value_in <<= 1;
    Nop;
    Nop;
    Nop;
     LEDSCL = 1;
     Nop;
     Nop;
     Nop;
     LEDSCL = 0;
    }
}

/////////////////////////////////////////////////////////////////
void outled(void)
{
    static char LedMode;
	char DataOut;
//    char temp;
//    if (fON_OFF == 0)
//        {
//         fVolume_AND = 0;
//         fBass_AND = 0;
//         fTreble_AND = 0;
//        }
        switch (LedMode)
        {
        case 0:
        DataOut = MaledInv[Display[3]];
        if (fSecond) DataOut &=  SEGDP_INV;
//if (fSecond) DataOut &=  SEGDP;
        if (!fBass_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80;
        LedMode = 1;
        break;
        case 1:
        DataOut = Maled[Display[4]];
        if (fSecond) DataOut &=  SEGDP;
        if (!fVolume_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80>>1;
        LedMode = 2;
        break;
        case 2:
        DataOut = MaledInv[Display[5]];
        if (!fVolume_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80>>2;
        LedMode = 3;
        break;
        case 3:
        DataOut = Maled[Display[0]];
        if (!fTreble_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80>>3;
        LedMode = 4;
        break;
        case 4:
        DataOut = MaledInv[Display[1]];
        if (fSecond) DataOut &=  SEGDP_INV;
        if (!fTreble_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80>>4;
        LedMode = 5;
        break;
        case 5:
        DataOut = Maled[Display[2]];
//if (fSecond) DataOut &=  SEGDP_INV;
        if (fSecond) DataOut &=  SEGDP;
        if (!fBass_AND) DataOut = 0xff;
        ShiftData(DataOut);
		DataOut = 0x80>>5;
        LedMode = 0;
        break;
        default:
        LedMode =0;
        }

	if (fLedRed) DataOut |= 1;
 	if (fLedGreen) DataOut |= 2;
        ShiftData(DataOut);
// analogControl from bit7-2, loadreg from Bit1-0
		DataOut = ~AnalogControl;
		DataOut &= 0xFC;
		DataOut |= (Loadreg & 0x03);
        ShiftData(DataOut);
//        ShiftData((~AnalogControl) & (~0x03));
        LATCH = 1;
        LATCH = 0;
}

/////////////////////////////////////////////////////////////////
// description: chanel has 2 nibble:    chanel[7]: on_off data = 0: off, = 1 : on
//                                      chanel[4]: select output chanel: = 0: CHB, = 1: CHA
//                                      chanel[2:0]: chanel input select  from 1 to 8
//              on_off bit:         = 1: on the chanel to out, = 0 off the chanel.


/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
void SendACK (void)
{
	TX_EN = 1;
	CRC = FixAdd;
	CRC = CRC8_DATA[CRC];
	CRC ^= ACK;
	CRC = CRC8_DATA[CRC];
	tx_rd_index = 1;
	tx_counter = 2;
	tx_buffer[0] = FixAdd;
	tx_buffer[1] = ACK;
	tx_buffer[2] = CRC;
	while (!fTranFinish);
	fTranFinish = 0;
//	UCSRB &= ~1;              // TXB = 0
	UDR = tx_buffer[0];
    Tx_TimeOut = 10;
}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
// send maximun TX_BUFFER_SIZE - 1 byte, the last byte is CRC
// Tx_counter is input
void SendBuffer (void)
{
	TX_EN = 1;
	CRC = 0;
	for (tx_rd_index = 0;tx_rd_index < tx_counter;tx_rd_index++)
		{
		CRC ^= tx_buffer[tx_rd_index];
		CRC = CRC8_DATA[CRC];
		}
	tx_buffer[tx_counter] = CRC;
	tx_rd_index = 1;
	while (!fTranFinish);
	fTranFinish = 0;
//	UCSRB &= ~1;              // TXB = 0
	UDR = tx_buffer[0];		  // total byte to send = tx_counter = (data byte + CRC)
    Tx_TimeOut = 10;
}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
unsigned char comp_time(const alarm_format ring_time)
{
	if ((currenttime.hour == ring_time.hour) || (currenttime.minute == ring_time.minute)) return 1;
	else return 0;

}
/////////////////////////////////////////////////////////////////
/////////////////////////////////////////////////////////////////
void main(void)
{
// Declare your local variables here
 char temp,i,j;
 unsigned int rSWdelay = 1;
 char ADC_MC = 0, rSelectMode = 0, Config, Kount = 0;
 int vAdcLight,vAdcVoice,vAdcRoom,vAdcAlum, temp_int;

 //char rDelay_blink = 0;
 bit fBass_blink = 0,fTreble_blink = 0,fVolume_blink = 0, fTest = 1, fLightTest = 0;


 char Volume_bk,Bass_bk,Treble_bk,Bell_Mc = 0,Alarm_delay, Bell_delay;
 char Blink_Mc = 0, Blink_delay;

 char DelayN100ms = 1,rDelay100ms = 0, rDelay1s = 0, rDelay500ms = 0, Button_delay;
 char AlarmByte[5];

 char AutolineDelay,Connectimeout,AutoLine_Mc = 0,oldAdcSW, ReadingLoop;

 char LimitMode;
 char LimitVolHi;
 char LimitVolLo;
 char BellVolume;
 char SwitchDelay = 20,SwitchDelay1 = 20;
 char DispEqDelay = 10,EqMc = 0;
 char Test = 0;
 char SoundLevel;

// Input/Output Ports initialization
// Port B initialization
// Func7=In Func6=In Func5=Out Func4=Out Func3=Out Func2=In Func1=In Func0=In
// State7=T State6=T State5=0 State4=0 State3=0 State2=0 State1=0 State0=0
PORTB=0x07;                 // = 1: pullup
DDRB=0x38;                  // = 0: IN

// Port C initialization
// Func6=In Func5=In Func4=In Func3=OUT Func2=In Func1=In Func0=In
// State6=T State5=P State4=0 State3=0 State2=0 State1=T State0=T
PORTC=0x10;	//
DDRC=0x08;  // 0 = In

// Port D initialization
// Func7=Out Func6=Out Func5=Out Func4=Out Func3=In Func2=OUT Func1=Out Func0=In
// State7=0 State6=0 State5=0 State4=0 State3=P State2=P State1=0 State0=P
PORTD=0x09;
DDRD=0xF6;

// Timer/Counter 0 initialization
// Clock source: System Clock
// Clock value: 12.000.000 kHz
TCCR0=0x01;
TCNT0=0x00;

// Timer/Counter 1 initialization
// Clock source: System Clock
// Clock value: 1500.000 kHz
// Mode: Fast PWM top=00FFh
// OC1A output: Non-Inv.
// OC1B output: Non-Inv.
// Noise Canceler: Off
// Input Capture on Falling Edge
// Timer 1 Overflow Interrupt: Off
// Input Capture Interrupt: Off
// Compare A Match Interrupt: Off
// Compare B Match Interrupt: Off
/*
TCCR1A=0xA1;
TCCR1B=0x0A;
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x00;
OCR1AH=0x00;
OCR1AL=0x00;
OCR1BH=0x00;
OCR1BL=0x00;
  */
// Timer/Counter 2 initialization
// Clock source: System Clock
// Clock value: 1500.000 kHz
// Mode: CTC top=OCR2
// OC2 output: Disconnected
ASSR=0x00;
TCCR2=0x0A;
TCNT2=0x00;
OCR2=150-1;

// External Interrupt(s) initialization
// INT0: Off
// INT1: On
// INT1 Mode: Falling Edge
GICR|=0x80;
MCUCR=0x08;
GIFR=0x80;

// Timer(s)/Counter(s) Interrupt(s) initialization
TIMSK=0x81;

// USART initialization
// Communication Parameters: 9 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 19200
// UCSRA=0x00;
// UCSRB=0xDC;
// UCSRC=0x86;
// UBRRH=0x00;
// UBRRL=0x26;

// USART initialization
// Communication Parameters: 8 Data, 1 Stop, No Parity
// USART Receiver: On
// USART Transmitter: On
// USART Mode: Asynchronous
// USART Baud Rate: 19200
UCSRA=0x00;
UCSRB=0xD8;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x26;


// Analog Comparator initialization
// Analog Comparator: Off
// Analog Comparator Input Capture by Timer/Counter 1: Off
ACSR=0x80;
SFIOR=0x00;

// ADC initialization
// ADC Clock frequency: 750.000 kHz
// ADC Voltage Reference: AVCC pin
ADMUX=ADC_VREF_TYPE & 0xff;
ADCSRA=0x84;

// Watchdog Timer initialization
// Watchdog Timer Prescaler: OSC/2048k
#pragma optsize-
WDTCR=0x1F;
WDTCR=0x0F;
#ifdef _OPTIMIZE_SIZE_
#pragma optsize+
#endif

// Global enable interrupts
//#asm("sei")

//off all the LED
fON_OFF = 0;
outled();
outled();
outled();
// init variable
//for (j=1;j<5;j++)
for (i=1;i<200;i++)
	{
	delay_ms(3);
	#asm("WDR")
	}

Volume_bk = eeVolume;
if (Volume_bk > 99)
	{
	Volume_bk = 56;
	eeVolume = 56;
	}
else if (Volume_bk == 0)
	{
	Volume_bk = 1;
	eeVolume = 1;
	}

Bass_bk = eeBass;
if (Bass_bk > 99)
	{
	 Bass_bk = 55;
	 eeBass = 55;
	}
if (Bass_bk == 0)
	{
	 Bass_bk = 1;
	 eeBass = 1;
	}
Treble_bk = eeTreble;
if (Treble_bk > 99)
	{
	 Treble_bk = 54;
	 eeTreble = 54;
	}
if (Treble_bk == 0)
	{
	 Treble_bk = 1;
	 eeTreble = 1;
	}
//for (i=1;i<10;i++)
//	{
//	if (eeFixAdd > MAXADDR)
//	}
FixAdd = 0xFF;
#asm("cli")
for (i=0;i<8;i++)
    {
    temp = eeFixAdd;
    if ((temp == ~eeFixAdd_) && (temp > 0) && (temp < MAXADDR))
    	{
    	FixAdd = temp;
    	break;
    	}
	delay_ms(3);
	#asm("WDR")
	}

TX_EN = 0;

if (eeLimitMode > 4) eeLimitMode = 0;
LimitMode = eeLimitMode;
if (eeLimitVolHi > 99) eeLimitVolHi = 99;
LimitVolHi = eeLimitVolHi;
if (eeLimitVolLo > 99) eeLimitVolLo = 55;
LimitVolLo = eeLimitVolLo;

Config = eeConfig;
if (Config & AUTO_ON_MIC)
    {
	fON_OFF = 1;
	AnalogControl = BITMICRO;
    Volume_value = Volume_bk;
    Bass_value = Bass_bk;
    Treble_value = Treble_bk;
    }
else if (Config & AUTO_OFF)
    {
	fON_OFF = 0;
    status = 0;
    Volume_value = 0;
    Bass_value = 0;
    Treble_value = 0;
    }
 else if (Config & AUTO_RESTORE)
 	{
 	 fON_OFF = eefON_OFF;
     Volume_value = Volume_bk;
     Bass_value = Bass_bk;
     Treble_value = Treble_bk;
	 AnalogControl = eeAnalogControl;
 	}
BellVolume = eeBellVolume;
fAutoGain = eefAutoGain;
SoundLevel = eeSoundLevel;
#asm("sei")
/////////////////////////////////////////////////////////////////////////
// startup completely
/////////////////////////////////////////////////////////////////////////
while (1)
      {
      // Place your code here
      //////////////////////////////////////
      // test IO port of system

      //////////////////////////////////////
      // running realtime clock function
      if (f10ms_ov)
            {
            f10ms_ov = 0;
            //SendDelay --;
         //   RxDelay --;
            Bell_delay --;
            Blink_delay --;
            if (Tx_TimeOut != 0)
            	{
            	Tx_TimeOut --;
              	}
            else
            	{
            	Tx_TimeOut = 4;
            	 TX_EN = 0;
            	}
			if (bON_OFF == 0)
				{
				if (--SwitchDelay == 0)
					{
					fON_OFFsw = 1;
					}
				}
			else
				{
				 fON_OFFsw = 0;
				 SwitchDelay = 20;
				}
			if (bSwitch == 0)
				{
				if (--SwitchDelay1 == 0)
					{
					fSwitch = 1;
					SwitchDelay1 = 10;
					}
				}
			else
				{
				 fSwitch = 0;
				 SwitchDelay1 = 10;
				}

            if (++rDelay100ms == 10)
                {
                if (++rDelay500ms == 5)
                	{
                	 rDelay500ms = 0;
                	 fSecond = !fSecond;
                	}
                AutolineDelay --;
                rDelay100ms = 0;     // delay 100ms section
                DelayN100ms --;
                Alarm_delay --;
				fWriteAnalog = 1;
                if (Button_delay != 0) Button_delay --;
                }
            if (++rDelay1s == 100)
                {
                rDelay1s = 0;     // make 1s RTC  , delay 1s section
                if (DispEqDelay != 0)
                    {
                	if (--DispEqDelay==0)
                        {
                        rSelectMode = 0;  // out off change (blink) mode
                        //rDelay_blink = 10;
                        #asm("cli")
                        eeBass = Bass_value;
                        eeTreble = Treble_value;
                        eeVolume = Volume_value;
                        #asm("sei")
                        }
                	}
				Connectimeout --;
                if (++currenttime.second >= 60)
                    {
                       currenttime.second = 0;
                    if (++currenttime.minute >= 60)
                        {
                        currenttime.minute = 0;
                        if (++currenttime.hour >= 24)
                            {
                            currenttime.hour = 0;
                            if (++currenttime.day == 9)
                                {
                                currenttime.day = 2;
                                currenttime.week++;
                                }
                            }
                        }
                    }	// end of RTC time-day process
                }
            } // end of 10ms condition (realtime clock)

/////////////////////////////////////////////////////////////
// running flash segment LED
/////////////////////////////////////////////////////////////

       if (rDelay1s < 20)
            {
            if (fVolume_blink) fVolume_AND = 0;
            if (fBass_blink) fBass_AND = 0;
            if (fTreble_blink) fTreble_AND = 0;
            }
       else if (rDelay1s < 50)
            {
            fVolume_AND = 1;
            fBass_AND = 1;
            fTreble_AND = 1;
            }
       else if (rDelay1s < 70)
            {
            if (fVolume_blink) fVolume_AND = 0;
            if (fBass_blink) fBass_AND = 0;
            if (fTreble_blink) fTreble_AND = 0;
            }
       else
            {
            fVolume_AND = 1;
            fBass_AND = 1;
            fTreble_AND = 1;
            }

/////////////////////////////////////////////////////////////
// System process, from read input to output LED
/////////////////////////////////////////////////////////////
      ///////////////////////////////////////
      // FixAdd is calculated by:
      // Floor 0: from 1  to 20
      // Floor 1: from 21 to 40
      // Floor 2: from 41 to 60
      // Floor 3: from 61 to 80
      // Floor 4: from 81 to 100
      // Floor 5: from 101 to 120
      ///////////////////////////////////////
      ///////////////////////////////////////

      if (fSwitch)
        {
        DispEqDelay = 5;       //reset to display Equalizer
        if (Button_delay == 0)
        	{
    		Button_delay = 250;
        	if (LimitMode != 0)
        		{
        		 LimitMode = 0;
        		 break;
        		}
        	if ((Volume_value < 6)  && (Treble_value < 10) && (Bass_value < 2))
//        	if ((Volume_value < 6))
        		{
        		 FixAdd = (Volume_value*20 + Bass_value*10 + Treble_value);
                 #asm("cli")
               	 eeFixAdd = FixAdd;
               	 eeFixAdd_ = ~FixAdd;
                 #asm("sei")
        		 Volume_value = 5;
        		 Bass_value = 5;
        		 Treble_value = 5;
        		}
        	else
        		{
        	    switch (Volume_value)
        	    	{
        	    	case 6:
        			if ((Treble_value == 6) && (Bass_value == 6))
        	    		{
               	 		Volume_value = FixAdd / 20;
               	 		Bass_value = FixAdd % 20;
               	 		Treble_value = Bass_value % 10;
               	 		Bass_value = Bass_value / 10;
        	    		}
        	  		else
        	  			{
	        		 	Volume_value = 2;
    	    		 	Bass_value = 2;
        			 	Treble_value = 2;
        	  			}
        	    	break;
        	    	case 7:                   //7-x-x
	               	 Volume_value = Config;
    	           	 Bass_value = AnalogControl;
        	       	 Treble_value = LimitVolLo;
        	    	break;
        	    	case 8:
        			if (Bass_value == 8)
        	    		{
               			Volume_value = 5;
               			Bass_value = 5;
               			switch (Treble_value)
               				{
               				case 0:
			            	AnalogControl |= BITMICRO;
            				break;
            				case 1:
			            	AnalogControl |= BITANALOG1;
            				break;
            				case 2:
			            	AnalogControl |= BITANALOG2;
            				break;
            				case 3:
			            	AnalogControl |= BITANALOG3;
            				break;
            				case 4:
			            	AnalogControl |= BITANALOG4;
            				break;
               				case 5:
			            	AnalogControl &= (~BITMICRO);
            				break;
            				case 6:
			            	AnalogControl &= (~BITANALOG1);
            				break;
            				case 7:
			            	AnalogControl &= (~BITANALOG2);
            				break;
            				case 8:
			            	AnalogControl &= (~BITANALOG3);
            				break;
            				case 9:
			            	AnalogControl &= (~BITANALOG4);
            				break;
            				default:
			            	AnalogControl |= BITMICRO;
            				}
            			eeAnalogControl = AnalogControl;
            			Treble_value = 7;
          	    		}
        			else if (Bass_value == 7)
        				{
               			Volume_value = 4;
               			Bass_value = 4;
        				fAutoGain = 1;
        				#asm("cli")
        				eefAutoGain = 1;
        				#asm("sei")
        				}
        			else if (Bass_value == 6)
        				{
               			Volume_value = 3;
               			Bass_value = 3;
        				fAutoGain = 0;
        				fLightTest = 0;
        				#asm("cli")
        				eefAutoGain = 0;
        				#asm("sei")
        				}
        			else if (Bass_value == 5)
        				{
        				fLightTest = 1;
               			Volume_value = 3;
               			Bass_value = 3;
               			Treble_value = 3;
        				}
        			else if (Bass_value == 4)
        				{
        				if (Treble_value == 0)
        					{
        					 Config &= (~AUTO_OFF);
        					 Config &= (~AUTO_RESTORE);
        					 Config |= AUTO_ON_MIC;
        					 eeConfig = Config;
	        				 Volume_value = 5;
    	    				 Bass_value = 5;
        					 Treble_value = 7;
        					}
        				else if (Treble_value == 1)
        					{
        					 Config |= (AUTO_OFF);
        					 Config &= (~AUTO_RESTORE);
        					 Config &= (~AUTO_ON_MIC);
        					 eeConfig = Config;
	        				 Volume_value = 5;
    	    				 Bass_value = 5;
        					 Treble_value = 7;
        					}
        				else if (Treble_value == 2)
        					{
        					 Config &= (~AUTO_OFF);
        					 Config |= (AUTO_RESTORE);
        					 Config &= (~AUTO_ON_MIC);
        					 eeConfig = Config;
	        				 Volume_value = 5;
    	    				 Bass_value = 5;
        					 Treble_value = 7;
        					}
        				else
        					{
	        				 Volume_value = 1;
    	    				 Bass_value = 1;
        					 Treble_value = 1;
        					}
        				}
        			else
        				{
        				 Volume_value = 1;
        				 Bass_value = 1;
        				 Treble_value = 1;
        				}
        	    	break;
        	    	default:
        		 	Volume_value = 1;
        		 	Bass_value = 1;
        		 	Treble_value = 1;
        	    	}
        		}
/*        	else if ((Volume_value == 7)  && (Treble_value == 7) && (Bass_value == 7))
        	    {
               	 Volume_value = Config;
               	 Bass_value = LimitVolHi;
               	 Treble_value = LimitVolLo;
        	    }*/
        	}
        }
      else
       	{
       	 Button_delay  = 50;
       	}

      if (fON_OFFsw)
       	{
       	fON_OFFsw = 0;
       	fON_OFF = !fON_OFF;
        #asm("cli")
        eefON_OFF = fON_OFF;
        #asm("sei")
        if (fON_OFF) AnalogControl |= BITMICRO;
       	}

      ///////////////////////////////////////
      ///////////////////////////////////////


		if (fON_OFF)                   //system is ON
            {
            fLedGreen = 1;
            bONpower = 1;
            //process for display time OR Equalizer
            fEncodeSedge = fEncodeSold &&(!EncodeS);	//falling edge
            fEncodeSold = EncodeS;
            if (fSwitch && (!fSwitchOld))
             	{
             	 if (++EqMc == 4) EqMc = 0;
             	}
            if (fEncodeSedge)			// falling edge of clock
            	{
            	DispEqDelay = 10;       //reset to display Equalizer
            	}
            if (DispEqDelay == 0)		// display time
            	{
           		 fVolume_blink = 0;
           		 fBass_blink = 0;
           		 fTreble_blink = 0;
				 Display[0] = currenttime.second % 10;
     			 Display[1] = (currenttime.second) / 10;
     			 Display[2] = currenttime.minute % 10;
     			 Display[3] = currenttime.minute / 10;
     			 Display[4] = currenttime.hour % 10;
     			 Display[5] = currenttime.hour / 10;
     			 EqMc = 0;
            	}
            else        				//Display Equalizer
            	{
            	fSecond = 0;
				 Display[0] = Treble_value % 10;
     			 Display[1] = Treble_value / 10;
     			 Display[2] = Bass_value % 10;
     			 Display[3] = Bass_value / 10;
     			 Display[4] = Volume_value % 10;
     			 Display[5] = Volume_value / 10;
            	switch (EqMc)
            		{
            		 case 0:     		//no change
            		 fVolume_blink = 0;
            		 fBass_blink = 0;
            		 fTreble_blink = 0;
            		 if (fEncodeSedge) EqMc = 1;
            		 break;
            		 case 1:     		//volume
            		 fVolume_blink = 1;
            		 fBass_blink = 0;
            		 fTreble_blink = 0;
            		 if (LimitMode == 3) break;     // fix all value
            		 if (fEncodeSedge) Volume_value += (EncodeC ? -1 : 1);
            		 if (Volume_value == 100) Volume_value = 99;
            		 if (Volume_value > 100)  Volume_value = 0;
           		     if (LimitMode == 1)	// limit volume at high level
      					{
      	 				if (Volume_value > LimitVolHi) Volume_value = LimitVolHi;
      					}
      			     else if (LimitMode == 2) // limit volume at high & Low level
      					{
      	 				if (Volume_value > LimitVolHi) Volume_value = LimitVolHi;
      	 				if (Volume_value < LimitVolLo) Volume_value = LimitVolLo;
      					}
            		 break;
            		 case 2:            // Bass
            		 fVolume_blink = 0;
            		 fBass_blink = 1;
            		 fTreble_blink = 0;
            		 if ((LimitMode == 3) || (LimitMode == 4)) break; 	// fix all & eq
            		 if (fEncodeSedge) Bass_value += (EncodeC ? -1 : 1);
            		 if (Bass_value == 100) Bass_value = 99;
            		 if (Bass_value > 100)  Bass_value = 0;
            		 break;
            		 case 3:			// Trebles
            		 fVolume_blink = 0;
            		 fBass_blink = 0;
            		 fTreble_blink = 1;
            		 if ((LimitMode == 3) || (LimitMode == 4)) break;
            		 if (fEncodeSedge) Treble_value += (EncodeC ? -1 : 1);
            		 if (Treble_value == 100) Treble_value = 99;
            		 if (Treble_value > 100)  Treble_value = 0;
            		 break;
            		 default:
            		 EqMc = 0;
            		}

            	}
//            if (fEncodeSedge && EncodeC) Kount --;      // counter clockwise rotation
//            if (fEncodeSedge && (!EncodeC)) Kount ++;	// clockwise rotation

            }
  		else						// System is OFF
  			{
  			bONpower = 0;
  			fLedGreen = 0; 			//turnoff the display
            fVolume_AND = 0;
            fBass_AND = 0;
            fTreble_AND = 0;
            fSecond = 0;
			// auto gain control test
			if (fLightTest)
				{
	 			temp = (char) (vAdcVoice >> 2);
	 			Display[2] = temp / 100;
	 			Display[1] = (temp % 100) / 10;
	 			Display[0] = temp % 10;
	 			temp = (char) (vAdcLight >> 2);
	 			Display[5] = temp / 100;
	 			Display[4] = (temp % 100) / 10;
	 			Display[3] = temp % 10;
            	fVolume_AND = 1;
            	fBass_AND = 1;
            	fTreble_AND = 1;
				}
            }
	fSwitchOld = fSwitch;

      ///////////////////////////////////////
      ///////////////////////////////////////

      ///////////////////////////////////////
      // process Bell of PINGPONG sound
      ///////////////////////////////////////

       switch (Bell_Mc)
         {
          case 0:
          fBell_en = 0;
          break;
          case 1:
//          if (fPingPong)
            {
            fBackup = fON_OFF;
            fON_OFF = 1;
            fBell_en = 0;
            Volume_bk = Volume_value;
            Bass_bk = Bass_value;
            Treble_bk = Treble_value;
            Volume_value = BellVolume;
            Bass_value = 3;
            Treble_value = 3;
//            ChanelA = BELL2 | CHANEL_ON | CHANELA;
//            analog_ctr(ChanelA);
//            ChanelB = BELL2 | CHANEL_ON | CHANELB;
//            analog_ctr(ChanelB);
			AnalogControl |= BITBELL;
            Bell_Mc = 2;
            Bell_freq = 6;
            Bell_delay = 100;
            }
          break;
          case 2:       // end of init time
          if (Bell_delay == 0)
            {
             fBell_en = 1;
             Bell_delay = 50;
             Bell_freq = 6;
             Bell_Mc = 3;
            }
          break;
          case 3:       // end of ping
          if (Bell_delay == 0)
            {
             Bell_delay = 56;
             Bell_freq = 8;
             Bell_Mc = 4;
            }
          break;
          case 4:          //end of pong
          if (Bell_delay == 0)
            {
             Bell_delay = 70;
             Bell_freq = 6;
             fBell_en = 0;
             Bell_Mc = 5;
            }
          break;
          case 5:          //end of stop time
          if (Bell_delay == 0)
            {
             Bell_delay = 50;
             Bell_freq = 6;
             fBell_en = 1;
             Bell_Mc = 6;
            }
          break;
          case 6:          //end of ping
          if (Bell_delay == 0)
            {
             Bell_delay = 56;
             Bell_freq = 8;
             Bell_Mc = 7;
            }
          break;
          case 7:          //end of pong
          if (Bell_delay == 0)
            {
             Bell_delay = 50;
             Bell_freq = 6;
             fBell_en = 0;
             fPingPong = 0;
             Bell_Mc = 8;
            }
          break;
          case 8:          //end of stop time
          if (Bell_delay == 0)
            {
            Bell_Mc = 0;
            Volume_value = Volume_bk;
            Bass_value = Bass_bk;
            Treble_value = Treble_bk;
//            ChanelA = BELL2 | CHANEL_OFF | CHANELA;
//            analog_ctr(ChanelA);
//            ChanelB = BELL2 | CHANEL_OFF | CHANELB;
//            analog_ctr(ChanelB);
			AnalogControl &= (~BITBELL);
            fON_OFF = fBackup;
            }
          break;
          default:
          Bell_Mc = 0;
          }
      ///////////////////////////////////////
      ///////////////////////////////////////
       switch (Blink_Mc)
         {
          case 0:
          if (fBlinkRED)
            {
            Blink_Mc = 1;
            fBlinkRED = 0;
            }
          break;
          case 1:
          fLedRed = 1;
          Blink_Mc = 2;
          Blink_delay = 10;    //200ms
          break;
          case 2:
          if (Blink_delay == 0)
            {
             fLedRed = 0;
             Blink_delay = 60;    //600ms
             Blink_Mc = 3;
            }
          break;
          case 3:
          if (Blink_delay == 0)
            {
             Blink_Mc = 0;
            }
          break;
          default:
          Blink_Mc = 0;
          }

///////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////
      ///////////////////////////////////////
      // process for RS485 Line select
      ///////////////////////////////////////
      //running auto line select mode if enable
      if (Config & CHANEL_AUTO)
		{
		if (fRx_receive) AutolineDelay = 100;
      	switch (AutoLine_Mc)
      		{
      		 case 0:		// load backup value
      		 #asm("cli")
      		 temp = eeAutoline_bk;
      		 #asm("sei")
      		 Loadreg |=  (CS_LINE1_ | CS_LINE2_);    //off 2 chanel
      		 Loadreg &= (temp | (~CS_LINE12_));
      		 AutolineDelay = 100;
      		 AutoLine_Mc ++;
      		 if (temp == ~CS_LINE12_)   // if 2 line connected, run Line 1
      		 	{
      		 	 Loadreg |= CS_LINE1_;
      		 	 Loadreg &= ~CS_LINE2_;
      		 	 }
      		 break;
      		 case 1:
      		 if (AutolineDelay == 0)	// no network detected  run line1
      		 	{
      		 	 Loadreg |= CS_LINE2_;
      		 	 Loadreg &= ~CS_LINE1_;
	      		 AutolineDelay = 100;
	      		 AutoLine_Mc ++;
	      		 #asm("cli")
	      		 eeAutoline_bk = ~CS_LINE1_;
	      		 #asm("sei")
      		 	}
      		 break;
      		 case 2:
      		 if (AutolineDelay == 0)	// no network detected  run line2
      		 	{
      		 	 Loadreg |= CS_LINE1_;
      		 	 Loadreg &= ~CS_LINE2_;
	      		 AutolineDelay = 100;
	      		 AutoLine_Mc = 1;
	      		 #asm("cli")
	      		 eeAutoline_bk = ~CS_LINE2_;
	      		 #asm("sei")
      		 	}
      		 break;
      		 default:
      		 AutoLine_Mc = 0;
      		}
      	}
  	else
  		{
  		 if ((Config & 0x03) == CHANEL_1)
  		 	{
  		 	 Loadreg &= ~CS_LINE1_;
  		 	 Loadreg |= CS_LINE2_;
  		 	}
  		 else if ((Config & 0x03) == CHANEL_2)
  		 	{
  		 	 Loadreg &= ~CS_LINE2_;
  		 	 Loadreg |= CS_LINE1_;
  		 	}
  		 else
  		 	{
  		 	 Loadreg &= ~CS_LINE1_;		// default using Line 1
  		 	 Loadreg |= CS_LINE2_;
  		 	}
  		}
	 Loadreg |= CS_LINE2_;
	 Loadreg &= ~CS_LINE1_;     // forced to line 1

  ///////////////////////////////////////////////////////////////////////

  //           #asm ("cli")
        if (RxDelay == 0)                   // reset the Rx state machine
            {
             Rx_Mc = 0;
             RxDelay --;
   //          UCSRA |= BIT0;                 // turn on address mode
            }
   //          #asm ("sei")
        if (fRx_receive)
            {
             if ((rx_buffer_out[0] != 0xFF) && (Config & ACK_ENABLE)) fSendACK = 1;
             fRx_receive = 0;               // process for RX data
             i = rx_buffer_out[1];
             fBlinkRED = 1;
             switch (i)  // process for command from master
                    {
                     case vSYNC:
                     break;
                     case vBELL_ON:
                     Bell_Mc = 1;
                     break;
                     case vALARM_ON:
                     break;
                     case vALARM_HALF:
                     break;
                     case vALARM_ONE:
                     break;
                     case vALARM_BELL_ON:
                     Bell_Mc = 1;
                     Alarm_Mc = 1;
                     AlarmByte[0] = rx_buffer_out[2]; // ON time Nx100ms
                     AlarmByte[1] = rx_buffer_out[3]; // OFF time
                     AlarmByte[2] = rx_buffer_out[4]; // ON time
                     AlarmByte[3] = rx_buffer_out[5]; // OFF time
                     AlarmByte[4] = rx_buffer_out[6]; // OFF time
                     break;
                     case vUPDATE_TIME:
                     currenttime.second = rx_buffer_out[2]; // ON time Nx100ms
                     currenttime.minute = rx_buffer_out[3]; // OFF time
                     currenttime.hour   = rx_buffer_out[4]; // ON time
                     currenttime.day    = rx_buffer_out[5]; // OFF time
                     currenttime.week   = rx_buffer_out[6]; // OFF time
                     break;
                     case vUPDATE_ADDR:
//                      if (rx_buffer_out[0] == 0xFF) break;
//                      FixAdd = rx_buffer_out[2];
// 	      		     #asm("cli")
//                    	 eeFixAdd = FixAdd;
//                    	 eeFixAdd_ = ~FixAdd;
// 	      		     #asm("sei")
                     break;
                     case vCONFIG:    // config: auto power on Mode, line select mode, line select chanel
	      		     #asm("cli")
                     eeConfig = rx_buffer_out[2];  	// BIT7: fACK_en, BIT6: AutoMIC, BIT5: AUTO_OFF, BIT4: LAST state
                     Config = rx_buffer_out[2];        // Line select: BIT3 = 1: auto select, = 0: manual with BIT1:0- 2 relay control
                     BellVolume = rx_buffer_out[3];
                     eeBellVolume = rx_buffer_out[3];
	      		     #asm("sei")
                     break;
                     case vON_DEVICE:
                     if (!fON_OFF)
                     fON_OFF = 1;
	      		     #asm("cli")
                     eefON_OFF = 1;
	      		     #asm("sei")
                     break;
                     case vOFF_DEVICE:
                   	 fON_OFF = 0;
	      		     #asm("cli")
                   	 eefON_OFF = 0;
	      		     #asm("sei")
                     break;
                     case vUPDATE_AMPLI:
	      		     #asm("cli")
	      		     DispEqDelay = 10;
                     eeVolume = rx_buffer_out[2];
                     eeBass = rx_buffer_out[3];
                     eeTreble = rx_buffer_out[4];
                     LimitMode = rx_buffer_out[5];     	// limit mode = 0: no limit, = 1: limit high, = 2 limit LO & HI
                     eeLimitMode = LimitMode;  			// = 3: FIX value ON ampli, = 4: FIX BASS-TREBLE only
                     LimitVolHi = rx_buffer_out[6];
                     eeLimitVolHi = LimitVolHi;
                     LimitVolLo = 0;
                     eeLimitVolLo = LimitVolLo;
	      		     #asm("sei")
                     if (fON_OFF)
                     	{
                     	Volume_value = rx_buffer_out[2];
                     	Bass_value = rx_buffer_out[3];
                     	Treble_value = rx_buffer_out[4];
                     	}
                     Volume_bk = rx_buffer_out[2];
                     Bass_bk   = rx_buffer_out[3];
                     Treble_bk = rx_buffer_out[4];
                     break;
                     case vANALOG_SELECT:
                     AnalogControl = rx_buffer_out[2];
	      		     fAutoGain = rx_buffer_out[3];
	      		     SoundLevel = rx_buffer_out[4];
	      		     #asm("cli")
	      		     eefAutoGain = fAutoGain;
                     eeAnalogControl = AnalogControl;
                     eeSoundLevel = SoundLevel;
	      		     #asm("sei")
//                     ChanelA = rx_buffer_out[2];
//                     ChanelB = rx_buffer_out[3];
//                     eeChanelA = ChanelA;
//                     eeChanelB = ChanelB;
                     break;
                     case vREAD_STATUS:
                     fSendACK = 0;
                     if (rx_buffer_out[0] != 0xFF)      //return data
                     	{
                     	 fSendStatus = 1;
                     // send tx_counter + 1 byte including CRC, no trailing address
                     	}
                     else
                     	{
                         DispEqDelay = 10;
                     	 Volume_value = FixAdd / 20;
                     	 Bass_value = FixAdd % 20;
                     	 Treble_value = Bass_value % 10;
                     	 Bass_value = Bass_value / 10;
                     	}
                     break;
                     case vREAD_SENSOR:
                     status_AND = 0;
                     fSendSense = 1;
                     fSendACK = 0;
                     break;
                     default:
                    }        // end of switch
            }    // end of fRxReceive
		if (!(fSendACK || fSendStatus || fSendSense)) SendDelay = 200;	// 20ms delay
		if (fSendSense  && (SendDelay == 0))
			{
			 fSendSense = 0;
         	 fSendStatus = 0;
        	 SendDelay = 200;
             tx_buffer[0] = FixAdd;
             tx_buffer[1] = (unsigned char)(vAdcLight >> 8);
             tx_buffer[2] = (unsigned char)(vAdcLight & 0xFF);
             tx_buffer[3] = (unsigned char)(vAdcVoice >> 8);
             tx_buffer[4] = (unsigned char)(vAdcVoice & 0xFF);
             tx_buffer[5] = (unsigned char)(vAdcAlum >> 8);
             tx_buffer[6] = (unsigned char)(vAdcAlum & 0xFF);
             tx_counter = 7;
             SendBuffer();
          	 status_AND = 0xFF;
			}
  		if (fSendStatus && (SendDelay == 0))
         	{
        	 fSendACK = 0;
        	 SendDelay = 200;
         	 fSendStatus = 0;
             tx_buffer[0] = FixAdd;
             if (fON_OFF)
                {
                tx_buffer[2] = Volume_value;
                tx_buffer[3] = Bass_value;
                tx_buffer[4] = Treble_value;
                }
             else
             	{
                 tx_buffer[2] = Volume_bk;
                 tx_buffer[3] = Bass_bk;
                 tx_buffer[4] = Treble_bk;
              	}
             tx_buffer[5] = Config;
             tx_buffer[1] = (LimitMode << 4);		// limit mode and fON_OFF
             if (fON_OFF) tx_buffer[1] |= 0x80;
             tx_buffer[6] = LimitVolHi;
//             tx_buffer[5] = ChanelA;
//             tx_buffer[6] = ChanelB;
             tx_counter = 7; // send tx_counter + 1 byte
             SendBuffer();
// buff(0): address of device
// buff(1): bit7: fON_OFF, bit 6,5,4: limit mode, bit3:0 - none
// buff(2): volume
// buff(3): bass
// buff(4): treble
// buff(5): config BIT7: fACK_en, BIT6:4 auto startup option
			//Line select: BIT3 = 1: auto select, = 0: manual with BIT1:0- 2 relay control
// buff(6): limit vol Hi and Limit vol Lo
            }
		if (fSendACK && (SendDelay == 0))
        	{
        	SendDelay = 100;
        	fSendACK = 0;
            SendACK();
            }
      ///////////////////////////////////////
////////////////////////////////////////////////////////////
      /////////////////////////////////////
      /////////////////////////////////////
      #asm("WDR")
      outled();
      switch (ADC_MC)
        {
        case ADC_LIGHT:
        vAdcLight = read_adc(ADC_MC);
        ADC_MC = ADC_VOICE;
        break;
        case ADC_VOICE:
        vAdcVoice = read_adc(ADC_MC);

        ADC_MC = ADC_ROOM;
        break;
        case ADC_ROOM:
        vAdcRoom = read_adc(ADC_MC);

        ADC_MC = ADC_ALUM;
        break;
        case ADC_ALUM:
        vAdcAlum = read_adc(ADC_MC);

        ADC_MC = ADC_LIGHT;
        break;
        default:
        ADC_MC = ADC_LIGHT;
        }
      };
}
