
;CodeVisionAVR C Compiler V3.12 Advanced
;(C) Copyright 1998-2014 Pavel Haiduc, HP InfoTech s.r.l.
;http://www.hpinfotech.com

;Build configuration    : Release
;Chip type              : ATmega8
;Program type           : Application
;Clock frequency        : 8.000000 MHz
;Memory model           : Small
;Optimize for           : Size
;(s)printf features     : int, width
;(s)scanf features      : int, width
;External RAM size      : 0
;Data Stack size        : 256 byte(s)
;Heap size              : 0 byte(s)
;Promote 'char' to 'int': No
;'char' is unsigned     : Yes
;8 bit enums            : Yes
;Global 'const' stored in FLASH: No
;Enhanced function parameter passing: Yes
;Enhanced core instructions: On
;Automatic register allocation for global variables: On
;Smart register allocation: On

	#define _MODEL_SMALL_

	#pragma AVRPART ADMIN PART_NAME ATmega8
	#pragma AVRPART MEMORY PROG_FLASH 8192
	#pragma AVRPART MEMORY EEPROM 512
	#pragma AVRPART MEMORY INT_SRAM SIZE 1024
	#pragma AVRPART MEMORY INT_SRAM START_ADDR 0x60

	.LISTMAC
	.EQU UDRE=0x5
	.EQU RXC=0x7
	.EQU USR=0xB
	.EQU UDR=0xC
	.EQU SPSR=0xE
	.EQU SPDR=0xF
	.EQU EERE=0x0
	.EQU EEWE=0x1
	.EQU EEMWE=0x2
	.EQU EECR=0x1C
	.EQU EEDR=0x1D
	.EQU EEARL=0x1E
	.EQU EEARH=0x1F
	.EQU WDTCR=0x21
	.EQU MCUCR=0x35
	.EQU GICR=0x3B
	.EQU SPL=0x3D
	.EQU SPH=0x3E
	.EQU SREG=0x3F

	.DEF R0X0=R0
	.DEF R0X1=R1
	.DEF R0X2=R2
	.DEF R0X3=R3
	.DEF R0X4=R4
	.DEF R0X5=R5
	.DEF R0X6=R6
	.DEF R0X7=R7
	.DEF R0X8=R8
	.DEF R0X9=R9
	.DEF R0XA=R10
	.DEF R0XB=R11
	.DEF R0XC=R12
	.DEF R0XD=R13
	.DEF R0XE=R14
	.DEF R0XF=R15
	.DEF R0X10=R16
	.DEF R0X11=R17
	.DEF R0X12=R18
	.DEF R0X13=R19
	.DEF R0X14=R20
	.DEF R0X15=R21
	.DEF R0X16=R22
	.DEF R0X17=R23
	.DEF R0X18=R24
	.DEF R0X19=R25
	.DEF R0X1A=R26
	.DEF R0X1B=R27
	.DEF R0X1C=R28
	.DEF R0X1D=R29
	.DEF R0X1E=R30
	.DEF R0X1F=R31

	.EQU __SRAM_START=0x0060
	.EQU __SRAM_END=0x045F
	.EQU __DSTACK_SIZE=0x0100
	.EQU __HEAP_SIZE=0x0000
	.EQU __CLEAR_SRAM_SIZE=__SRAM_END-__SRAM_START+1

	.MACRO __CPD1N
	CPI  R30,LOW(@0)
	LDI  R26,HIGH(@0)
	CPC  R31,R26
	LDI  R26,BYTE3(@0)
	CPC  R22,R26
	LDI  R26,BYTE4(@0)
	CPC  R23,R26
	.ENDM

	.MACRO __CPD2N
	CPI  R26,LOW(@0)
	LDI  R30,HIGH(@0)
	CPC  R27,R30
	LDI  R30,BYTE3(@0)
	CPC  R24,R30
	LDI  R30,BYTE4(@0)
	CPC  R25,R30
	.ENDM

	.MACRO __CPWRR
	CP   R@0,R@2
	CPC  R@1,R@3
	.ENDM

	.MACRO __CPWRN
	CPI  R@0,LOW(@2)
	LDI  R30,HIGH(@2)
	CPC  R@1,R30
	.ENDM

	.MACRO __ADDB1MN
	SUBI R30,LOW(-@0-(@1))
	.ENDM

	.MACRO __ADDB2MN
	SUBI R26,LOW(-@0-(@1))
	.ENDM

	.MACRO __ADDW1MN
	SUBI R30,LOW(-@0-(@1))
	SBCI R31,HIGH(-@0-(@1))
	.ENDM

	.MACRO __ADDW2MN
	SUBI R26,LOW(-@0-(@1))
	SBCI R27,HIGH(-@0-(@1))
	.ENDM

	.MACRO __ADDW1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	.ENDM

	.MACRO __ADDD1FN
	SUBI R30,LOW(-2*@0-(@1))
	SBCI R31,HIGH(-2*@0-(@1))
	SBCI R22,BYTE3(-2*@0-(@1))
	.ENDM

	.MACRO __ADDD1N
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	SBCI R22,BYTE3(-@0)
	SBCI R23,BYTE4(-@0)
	.ENDM

	.MACRO __ADDD2N
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	SBCI R24,BYTE3(-@0)
	SBCI R25,BYTE4(-@0)
	.ENDM

	.MACRO __SUBD1N
	SUBI R30,LOW(@0)
	SBCI R31,HIGH(@0)
	SBCI R22,BYTE3(@0)
	SBCI R23,BYTE4(@0)
	.ENDM

	.MACRO __SUBD2N
	SUBI R26,LOW(@0)
	SBCI R27,HIGH(@0)
	SBCI R24,BYTE3(@0)
	SBCI R25,BYTE4(@0)
	.ENDM

	.MACRO __ANDBMNN
	LDS  R30,@0+(@1)
	ANDI R30,LOW(@2)
	STS  @0+(@1),R30
	.ENDM

	.MACRO __ANDWMNN
	LDS  R30,@0+(@1)
	ANDI R30,LOW(@2)
	STS  @0+(@1),R30
	LDS  R30,@0+(@1)+1
	ANDI R30,HIGH(@2)
	STS  @0+(@1)+1,R30
	.ENDM

	.MACRO __ANDD1N
	ANDI R30,LOW(@0)
	ANDI R31,HIGH(@0)
	ANDI R22,BYTE3(@0)
	ANDI R23,BYTE4(@0)
	.ENDM

	.MACRO __ANDD2N
	ANDI R26,LOW(@0)
	ANDI R27,HIGH(@0)
	ANDI R24,BYTE3(@0)
	ANDI R25,BYTE4(@0)
	.ENDM

	.MACRO __ORBMNN
	LDS  R30,@0+(@1)
	ORI  R30,LOW(@2)
	STS  @0+(@1),R30
	.ENDM

	.MACRO __ORWMNN
	LDS  R30,@0+(@1)
	ORI  R30,LOW(@2)
	STS  @0+(@1),R30
	LDS  R30,@0+(@1)+1
	ORI  R30,HIGH(@2)
	STS  @0+(@1)+1,R30
	.ENDM

	.MACRO __ORD1N
	ORI  R30,LOW(@0)
	ORI  R31,HIGH(@0)
	ORI  R22,BYTE3(@0)
	ORI  R23,BYTE4(@0)
	.ENDM

	.MACRO __ORD2N
	ORI  R26,LOW(@0)
	ORI  R27,HIGH(@0)
	ORI  R24,BYTE3(@0)
	ORI  R25,BYTE4(@0)
	.ENDM

	.MACRO __DELAY_USB
	LDI  R24,LOW(@0)
__DELAY_USB_LOOP:
	DEC  R24
	BRNE __DELAY_USB_LOOP
	.ENDM

	.MACRO __DELAY_USW
	LDI  R24,LOW(@0)
	LDI  R25,HIGH(@0)
__DELAY_USW_LOOP:
	SBIW R24,1
	BRNE __DELAY_USW_LOOP
	.ENDM

	.MACRO __GETD1S
	LDD  R30,Y+@0
	LDD  R31,Y+@0+1
	LDD  R22,Y+@0+2
	LDD  R23,Y+@0+3
	.ENDM

	.MACRO __GETD2S
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	LDD  R24,Y+@0+2
	LDD  R25,Y+@0+3
	.ENDM

	.MACRO __PUTD1S
	STD  Y+@0,R30
	STD  Y+@0+1,R31
	STD  Y+@0+2,R22
	STD  Y+@0+3,R23
	.ENDM

	.MACRO __PUTD2S
	STD  Y+@0,R26
	STD  Y+@0+1,R27
	STD  Y+@0+2,R24
	STD  Y+@0+3,R25
	.ENDM

	.MACRO __PUTDZ2
	STD  Z+@0,R26
	STD  Z+@0+1,R27
	STD  Z+@0+2,R24
	STD  Z+@0+3,R25
	.ENDM

	.MACRO __CLRD1S
	STD  Y+@0,R30
	STD  Y+@0+1,R30
	STD  Y+@0+2,R30
	STD  Y+@0+3,R30
	.ENDM

	.MACRO __POINTB1MN
	LDI  R30,LOW(@0+(@1))
	.ENDM

	.MACRO __POINTW1MN
	LDI  R30,LOW(@0+(@1))
	LDI  R31,HIGH(@0+(@1))
	.ENDM

	.MACRO __POINTD1M
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __POINTW1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	.ENDM

	.MACRO __POINTD1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	LDI  R22,BYTE3(2*@0+(@1))
	LDI  R23,BYTE4(2*@0+(@1))
	.ENDM

	.MACRO __POINTB2MN
	LDI  R26,LOW(@0+(@1))
	.ENDM

	.MACRO __POINTW2MN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	.ENDM

	.MACRO __POINTW2FN
	LDI  R26,LOW(2*@0+(@1))
	LDI  R27,HIGH(2*@0+(@1))
	.ENDM

	.MACRO __POINTD2FN
	LDI  R26,LOW(2*@0+(@1))
	LDI  R27,HIGH(2*@0+(@1))
	LDI  R24,BYTE3(2*@0+(@1))
	LDI  R25,BYTE4(2*@0+(@1))
	.ENDM

	.MACRO __POINTBRM
	LDI  R@0,LOW(@1)
	.ENDM

	.MACRO __POINTWRM
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __POINTBRMN
	LDI  R@0,LOW(@1+(@2))
	.ENDM

	.MACRO __POINTWRMN
	LDI  R@0,LOW(@2+(@3))
	LDI  R@1,HIGH(@2+(@3))
	.ENDM

	.MACRO __POINTWRFN
	LDI  R@0,LOW(@2*2+(@3))
	LDI  R@1,HIGH(@2*2+(@3))
	.ENDM

	.MACRO __GETD1N
	LDI  R30,LOW(@0)
	LDI  R31,HIGH(@0)
	LDI  R22,BYTE3(@0)
	LDI  R23,BYTE4(@0)
	.ENDM

	.MACRO __GETD2N
	LDI  R26,LOW(@0)
	LDI  R27,HIGH(@0)
	LDI  R24,BYTE3(@0)
	LDI  R25,BYTE4(@0)
	.ENDM

	.MACRO __GETB1MN
	LDS  R30,@0+(@1)
	.ENDM

	.MACRO __GETB1HMN
	LDS  R31,@0+(@1)
	.ENDM

	.MACRO __GETW1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	.ENDM

	.MACRO __GETD1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	LDS  R22,@0+(@1)+2
	LDS  R23,@0+(@1)+3
	.ENDM

	.MACRO __GETBRMN
	LDS  R@0,@1+(@2)
	.ENDM

	.MACRO __GETWRMN
	LDS  R@0,@2+(@3)
	LDS  R@1,@2+(@3)+1
	.ENDM

	.MACRO __GETWRZ
	LDD  R@0,Z+@2
	LDD  R@1,Z+@2+1
	.ENDM

	.MACRO __GETD2Z
	LDD  R26,Z+@0
	LDD  R27,Z+@0+1
	LDD  R24,Z+@0+2
	LDD  R25,Z+@0+3
	.ENDM

	.MACRO __GETB2MN
	LDS  R26,@0+(@1)
	.ENDM

	.MACRO __GETW2MN
	LDS  R26,@0+(@1)
	LDS  R27,@0+(@1)+1
	.ENDM

	.MACRO __GETD2MN
	LDS  R26,@0+(@1)
	LDS  R27,@0+(@1)+1
	LDS  R24,@0+(@1)+2
	LDS  R25,@0+(@1)+3
	.ENDM

	.MACRO __PUTB1MN
	STS  @0+(@1),R30
	.ENDM

	.MACRO __PUTW1MN
	STS  @0+(@1),R30
	STS  @0+(@1)+1,R31
	.ENDM

	.MACRO __PUTD1MN
	STS  @0+(@1),R30
	STS  @0+(@1)+1,R31
	STS  @0+(@1)+2,R22
	STS  @0+(@1)+3,R23
	.ENDM

	.MACRO __PUTB1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	RCALL __EEPROMWRB
	.ENDM

	.MACRO __PUTW1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	RCALL __EEPROMWRW
	.ENDM

	.MACRO __PUTD1EN
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	RCALL __EEPROMWRD
	.ENDM

	.MACRO __PUTBR0MN
	STS  @0+(@1),R0
	.ENDM

	.MACRO __PUTBMRN
	STS  @0+(@1),R@2
	.ENDM

	.MACRO __PUTWMRN
	STS  @0+(@1),R@2
	STS  @0+(@1)+1,R@3
	.ENDM

	.MACRO __PUTBZR
	STD  Z+@1,R@0
	.ENDM

	.MACRO __PUTWZR
	STD  Z+@2,R@0
	STD  Z+@2+1,R@1
	.ENDM

	.MACRO __GETW1R
	MOV  R30,R@0
	MOV  R31,R@1
	.ENDM

	.MACRO __GETW2R
	MOV  R26,R@0
	MOV  R27,R@1
	.ENDM

	.MACRO __GETWRN
	LDI  R@0,LOW(@2)
	LDI  R@1,HIGH(@2)
	.ENDM

	.MACRO __PUTW1R
	MOV  R@0,R30
	MOV  R@1,R31
	.ENDM

	.MACRO __PUTW2R
	MOV  R@0,R26
	MOV  R@1,R27
	.ENDM

	.MACRO __ADDWRN
	SUBI R@0,LOW(-@2)
	SBCI R@1,HIGH(-@2)
	.ENDM

	.MACRO __ADDWRR
	ADD  R@0,R@2
	ADC  R@1,R@3
	.ENDM

	.MACRO __SUBWRN
	SUBI R@0,LOW(@2)
	SBCI R@1,HIGH(@2)
	.ENDM

	.MACRO __SUBWRR
	SUB  R@0,R@2
	SBC  R@1,R@3
	.ENDM

	.MACRO __ANDWRN
	ANDI R@0,LOW(@2)
	ANDI R@1,HIGH(@2)
	.ENDM

	.MACRO __ANDWRR
	AND  R@0,R@2
	AND  R@1,R@3
	.ENDM

	.MACRO __ORWRN
	ORI  R@0,LOW(@2)
	ORI  R@1,HIGH(@2)
	.ENDM

	.MACRO __ORWRR
	OR   R@0,R@2
	OR   R@1,R@3
	.ENDM

	.MACRO __EORWRR
	EOR  R@0,R@2
	EOR  R@1,R@3
	.ENDM

	.MACRO __GETWRS
	LDD  R@0,Y+@2
	LDD  R@1,Y+@2+1
	.ENDM

	.MACRO __PUTBSR
	STD  Y+@1,R@0
	.ENDM

	.MACRO __PUTWSR
	STD  Y+@2,R@0
	STD  Y+@2+1,R@1
	.ENDM

	.MACRO __MOVEWRR
	MOV  R@0,R@2
	MOV  R@1,R@3
	.ENDM

	.MACRO __INWR
	IN   R@0,@2
	IN   R@1,@2+1
	.ENDM

	.MACRO __OUTWR
	OUT  @2+1,R@1
	OUT  @2,R@0
	.ENDM

	.MACRO __CALL1MN
	LDS  R30,@0+(@1)
	LDS  R31,@0+(@1)+1
	ICALL
	.ENDM

	.MACRO __CALL1FN
	LDI  R30,LOW(2*@0+(@1))
	LDI  R31,HIGH(2*@0+(@1))
	RCALL __GETW1PF
	ICALL
	.ENDM

	.MACRO __CALL2EN
	PUSH R26
	PUSH R27
	LDI  R26,LOW(@0+(@1))
	LDI  R27,HIGH(@0+(@1))
	RCALL __EEPROMRDW
	POP  R27
	POP  R26
	ICALL
	.ENDM

	.MACRO __CALL2EX
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	RCALL __EEPROMRDD
	ICALL
	.ENDM

	.MACRO __GETW1STACK
	IN   R30,SPL
	IN   R31,SPH
	ADIW R30,@0+1
	LD   R0,Z+
	LD   R31,Z
	MOV  R30,R0
	.ENDM

	.MACRO __GETD1STACK
	IN   R30,SPL
	IN   R31,SPH
	ADIW R30,@0+1
	LD   R0,Z+
	LD   R1,Z+
	LD   R22,Z
	MOVW R30,R0
	.ENDM

	.MACRO __NBST
	BST  R@0,@1
	IN   R30,SREG
	LDI  R31,0x40
	EOR  R30,R31
	OUT  SREG,R30
	.ENDM


	.MACRO __PUTB1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SN
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNS
	LDD  R26,Y+@0
	LDD  R27,Y+@0+1
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMN
	LDS  R26,@0
	LDS  R27,@0+1
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1PMNS
	LDS  R26,@0
	LDS  R27,@0+1
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RN
	MOVW R26,R@0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RNS
	MOVW R26,R@0
	ADIW R26,@1
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RNS
	MOVW R26,R@0
	ADIW R26,@1
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RON
	MOV  R26,R@0
	MOV  R27,R@1
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	RCALL __PUTDP1
	.ENDM

	.MACRO __PUTB1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X,R30
	.ENDM

	.MACRO __PUTW1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1RONS
	MOV  R26,R@0
	MOV  R27,R@1
	ADIW R26,@2
	RCALL __PUTDP1
	.ENDM


	.MACRO __GETB1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R30,Z
	.ENDM

	.MACRO __GETB1HSX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	.ENDM

	.MACRO __GETW1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R0,Z+
	LD   R31,Z
	MOV  R30,R0
	.ENDM

	.MACRO __GETD1SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R0,Z+
	LD   R1,Z+
	LD   R22,Z+
	LD   R23,Z
	MOVW R30,R0
	.ENDM

	.MACRO __GETB2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R26,X
	.ENDM

	.MACRO __GETW2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	.ENDM

	.MACRO __GETD2SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R1,X+
	LD   R24,X+
	LD   R25,X
	MOVW R26,R0
	.ENDM

	.MACRO __GETBRSX
	MOVW R30,R28
	SUBI R30,LOW(-@1)
	SBCI R31,HIGH(-@1)
	LD   R@0,Z
	.ENDM

	.MACRO __GETWRSX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	LD   R@0,Z+
	LD   R@1,Z
	.ENDM

	.MACRO __GETBRSX2
	MOVW R26,R28
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	LD   R@0,X
	.ENDM

	.MACRO __GETWRSX2
	MOVW R26,R28
	SUBI R26,LOW(-@2)
	SBCI R27,HIGH(-@2)
	LD   R@0,X+
	LD   R@1,X
	.ENDM

	.MACRO __LSLW8SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	LD   R31,Z
	CLR  R30
	.ENDM

	.MACRO __PUTB1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __CLRW1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X,R30
	.ENDM

	.MACRO __CLRD1SX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	ST   X+,R30
	ST   X+,R30
	ST   X+,R30
	ST   X,R30
	.ENDM

	.MACRO __PUTB2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z,R26
	.ENDM

	.MACRO __PUTW2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z,R27
	.ENDM

	.MACRO __PUTD2SX
	MOVW R30,R28
	SUBI R30,LOW(-@0)
	SBCI R31,HIGH(-@0)
	ST   Z+,R26
	ST   Z+,R27
	ST   Z+,R24
	ST   Z,R25
	.ENDM

	.MACRO __PUTBSRX
	MOVW R30,R28
	SUBI R30,LOW(-@1)
	SBCI R31,HIGH(-@1)
	ST   Z,R@0
	.ENDM

	.MACRO __PUTWSRX
	MOVW R30,R28
	SUBI R30,LOW(-@2)
	SBCI R31,HIGH(-@2)
	ST   Z+,R@0
	ST   Z,R@1
	.ENDM

	.MACRO __PUTB1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X,R30
	.ENDM

	.MACRO __PUTW1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X,R31
	.ENDM

	.MACRO __PUTD1SNX
	MOVW R26,R28
	SUBI R26,LOW(-@0)
	SBCI R27,HIGH(-@0)
	LD   R0,X+
	LD   R27,X
	MOV  R26,R0
	SUBI R26,LOW(-@1)
	SBCI R27,HIGH(-@1)
	ST   X+,R30
	ST   X+,R31
	ST   X+,R22
	ST   X,R23
	.ENDM

	.MACRO __MULBRR
	MULS R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRRU
	MUL  R@0,R@1
	MOVW R30,R0
	.ENDM

	.MACRO __MULBRR0
	MULS R@0,R@1
	.ENDM

	.MACRO __MULBRRU0
	MUL  R@0,R@1
	.ENDM

	.MACRO __MULBNWRU
	LDI  R26,@2
	MUL  R26,R@0
	MOVW R30,R0
	MUL  R26,R@1
	ADD  R31,R0
	.ENDM

;NAME DEFINITIONS FOR GLOBAL VARIABLES ALLOCATED TO REGISTERS
	.DEF _IrMc=R7
	.DEF _SPIid=R6
	.DEF _SPI_L=R9
	.DEF _SPI_H=R8
	.DEF _SPI_data=R11
	.DEF _Kount100us=R10
	.DEF _FanSet=R13
	.DEF _BatPWM=R12

	.CSEG
	.ORG 0x00

;START OF CODE MARKER
__START_OF_CODE:

;INTERRUPT VECTORS
	RJMP __RESET
	RJMP 0x00
	RJMP _ext_int1_isr
	RJMP _timer2_comp_isr
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00
	RJMP _timer0_ovf_isr
	RJMP _spi_isr
	RJMP _usart_rx_isr
	RJMP 0x00
	RJMP _usart_tx_isr
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00
	RJMP 0x00

;REGISTER BIT VARIABLES INITIALIZATION
__REG_BIT_VARS:
	.DW  0x2204
	.DW  0x0000

;GLOBAL REGISTER VARIABLES INITIALIZATION
__REG_VARS:
	.DB  0x0,0x0,0x0,0x0
	.DB  0x0,0x0,0x1,0x6

_0x3:
	.DB  0x46,0x4F,0x52,0x54,0x45,0x4B,0x31,0x46
_0x4:
	.DB  0x50,0x44,0x45,0x20,0x47,0x69,0x66,0x74
_0x5:
	.DB  0x41,0x54,0x2B,0x4E,0x41,0x4D,0x45,0x3D
_0x6:
	.DB  0x78,0x0,0x3C,0xFE,0x1E,0xFC,0x3C,0x0
	.DB  0x3C,0xFE,0x3C,0x0,0x3C,0x2,0x3C,0x0
	.DB  0x3C,0xFE,0x28,0xFC,0x3C,0x0,0x3C,0xFE
	.DB  0x78,0x0,0x3C,0x2
_0x7:
	.DB  0x4,0x2,0x40,0x20,0x10,0x8
_0x8:
	.DB  0xFE,0xFD,0xFB,0xF7,0xEF,0xDF,0xBF,0x7F
_0x9:
	.DB  0x3,0x9F,0x25,0xD,0x99,0x49,0x41,0x1F
	.DB  0x1,0x9,0x11,0xC1,0x63,0x85,0x61,0x71
	.DB  0xFD,0xFF
_0xA:
	.DB  0x0,0x5E,0xBC,0xE2,0x61,0x3F,0xDD,0x83
	.DB  0xC2,0x9C,0x7E,0x20,0xA3,0xFD,0x1F,0x41
	.DB  0x9D,0xC3,0x21,0x7F,0xFC,0xA2,0x40,0x1E
	.DB  0x5F,0x1,0xE3,0xBD,0x3E,0x60,0x82,0xDC
	.DB  0x23,0x7D,0x9F,0xC1,0x42,0x1C,0xFE,0xA0
	.DB  0xE1,0xBF,0x5D,0x3,0x80,0xDE,0x3C,0x62
	.DB  0xBE,0xE0,0x2,0x5C,0xDF,0x81,0x63,0x3D
	.DB  0x7C,0x22,0xC0,0x9E,0x1D,0x43,0xA1,0xFF
	.DB  0x46,0x18,0xFA,0xA4,0x27,0x79,0x9B,0xC5
	.DB  0x84,0xDA,0x38,0x66,0xE5,0xBB,0x59,0x7
	.DB  0xDB,0x85,0x67,0x39,0xBA,0xE4,0x6,0x58
	.DB  0x19,0x47,0xA5,0xFB,0x78,0x26,0xC4,0x9A
	.DB  0x65,0x3B,0xD9,0x87,0x4,0x5A,0xB8,0xE6
	.DB  0xA7,0xF9,0x1B,0x45,0xC6,0x98,0x7A,0x24
	.DB  0xF8,0xA6,0x44,0x1A,0x99,0xC7,0x25,0x7B
	.DB  0x3A,0x64,0x86,0xD8,0x5B,0x5,0xE7,0xB9
	.DB  0x8C,0xD2,0x30,0x6E,0xED,0xB3,0x51,0xF
	.DB  0x4E,0x10,0xF2,0xAC,0x2F,0x71,0x93,0xCD
	.DB  0x11,0x4F,0xAD,0xF3,0x70,0x2E,0xCC,0x92
	.DB  0xD3,0x8D,0x6F,0x31,0xB2,0xEC,0xE,0x50
	.DB  0xAF,0xF1,0x13,0x4D,0xCE,0x90,0x72,0x2C
	.DB  0x6D,0x33,0xD1,0x8F,0xC,0x52,0xB0,0xEE
	.DB  0x32,0x6C,0x8E,0xD0,0x53,0xD,0xEF,0xB1
	.DB  0xF0,0xAE,0x4C,0x12,0x91,0xCF,0x2D,0x73
	.DB  0xCA,0x94,0x76,0x28,0xAB,0xF5,0x17,0x49
	.DB  0x8,0x56,0xB4,0xEA,0x69,0x37,0xD5,0x8B
	.DB  0x57,0x9,0xEB,0xB5,0x36,0x68,0x8A,0xD4
	.DB  0x95,0xCB,0x29,0x77,0xF4,0xAA,0x48,0x16
	.DB  0xE9,0xB7,0x55,0xB,0x88,0xD6,0x34,0x6A
	.DB  0x2B,0x75,0x97,0xC9,0x4A,0x14,0xF6,0xA8
	.DB  0x74,0x2A,0xC8,0x96,0x15,0x4B,0xA9,0xF7
	.DB  0xB6,0xE8,0xA,0x54,0xD7,0x89,0x6B,0x35
_0xB:
	.DB  0x5
_0x102:
	.DB  0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0
	.DB  0x0,0x0,0x0,0x0,0x0,0x0,0x1,0x0

__GLOBAL_INI_TBL:
	.DW  0x03
	.DW  0x02
	.DW  __REG_BIT_VARS*2

	.DW  0x08
	.DW  0x06
	.DW  __REG_VARS*2

	.DW  0x08
	.DW  _VERSION
	.DW  _0x3*2

	.DW  0x08
	.DW  _NAME_CMD
	.DW  _0x5*2

	.DW  0x1C
	.DW  _AUTO_FAN
	.DW  _0x6*2

	.DW  0x100
	.DW  _CRC8_DATA
	.DW  _0xA*2

_0xFFFFFFFF:
	.DW  0

#define __GLOBAL_INI_TBL_PRESENT 1

__RESET:
	CLI
	CLR  R30
	OUT  EECR,R30

;INTERRUPT VECTORS ARE PLACED
;AT THE START OF FLASH
	LDI  R31,1
	OUT  GICR,R31
	OUT  GICR,R30
	OUT  MCUCR,R30

;DISABLE WATCHDOG
	LDI  R31,0x18
	OUT  WDTCR,R31
	OUT  WDTCR,R30

;CLEAR R2-R14
	LDI  R24,(14-2)+1
	LDI  R26,2
	CLR  R27
__CLEAR_REG:
	ST   X+,R30
	DEC  R24
	BRNE __CLEAR_REG

;CLEAR SRAM
	LDI  R24,LOW(__CLEAR_SRAM_SIZE)
	LDI  R25,HIGH(__CLEAR_SRAM_SIZE)
	LDI  R26,__SRAM_START
__CLEAR_SRAM:
	ST   X+,R30
	SBIW R24,1
	BRNE __CLEAR_SRAM

;GLOBAL VARIABLES INITIALIZATION
	LDI  R30,LOW(__GLOBAL_INI_TBL*2)
	LDI  R31,HIGH(__GLOBAL_INI_TBL*2)
__GLOBAL_INI_NEXT:
	LPM  R24,Z+
	LPM  R25,Z+
	SBIW R24,0
	BREQ __GLOBAL_INI_END
	LPM  R26,Z+
	LPM  R27,Z+
	LPM  R0,Z+
	LPM  R1,Z+
	MOVW R22,R30
	MOVW R30,R0
__GLOBAL_INI_LOOP:
	LPM  R0,Z+
	ST   X+,R0
	SBIW R24,1
	BRNE __GLOBAL_INI_LOOP
	MOVW R30,R22
	RJMP __GLOBAL_INI_NEXT
__GLOBAL_INI_END:

;HARDWARE STACK POINTER INITIALIZATION
	LDI  R30,LOW(__SRAM_END-__HEAP_SIZE)
	OUT  SPL,R30
	LDI  R30,HIGH(__SRAM_END-__HEAP_SIZE)
	OUT  SPH,R30

;DATA STACK POINTER INITIALIZATION
	LDI  R28,LOW(__SRAM_START+__DSTACK_SIZE)
	LDI  R29,HIGH(__SRAM_START+__DSTACK_SIZE)

	RJMP _main

	.ESEG
	.ORG 0

	.DSEG
	.ORG 0x160

	.CSEG
;#include <mega8.h>
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x80
	.EQU __sm_mask=0x70
	.EQU __sm_powerdown=0x20
	.EQU __sm_powersave=0x30
	.EQU __sm_standby=0x60
	.EQU __sm_ext_standby=0x70
	.EQU __sm_adc_noise_red=0x10
	.SET power_ctrl_reg=mcucr
	#endif
;
;//using internal clk source
;// CLK SEL: 0100
;// CLKOPT : 1 (unpro)
;
;#include <delay.h>
;
;#define Nop #asm("NOP")
;
;const unsigned char     VERSION[8]={'F','O','R','T','E','K','1','F'};

	.DSEG
;const unsigned char     NAME[] = "PDE Gift";
;const unsigned char     NAME_CMD[] = "AT+NAME=";
;// version C: bo sung token
;// version E: chinh hien thi bao ACCU
;#define vLOW_LEVEL  0x63
;#define vMID_LEVEL  0x6d
;#define I_LOW       0x1d
;#define V_HIGH_CHR  0x75    //temp set
;#define vSYNCKOUNT  100
;#define vLOSTKOUNT  180     // 120 * vSYNCKOUNT * 100ms timeout = 30min
;
;
;#define bStsLed     PORTD.4
;#define bSts1Led    PORTC.4
;#define bSts2Led    PORTC.3
;#define bIr         PIND.3
;#define bSw         PINC.2
;#define bOpt        PINB.7
;
;#define bLatch  PORTB.4
;#define LEDSDA  PORTB.3
;#define LEDSCL  PORTB.5
;
;#define bBuzz   PORTB.0
;//#define bCHR_PWM    PORTB.1
;//#define bFAN_PWM    PORTB.2
;
;#define BIT0    0x01
;#define BIT1    0x02
;#define BIT2    0x04
;#define BIT3    0x08
;#define BIT4    0x10
;#define BIT5    0x20
;#define BIT6    0x40
;#define BIT7    0x80
;
;#define SEGA	~(0x01 << 7)
;#define SEGB	~(0x01 << 6)
;#define SEGC	~(0x01 << 5)
;#define SEGD	~(0x01 << 4)
;#define SEGE	~(0x01 << 3)
;#define SEGF	~(0x01 << 2)
;#define SEGG	~(0x01 << 1)
;#define SEGDP_INV	~(0x01 << 0)
;
;#define LEDNUM0		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF
;#define LEDNUM1		SEGB & SEGC
;#define LEDNUM2		SEGA & SEGB &  SEGD & SEGE & SEGG
;#define LEDNUM3		SEGA & SEGB & SEGC & SEGD & SEGG
;#define LEDNUM4		SEGB & SEGC & SEGG & SEGF
;#define LEDNUM5		SEGA & SEGC & SEGD & SEGG & SEGF
;#define LEDNUM6		SEGA & SEGG & SEGC & SEGD & SEGE & SEGF
;#define LEDNUM7		SEGA & SEGB & SEGC
;#define LEDNUM8		SEGA & SEGB & SEGC & SEGD & SEGE & SEGF  & SEGG
;#define LEDNUM9		SEGA & SEGB & SEGC & SEGD & SEGF  & SEGG
;#define LEDNUMA		SEGA & SEGB & SEGC & SEGE & SEGF  & SEGG
;#define LEDNUMB		SEGC & SEGD & SEGE & SEGF  & SEGG
;#define LEDNUMC		SEGA & SEGD & SEGE & SEGF
;#define LEDNUMD		SEGB & SEGC & SEGD & SEGE & SEGG
;#define LEDNUME		SEGA & SEGD & SEGE & SEGF  & SEGG
;#define LEDNUMF		SEGA & SEGE & SEGF  & SEGG
;#define LEDNUM16	SEGG
;#define LEDNUM17	0xFF
;
;const unsigned char   AUTO_FAN[28]={120,0,60,-2,30,-4,60,0,60,-2,60,0,60,2,60,0,60,-2,40,-4,60,0,60,-2,120,0,60,2}; //{T ...
;
;const unsigned char   FAN[6]={BIT2,BIT1,BIT6,BIT5,BIT4,BIT3};
;const unsigned char   TEST[8]={~BIT0,~BIT1,~BIT2,~BIT3,~BIT4,~BIT5,~BIT6,~BIT7};
;
;const unsigned char   MaledInv[18]={LEDNUM0,LEDNUM1,LEDNUM2,LEDNUM3,LEDNUM4,LEDNUM5,LEDNUM6,LEDNUM7,LEDNUM8,LEDNUM9,
;								    LEDNUMA,LEDNUMB,LEDNUMC,LEDNUMD,LEDNUME,LEDNUMF,LEDNUM16,LEDNUM17};
;
;const char CRC8_DATA[256]={
;        0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
;		0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e,	0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
;		0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0,	0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
;		0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,	0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
;		0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,	0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
;		0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58,	0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
;		0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6,	0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
;		0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b,	0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
;		0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f,	0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
;		0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92,	0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
;		0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c,	0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
;		0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1,	0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
;		0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49,	0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
;		0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,	0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
;		0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a,	0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
;		0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7,	0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35};
;
;#ifndef RXB8
;#define RXB8 1
;#endif
;
;#ifndef TXB8
;#define TXB8 0
;#endif
;
;#ifndef UPE
;#define UPE 2
;#endif
;
;#ifndef DOR
;#define DOR 3
;#endif
;
;#ifndef FE
;#define FE 4
;#endif
;
;#ifndef UDRE
;#define UDRE 5
;#endif
;
;#ifndef RXC
;#define RXC 7
;#endif
;#define vFRAMELEN 16
;
;#define FRAMING_ERROR (1<<FE)
;#define PARITY_ERROR (1<<UPE)
;#define DATA_OVERRUN (1<<DOR)
;#define DATA_REGISTER_EMPTY (1<<UDRE)
;#define RX_COMPLETE (1<<RXC)
;
;// USART Receiver buffer
;#define MAXREMOTE   1
;#define MAXBUTTON   6
;
;// Declare your global variables here
;
;char    IrMc = 0,SPIid = 0,SPI_L,SPI_H,SPI_data,Kount100us;
;char    LedBuff[12],FanSet = 6,BatPWM = 1,LightValue,LightPWM;
;char    BatT, IbatIn, IbatOut, Vbat, ADid = 0;
;char    RandData,RandSend,CYCLE = 5,TestIr;
;char    NameMc = 0,SyncKount,LostKount,IrByte,BitKount,IrTimeOut;
;char    NameBuffer[10],IrData[8],RemoteData[2*MAXBUTTON*MAXREMOTE+1],StoreId;
;char    BuzzFreq;
;
;eeprom char RemoteRom[2*MAXBUTTON*MAXREMOTE+2];
;int     IrInt;//,IrData16[2];
;
;char    Rx_Mc = 0,tx_counter,RxDelay = 0;
;char    setminute, sethour,Mode = 0;
;bit     f1ms_ov,fDisplayMode,fON_OFF = 1,fChangeName = 0,fRxReceived = 0;
;bit     fStsLed,fSound,fSwing,fTimerOn,fDisplayOn = 1,fSts1Led,fIrReceived;
;// This flag is set on USART Receiver buffer overflow
;bit     fRx_receive = 0,fTranFinish = 1,fProtect = 0, fSts2Led,fPulse,fRC5;
;//bit     fSound;
;
;#define DIG1    LedBuff[0]
;#define DIG2    LedBuff[1]
;#define DIG3    LedBuff[2]
;#define DIG4    LedBuff[3]
;#define DIG5    LedBuff[4]
;#define DIG6    LedBuff[5]
;#define DIG7    LedBuff[6]
;#define Hbyte   LedBuff[7]
;#define Kbyte   LedBuff[8]
;#define Jbyte   LedBuff[9]
;#define Lbyte   LedBuff[10]
;#define Sbyte   LedBuff[11]
;
;/////////////////////////////////////////////////////////////////
;/////////////////////////////////////////////////////////////////
;// External Interrupt 1 service routine
;
;interrupt [EXT_INT1] void ext_int1_isr(void)
; 0000 00B4 {

	.CSEG
_ext_int1_isr:
; .FSTART _ext_int1_isr
	RCALL SUBOPT_0x0
; 0000 00B5 // Place your code here
; 0000 00B6  char temp,i;
; 0000 00B7 //    fIntSts = !fIntSts;
; 0000 00B8 //bStsLed = !bStsLed;
; 0000 00B9     temp = Kount100us;
	RCALL __SAVELOCR2
;	temp -> R17
;	i -> R16
	MOV  R17,R10
; 0000 00BA     Kount100us = 0;
	CLR  R10
; 0000 00BB     IrTimeOut = 20;
	LDI  R30,LOW(20)
	RCALL SUBOPT_0x1
; 0000 00BC     switch (IrMc)
	MOV  R30,R7
; 0000 00BD         {
; 0000 00BE         case 0:
	CPI  R30,0
	BRNE _0xF
; 0000 00BF    //     fRC5 = 0;
; 0000 00C0         IrMc = 1;
	LDI  R30,LOW(1)
	MOV  R7,R30
; 0000 00C1         break;
	RJMP _0xE
; 0000 00C2         case 1:
_0xF:
	CPI  R30,LOW(0x1)
	BRNE _0x10
; 0000 00C3         if ((temp > 70) && (temp < 170)) // start bit condition, NEC code
	CPI  R17,71
	BRLO _0x12
	CPI  R17,170
	BRLO _0x13
_0x12:
	RJMP _0x11
_0x13:
; 0000 00C4             {
; 0000 00C5             BitKount = 0;
	RCALL SUBOPT_0x2
; 0000 00C6             IrMc = 2;
	LDI  R30,LOW(2)
	MOV  R7,R30
; 0000 00C7             IrByte = 0;
	RCALL SUBOPT_0x3
; 0000 00C8 //fStsLed = 1;
; 0000 00C9             }
; 0000 00CA         else if ((temp > 10) && (temp < 23))   //change config to receive toggle bit
	RJMP _0x14
_0x11:
	CPI  R17,11
	BRLO _0x16
	CPI  R17,23
	BRLO _0x17
_0x16:
	RJMP _0x15
_0x17:
; 0000 00CB             {
; 0000 00CC             MCUCR=(0<<ISC11) | (1<<ISC10) | (0<<ISC01) | (0<<ISC00);    //any change
	LDI  R30,LOW(4)
	OUT  0x35,R30
; 0000 00CD             BitKount = 0;
	RCALL SUBOPT_0x2
; 0000 00CE             IrMc = 30; //senko remote format
	LDI  R30,LOW(30)
	MOV  R7,R30
; 0000 00CF //            IrMc = 10;  // RC5 reading
; 0000 00D0  //           fPulse = 1;
; 0000 00D1             IrInt = 0;
	LDI  R30,LOW(0)
	STS  _IrInt,R30
	STS  _IrInt+1,R30
; 0000 00D2             }
; 0000 00D3         else
	RJMP _0x18
_0x15:
; 0000 00D4             {
; 0000 00D5             IrMc = 0;
	CLR  R7
; 0000 00D6 // TestIr = temp/10;
; 0000 00D7             }
_0x18:
_0x14:
; 0000 00D8         break;
	RJMP _0xE
; 0000 00D9         case 2:           //reading full byte 1 (address)
_0x10:
	CPI  R30,LOW(0x2)
	BRNE _0x19
; 0000 00DA         if ((temp > 28) || (temp < 8))
	CPI  R17,29
	BRSH _0x1B
	CPI  R17,8
	BRSH _0x1A
_0x1B:
; 0000 00DB             {
; 0000 00DC             IrMc = 0;   //invalid bit
	CLR  R7
; 0000 00DD             }
; 0000 00DE         else
	RJMP _0x1D
_0x1A:
; 0000 00DF             {
; 0000 00E0             IrByte >>= 1;
	RCALL SUBOPT_0x4
	RCALL SUBOPT_0x5
; 0000 00E1             if (temp > 17) IrByte |= 0x80;
	BRLO _0x1E
	RCALL SUBOPT_0x6
; 0000 00E2             if (++BitKount == 8)
_0x1E:
	RCALL SUBOPT_0x7
	BRNE _0x1F
; 0000 00E3                 {
; 0000 00E4                 IrData[0] = IrByte;
	RCALL SUBOPT_0x4
	STS  _IrData,R30
; 0000 00E5                 BitKount = 0;
	RCALL SUBOPT_0x2
; 0000 00E6                 IrByte = 0;
	RCALL SUBOPT_0x3
; 0000 00E7                 IrMc = 3;
	LDI  R30,LOW(3)
	MOV  R7,R30
; 0000 00E8                 }
; 0000 00E9             }
_0x1F:
_0x1D:
; 0000 00EA         break;
	RJMP _0xE
; 0000 00EB         case 3:           //reading full byte 2 (address_)
_0x19:
	CPI  R30,LOW(0x3)
	BRNE _0x20
; 0000 00EC         if ((temp > 28) || (temp < 8))
	CPI  R17,29
	BRSH _0x22
	CPI  R17,8
	BRSH _0x21
_0x22:
; 0000 00ED             {
; 0000 00EE             IrMc = 0;   //invalid bit
	CLR  R7
; 0000 00EF             }
; 0000 00F0         else
	RJMP _0x24
_0x21:
; 0000 00F1             {
; 0000 00F2             IrByte >>= 1;
	RCALL SUBOPT_0x4
	RCALL SUBOPT_0x5
; 0000 00F3             if (temp > 17) IrByte |= 0x80;
	BRLO _0x25
	RCALL SUBOPT_0x6
; 0000 00F4             if (++BitKount == 8)
_0x25:
	RCALL SUBOPT_0x7
	BRNE _0x26
; 0000 00F5                 {
; 0000 00F6                 IrData[1] = IrByte;
	RCALL SUBOPT_0x4
	__PUTB1MN _IrData,1
; 0000 00F7                 BitKount = 0;
	RCALL SUBOPT_0x2
; 0000 00F8                 IrByte = 0;
	RCALL SUBOPT_0x3
; 0000 00F9                 IrMc = 4;
	LDI  R30,LOW(4)
	MOV  R7,R30
; 0000 00FA                }
; 0000 00FB             }
_0x26:
_0x24:
; 0000 00FC         break;
	RJMP _0xE
; 0000 00FD         case 4:           //reading full byte 3 (data)
_0x20:
	CPI  R30,LOW(0x4)
	BRNE _0x27
; 0000 00FE         if ((temp > 28) || (temp < 8))
	CPI  R17,29
	BRSH _0x29
	CPI  R17,8
	BRSH _0x28
_0x29:
; 0000 00FF             {
; 0000 0100             IrMc = 0;   //invalid bit
	CLR  R7
; 0000 0101             }
; 0000 0102         else
	RJMP _0x2B
_0x28:
; 0000 0103             {
; 0000 0104             IrByte >>= 1;
	RCALL SUBOPT_0x4
	RCALL SUBOPT_0x5
; 0000 0105             if (temp > 17) IrByte |= 0x80;
	BRLO _0x2C
	RCALL SUBOPT_0x6
; 0000 0106             if (++BitKount == 8)
_0x2C:
	RCALL SUBOPT_0x7
	BRNE _0x2D
; 0000 0107                 {
; 0000 0108                 IrData[2] = IrByte;
	RCALL SUBOPT_0x4
	__PUTB1MN _IrData,2
; 0000 0109                 BitKount = 0;
	RCALL SUBOPT_0x2
; 0000 010A                 IrByte = 0;
	RCALL SUBOPT_0x3
; 0000 010B                 IrMc = 5;
	LDI  R30,LOW(5)
	MOV  R7,R30
; 0000 010C                }
; 0000 010D             }
_0x2D:
_0x2B:
; 0000 010E         break;
	RJMP _0xE
; 0000 010F         case 5:           //reading full byte 4 (data_)
_0x27:
	CPI  R30,LOW(0x5)
	BRNE _0x2E
; 0000 0110         if ((temp > 28) || (temp < 8))
	CPI  R17,29
	BRSH _0x30
	CPI  R17,8
	BRSH _0x2F
_0x30:
; 0000 0111             {
; 0000 0112             IrMc = 0;   //invalid bit
	RJMP _0x1C1
; 0000 0113             }
; 0000 0114         else
_0x2F:
; 0000 0115             {
; 0000 0116             IrByte >>= 1;
	RCALL SUBOPT_0x4
	RCALL SUBOPT_0x5
; 0000 0117             if (temp > 17) IrByte |= 0x80;
	BRLO _0x33
	RCALL SUBOPT_0x6
; 0000 0118             if (++BitKount == 8)
_0x33:
	RCALL SUBOPT_0x7
	BRNE _0x34
; 0000 0119                 {
; 0000 011A                 IrData[3] = IrByte;
	RCALL SUBOPT_0x4
	__PUTB1MN _IrData,3
; 0000 011B //                fStsLed = 0;
; 0000 011C //                for (i=0;i<4;i++)
; 0000 011D //                    {
; 0000 011E //                    if (IrData[i+4] != IrData[i]) fStsLed = 1;
; 0000 011F //                    IrData[i+4] = IrData[i];
; 0000 0120 //                    }
; 0000 0121                 if ((IrData[0] ^ IrData[1] == 0xFF) && (IrData[2] ^ IrData[3] == 0xFF))
	RCALL SUBOPT_0x8
	LDI  R30,LOW(255)
	RCALL __EQB12
	RCALL SUBOPT_0x9
	EOR  R30,R26
	BREQ _0x36
	__GETB2MN _IrData,3
	LDI  R30,LOW(255)
	RCALL __EQB12
	__GETB2MN _IrData,2
	EOR  R30,R26
	BRNE _0x37
_0x36:
	RJMP _0x35
_0x37:
; 0000 0122                     {
; 0000 0123                     //fStsLed = 1;
; 0000 0124                     fIrReceived = 1;
	SET
	BLD  R3,3
; 0000 0125                     IrData[1] = IrData[2];
	__GETB1MN _IrData,2
	__PUTB1MN _IrData,1
; 0000 0126                     fRC5 = 0;
	CLT
	BLD  R4,1
; 0000 0127                     }
; 0000 0128                 BitKount = 0;
_0x35:
	RCALL SUBOPT_0x2
; 0000 0129                 IrByte = 0;
	RCALL SUBOPT_0x3
; 0000 012A                 IrMc = 0;
_0x1C1:
	CLR  R7
; 0000 012B                 }
; 0000 012C             }
_0x34:
; 0000 012D         break;
	RJMP _0xE
; 0000 012E         case 10:             //mid1 state
_0x2E:
	CPI  R30,LOW(0xA)
	BRNE _0x38
; 0000 012F             if ((temp > 4) && (temp < 15))  //short P
	CPI  R17,5
	BRLO _0x3A
	CPI  R17,15
	BRLO _0x3B
_0x3A:
	RJMP _0x39
_0x3B:
; 0000 0130                 {
; 0000 0131                 IrMc = 11;  // start1 state
	LDI  R30,LOW(11)
	MOV  R7,R30
; 0000 0132                 fPulse = 0;
	CLT
	RCALL SUBOPT_0xA
; 0000 0133                 BitKount ++;
; 0000 0134                 }
; 0000 0135             else if ((temp >= 15) && (temp < 23))  // long P
	RJMP _0x3C
_0x39:
	CPI  R17,15
	BRLO _0x3E
	CPI  R17,23
	BRLO _0x3F
_0x3E:
	RJMP _0x3D
_0x3F:
; 0000 0136                 {
; 0000 0137                 IrMc = 12;  // Mid0 state
	LDI  R30,LOW(12)
	MOV  R7,R30
; 0000 0138                 BitKount ++;
	RCALL SUBOPT_0xB
; 0000 0139                 fPulse = 0;
	CLT
	BLD  R4,0
; 0000 013A                 }
; 0000 013B         break;
_0x3D:
_0x3C:
	RJMP _0xE
; 0000 013C         case 11:             //start1 state
_0x38:
	CPI  R30,LOW(0xB)
	BRNE _0x40
; 0000 013D         if ((temp > 4) && (temp < 13))   // short S
	CPI  R17,5
	BRLO _0x42
	CPI  R17,13
	BRLO _0x43
_0x42:
	RJMP _0x41
_0x43:
; 0000 013E             {
; 0000 013F             fPulse = 1;
	SET
	RCALL SUBOPT_0xA
; 0000 0140             BitKount++;    //emit 1
; 0000 0141             IrMc =  10;
	LDI  R30,LOW(10)
	MOV  R7,R30
; 0000 0142             }
; 0000 0143         break;
_0x41:
	RJMP _0xE
; 0000 0144         case 12:        // Mid 0
_0x40:
	CPI  R30,LOW(0xC)
	BRNE _0x44
; 0000 0145         if ((temp > 4) && (temp < 13))   // short S
	CPI  R17,5
	BRLO _0x46
	CPI  R17,13
	BRLO _0x47
_0x46:
	RJMP _0x45
_0x47:
; 0000 0146             {
; 0000 0147             fPulse = 1;
	SET
	BLD  R4,0
; 0000 0148             //BitKount++;    //emit 1
; 0000 0149             IrMc =  13;
	LDI  R30,LOW(13)
	MOV  R7,R30
; 0000 014A             }
; 0000 014B         else if ((temp > 13) && (temp < 23))   // long S
	RJMP _0x48
_0x45:
	CPI  R17,14
	BRLO _0x4A
	CPI  R17,23
	BRLO _0x4B
_0x4A:
	RJMP _0x49
_0x4B:
; 0000 014C             {
; 0000 014D             BitKount ++;    // emit 1
	RCALL SUBOPT_0xB
; 0000 014E             IrMc = 10;  // to Mid1 state
	LDI  R30,LOW(10)
	MOV  R7,R30
; 0000 014F             fPulse = 1;
	SET
	BLD  R4,0
; 0000 0150             }
; 0000 0151         break;
_0x49:
_0x48:
	RJMP _0xE
; 0000 0152         case 13:   // start0
_0x44:
	CPI  R30,LOW(0xD)
	BRNE _0x4C
; 0000 0153         if ((temp > 4) && (temp < 13))   // short P
	CPI  R17,5
	BRLO _0x4E
	CPI  R17,13
	BRLO _0x4F
_0x4E:
	RJMP _0x4D
_0x4F:
; 0000 0154             {
; 0000 0155             fPulse = 0;
	CLT
	RCALL SUBOPT_0xA
; 0000 0156             BitKount++;    //emit 0
; 0000 0157             IrMc =  12;
	LDI  R30,LOW(12)
	MOV  R7,R30
; 0000 0158             }
; 0000 0159         break;
_0x4D:
	RJMP _0xE
; 0000 015A         case 20:
_0x4C:
	CPI  R30,LOW(0x14)
	BRNE _0x50
; 0000 015B         fRC5 = 1;
	SET
	BLD  R4,1
; 0000 015C         IrTimeOut = 8;  //8ms for stop reading
	LDI  R30,LOW(8)
	RCALL SUBOPT_0x1
; 0000 015D         if (BitKount < 20)
	LDS  R26,_BitKount
	CPI  R26,LOW(0x14)
	BRSH _0x51
; 0000 015E             {
; 0000 015F             BitKount ++;
	RCALL SUBOPT_0xB
; 0000 0160             }
; 0000 0161         else
	RJMP _0x52
_0x51:
; 0000 0162             {
; 0000 0163             IrMc = 255;
	LDI  R30,LOW(255)
	MOV  R7,R30
; 0000 0164             }
_0x52:
; 0000 0165         break;
	RJMP _0xE
; 0000 0166 /////////////////////////////////////////////////
; 0000 0167         case 30:     // read the pulse
_0x50:
	CPI  R30,LOW(0x1E)
	BRNE _0x53
; 0000 0168         fRC5 = 1;
	SET
	BLD  R4,1
; 0000 0169         IrTimeOut = 5;  //8ms for stop reading
	LDI  R30,LOW(5)
	RCALL SUBOPT_0x1
; 0000 016A         if (temp > 3 && temp < 15)  //valid signal
	CPI  R17,4
	BRLO _0x55
	CPI  R17,15
	BRLO _0x56
_0x55:
	RJMP _0x54
_0x56:
; 0000 016B             {
; 0000 016C             IrInt <<= 1;
	RCALL SUBOPT_0xC
	LSL  R30
	ROL  R31
	RCALL SUBOPT_0xD
; 0000 016D             if (temp > 8) IrInt |= 1;  // bit 1
	CPI  R17,9
	BRLO _0x57
	RCALL SUBOPT_0xC
	ORI  R30,1
	RCALL SUBOPT_0xD
; 0000 016E             BitKount ++;
_0x57:
	RCALL SUBOPT_0xB
; 0000 016F             if (BitKount < 11)
	LDS  R26,_BitKount
	CPI  R26,LOW(0xB)
	BRSH _0x58
; 0000 0170                 {
; 0000 0171                 IrMc = 31;  // bypass next Space
	LDI  R30,LOW(31)
	MOV  R7,R30
; 0000 0172                 }
; 0000 0173             else
	RJMP _0x59
_0x58:
; 0000 0174                 {
; 0000 0175               //  if (IrData16[0] != IrInt) fStsLed = 1;
; 0000 0176               //  IrData16[0] = IrInt;
; 0000 0177                 fIrReceived = 1;
	SET
	BLD  R3,3
; 0000 0178                 fRC5 = 1;
	BLD  R4,1
; 0000 0179                 IrData[0] = (IrInt & 0xFF00)>>8;
	RCALL SUBOPT_0xC
	ANDI R30,LOW(0xFF00)
	MOV  R30,R31
	LDI  R31,0
	STS  _IrData,R30
; 0000 017A                 IrData[1] = (IrInt & 0x00ff);
	LDS  R30,_IrInt
	__PUTB1MN _IrData,1
; 0000 017B              //   IrData[2] = 0;
; 0000 017C              //   IrData[3] = 0;
; 0000 017D                 MCUCR = (1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);    //falling adge
	LDI  R30,LOW(8)
	OUT  0x35,R30
; 0000 017E                 IrMc = 0;
	CLR  R7
; 0000 017F                 }
_0x59:
; 0000 0180             }
; 0000 0181         else
_0x54:
; 0000 0182             {
; 0000 0183         //    IrMc = 255; // = 0 as normal
; 0000 0184             }
; 0000 0185         break;
	RJMP _0xE
; 0000 0186         case 31:     // read the space, do nothing
_0x53:
	CPI  R30,LOW(0x1F)
	BRNE _0x5B
; 0000 0187    //     fRC5 = 1;
; 0000 0188         IrTimeOut = 5;  //8ms for stop reading
	LDI  R30,LOW(5)
	RCALL SUBOPT_0x1
; 0000 0189         IrMc = 30;
	LDI  R30,LOW(30)
	MOV  R7,R30
; 0000 018A         break;
; 0000 018B 
; 0000 018C         case 255:   // receiver halted
_0x5B:
; 0000 018D         break;
; 0000 018E         }
_0xE:
; 0000 018F 
; 0000 0190  //   bStsLed = !bStsLed;
; 0000 0191 }
	LD   R16,Y+
	LD   R17,Y+
	RJMP _0x1D0
; .FEND
;
;// This flag is set on USART Receiver buffer overflow
;//bit rx_buffer_overflow;
;
;/////////////////////////////////////////////////////////////////
;/////////////////////////////////////////////////////////////////
;
;// USART Receiver buffer
;
;#define RX_BUFFER_SIZE 20
;char rx_buffer[RX_BUFFER_SIZE];
;char rx_buffer_out[RX_BUFFER_SIZE];
;
;#if RX_BUFFER_SIZE<256
;unsigned char rx_wr_index,rx_rd_index;//,rx_counter;
;#else
;unsigned int rx_wr_index,rx_rd_index;//,rx_counter;
;#endif
;
;
;/////////////////////////////////////////////////////
;/////////////////////////////////////////////////////
;
;// Data frame format for network
;// using fix size data frame:
;// Header: | Slave address or 0xFF | command | data bytes | CRC (include command) |
;//size of frame = RX_BUFFER_SIZE including address, command, data and CRC bytes
;
;/////////////////////////////////////////////////////
;/////////////////////////////////////////////////////
;// USART Receiver interrupt service routine
;interrupt [USART_RXC] void usart_rx_isr(void)
; 0000 01B2 {
_usart_rx_isr:
; .FSTART _usart_rx_isr
	ST   -Y,R26
	ST   -Y,R27
	ST   -Y,R30
	ST   -Y,R31
	IN   R30,SREG
	ST   -Y,R30
; 0000 01B3 char status1,data;
; 0000 01B4 status1=UCSRA;
	RCALL __SAVELOCR2
;	status1 -> R17
;	data -> R16
	IN   R17,11
; 0000 01B5 data=UDR;
	IN   R16,12
; 0000 01B6 
; 0000 01B7 if ((status1 & (FRAMING_ERROR | PARITY_ERROR | DATA_OVERRUN))==0)
	MOV  R30,R17
	ANDI R30,LOW(0x1C)
	BRNE _0x5D
; 0000 01B8 {
; 0000 01B9 switch (Rx_Mc)
	LDS  R30,_Rx_Mc
; 0000 01BA     {
; 0000 01BB     case 0:
	CPI  R30,0
	BRNE _0x61
; 0000 01BC         {
; 0000 01BD          rx_buffer[0]=data;   //store number of byte
	STS  _rx_buffer,R16
; 0000 01BE          rx_wr_index=1;
	LDI  R30,LOW(1)
	RCALL SUBOPT_0xE
; 0000 01BF          Rx_Mc = 1;
	LDI  R30,LOW(1)
	RCALL SUBOPT_0xF
; 0000 01C0          RxDelay = 40;
	LDI  R30,LOW(40)
	STS  _RxDelay,R30
; 0000 01C1         }
; 0000 01C2     break;
	RJMP _0x60
; 0000 01C3     case 1:         // receiving data frame
_0x61:
	CPI  R30,LOW(0x1)
	BRNE _0x69
; 0000 01C4     rx_buffer[rx_wr_index]=data;
	RCALL SUBOPT_0x10
	LDI  R31,0
	SUBI R30,LOW(-_rx_buffer)
	SBCI R31,HIGH(-_rx_buffer)
	ST   Z,R16
; 0000 01C5     RxDelay = 40;
	LDI  R30,LOW(40)
	STS  _RxDelay,R30
; 0000 01C6     ++rx_wr_index;
	RCALL SUBOPT_0x10
	SUBI R30,-LOW(1)
	RCALL SUBOPT_0xE
; 0000 01C7     if ((rx_wr_index == RX_BUFFER_SIZE) ||(rx_wr_index == rx_buffer[0]))
	RCALL SUBOPT_0x11
	CPI  R26,LOW(0x14)
	BREQ _0x64
	LDS  R30,_rx_buffer
	RCALL SUBOPT_0x11
	CP   R30,R26
	BRNE _0x63
_0x64:
; 0000 01C8        {
; 0000 01C9             {
; 0000 01CA             fRx_receive = 1;
	SET
	BLD  R3,4
; 0000 01CB             for (rx_wr_index=0;rx_wr_index<RX_BUFFER_SIZE;rx_wr_index++)      //double buffer purpose
	LDI  R30,LOW(0)
	RCALL SUBOPT_0xE
_0x67:
	RCALL SUBOPT_0x11
	CPI  R26,LOW(0x14)
	BRSH _0x68
; 0000 01CC                 {
; 0000 01CD                 rx_buffer_out[rx_wr_index] = rx_buffer[rx_wr_index];
	RCALL SUBOPT_0x11
	LDI  R27,0
	SUBI R26,LOW(-_rx_buffer_out)
	SBCI R27,HIGH(-_rx_buffer_out)
	RCALL SUBOPT_0x10
	LDI  R31,0
	SUBI R30,LOW(-_rx_buffer)
	SBCI R31,HIGH(-_rx_buffer)
	LD   R30,Z
	ST   X,R30
; 0000 01CE                 }
	RCALL SUBOPT_0x10
	SUBI R30,-LOW(1)
	RCALL SUBOPT_0xE
	RJMP _0x67
_0x68:
; 0000 01CF             }
; 0000 01D0        Rx_Mc = 0;
	LDI  R30,LOW(0)
	RCALL SUBOPT_0xF
; 0000 01D1        };
_0x63:
; 0000 01D2     break;
	RJMP _0x60
; 0000 01D3     default:
_0x69:
; 0000 01D4     Rx_Mc = 0;
	LDI  R30,LOW(0)
	RCALL SUBOPT_0xF
; 0000 01D5     }
_0x60:
; 0000 01D6 }
; 0000 01D7 }
_0x5D:
	LD   R16,Y+
	LD   R17,Y+
	LD   R30,Y+
	OUT  SREG,R30
	LD   R31,Y+
	LD   R30,Y+
	LD   R27,Y+
	LD   R26,Y+
	RETI
; .FEND
;
;#ifndef _DEBUG_TERMINAL_IO_
;// Get a character from the USART Receiver buffer
;#define _ALTERNATE_GETCHAR_
;#pragma used+
;#pragma used-
;#endif
;
;// USART Transmitter buffer
;#define TX_BUFFER_SIZE 50
;char tx_buffer[TX_BUFFER_SIZE];
;
;#if TX_BUFFER_SIZE<256
;unsigned char tx_wr_index,tx_rd_index,tx_counter;
;#else
;unsigned int tx_wr_index,tx_rd_index,tx_counter;
;#endif
;
;// USART Transmitter interrupt service routine
;interrupt [USART_TXC] void usart_tx_isr(void)
; 0000 01EC {
_usart_tx_isr:
; .FSTART _usart_tx_isr
	RCALL SUBOPT_0x0
; 0000 01ED if (tx_counter != 0)
	RCALL SUBOPT_0x12
	CPI  R30,0
	BREQ _0x6A
; 0000 01EE    {
; 0000 01EF  //  fStsLed = 1;
; 0000 01F0 
; 0000 01F1    --tx_counter;
	RCALL SUBOPT_0x13
; 0000 01F2    UDR=tx_buffer[tx_rd_index];
	LDS  R30,_tx_rd_index
	RCALL SUBOPT_0x14
	OUT  0xC,R30
; 0000 01F3 //   Tx_TimeOut = 10;
; 0000 01F4    if (++tx_rd_index == TX_BUFFER_SIZE) tx_rd_index=0;
	LDS  R26,_tx_rd_index
	SUBI R26,-LOW(1)
	STS  _tx_rd_index,R26
	CPI  R26,LOW(0x32)
	BRNE _0x6B
	LDI  R30,LOW(0)
	STS  _tx_rd_index,R30
; 0000 01F5    }
_0x6B:
; 0000 01F6 else
	RJMP _0x6C
_0x6A:
; 0000 01F7    {
; 0000 01F8  //   fStsLed = 0;
; 0000 01F9 	fTranFinish = 1;
	SET
	BLD  R3,5
; 0000 01FA    }
_0x6C:
; 0000 01FB }
_0x1D0:
	LD   R30,Y+
	OUT  SREG,R30
	LD   R31,Y+
	LD   R30,Y+
	LD   R26,Y+
	RETI
; .FEND
;
;
;#ifndef _DEBUG_TERMINAL_IO_
;// Write a character to the USART Transmitter buffer
;#define _ALTERNATE_PUTCHAR_
;#pragma used+
;
;#pragma used-
;#endif
;
;// Standard Input/Output functions
;//#include <stdio.h>
;
;// Timer 0 overflow interrupt service routine
;interrupt [TIM0_OVF] void timer0_ovf_isr(void)
; 0000 020B {
_timer0_ovf_isr:
; .FSTART _timer0_ovf_isr
	ST   -Y,R30
	IN   R30,SREG
	ST   -Y,R30
; 0000 020C // Reinitialize Timer 0 value
; 0000 020D TCNT0=-125-2;     // 1ms interrupt
	LDI  R30,LOW(129)
	OUT  0x32,R30
; 0000 020E // Place your code here
; 0000 020F     f1ms_ov = 1;
	SET
	BLD  R2,0
; 0000 0210     if (--IrTimeOut == 0)  //80ms timeout
	LDS  R30,_IrTimeOut
	SUBI R30,LOW(1)
	RCALL SUBOPT_0x1
	CPI  R30,0
	BRNE _0x6D
; 0000 0211         {
; 0000 0212         MCUCR=(1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);    //falling adge
	LDI  R30,LOW(8)
	OUT  0x35,R30
; 0000 0213         IrMc = 0;
	CLR  R7
; 0000 0214         }
; 0000 0215 }
_0x6D:
	LD   R30,Y+
	OUT  SREG,R30
	LD   R30,Y+
	RETI
; .FEND
;
;// Timer2 output compare interrupt service routine
;interrupt [TIM2_COMP] void timer2_comp_isr(void)
; 0000 0219 {
_timer2_comp_isr:
; .FSTART _timer2_comp_isr
	ST   -Y,R26
	ST   -Y,R30
	IN   R30,SREG
	ST   -Y,R30
; 0000 021A // Place your code here
; 0000 021B     Kount100us ++;
	INC  R10
; 0000 021C     if (fSound)
	SBRS R2,6
	RJMP _0x6E
; 0000 021D         {
; 0000 021E         if (++BuzzFreq == 4)
	LDS  R26,_BuzzFreq
	SUBI R26,-LOW(1)
	STS  _BuzzFreq,R26
	CPI  R26,LOW(0x4)
	BRNE _0x6F
; 0000 021F             {
; 0000 0220             BuzzFreq = 0;
	LDI  R30,LOW(0)
	STS  _BuzzFreq,R30
; 0000 0221             bBuzz = !bBuzz;
	SBIS 0x18,0
	RJMP _0x70
	CBI  0x18,0
	RJMP _0x71
_0x70:
	SBI  0x18,0
_0x71:
; 0000 0222             }
; 0000 0223         }
_0x6F:
; 0000 0224     else
	RJMP _0x72
_0x6E:
; 0000 0225         {
; 0000 0226         bBuzz = 0;
	CBI  0x18,0
; 0000 0227         BuzzFreq = 0;
	LDI  R30,LOW(0)
	STS  _BuzzFreq,R30
; 0000 0228         }
_0x72:
; 0000 0229 //    bBuzz
; 0000 022A   //  bStsLed = !bStsLed;
; 0000 022B }
	LD   R30,Y+
	OUT  SREG,R30
	LD   R30,Y+
	LD   R26,Y+
	RETI
; .FEND
;
;//#define ADC_VREF_TYPE 0xE0
;#define ADC_VREF_TYPE 0x60
;
;// Read the 8 most significant bits
;// of the AD conversion result
;unsigned char read_adc(unsigned char adc_input)
; 0000 0233 {
_read_adc:
; .FSTART _read_adc
; 0000 0234 ADMUX=adc_input | (ADC_VREF_TYPE & 0xff);
	ST   -Y,R26
;	adc_input -> Y+0
	LD   R30,Y
	ORI  R30,LOW(0x60)
	OUT  0x7,R30
; 0000 0235 // Delay needed for the stabilization of the ADC input voltage
; 0000 0236 delay_us(10);
	__DELAY_USB 27
; 0000 0237 // Start the AD conversion
; 0000 0238 ADCSRA|=0x40;
	SBI  0x6,6
; 0000 0239 // Wait for the AD conversion to complete
; 0000 023A while ((ADCSRA & 0x10)==0);
_0x75:
	SBIS 0x6,4
	RJMP _0x75
; 0000 023B ADCSRA|=0x10;
	SBI  0x6,4
; 0000 023C return ADCH;
	IN   R30,0x5
	RJMP _0x2000004
; 0000 023D }
; .FEND
;//////////////////////////////////////////////////////////////
;void ADC()
; 0000 0240 {
_ADC:
; .FSTART _ADC
; 0000 0241     switch (ADid)
	RCALL SUBOPT_0x15
; 0000 0242     {
; 0000 0243     case 0:
	CPI  R30,0
	BRNE _0x7B
; 0000 0244        IbatIn = read_adc(0);
	LDI  R26,LOW(0)
	RCALL _read_adc
	STS  _IbatIn,R30
; 0000 0245        ADid ++;
	RCALL SUBOPT_0x15
	SUBI R30,-LOW(1)
	RJMP _0x1C2
; 0000 0246     break;
; 0000 0247     case 1:
_0x7B:
	CPI  R30,LOW(0x1)
	BRNE _0x7C
; 0000 0248        IbatOut = read_adc(7);
	LDI  R26,LOW(7)
	RCALL _read_adc
	STS  _IbatOut,R30
; 0000 0249        ADid ++;
	RCALL SUBOPT_0x15
	SUBI R30,-LOW(1)
	RJMP _0x1C2
; 0000 024A     break;
; 0000 024B     case 2:
_0x7C:
	CPI  R30,LOW(0x2)
	BRNE _0x7D
; 0000 024C        Vbat = read_adc(1);
	LDI  R26,LOW(1)
	RCALL _read_adc
	STS  _Vbat,R30
; 0000 024D        ADid ++;
	RCALL SUBOPT_0x15
	SUBI R30,-LOW(1)
	RJMP _0x1C2
; 0000 024E     break;
; 0000 024F     case 3:
_0x7D:
	CPI  R30,LOW(0x3)
	BRNE _0x7F
; 0000 0250        BatT = read_adc(6);
	LDI  R26,LOW(6)
	RCALL _read_adc
	STS  _BatT,R30
; 0000 0251        ADid = 0;
; 0000 0252     break;
; 0000 0253     default:
_0x7F:
; 0000 0254        ADid = 0;
_0x1C3:
	LDI  R30,LOW(0)
_0x1C2:
	STS  _ADid,R30
; 0000 0255     }
; 0000 0256 
; 0000 0257 }
	RET
; .FEND
;// SPI interrupt service routine
;interrupt [SPI_STC] void spi_isr(void)
; 0000 025A {
_spi_isr:
; .FSTART _spi_isr
; 0000 025B 
; 0000 025C }
	RETI
; .FEND
;
;//////////////////////////////////////////////////////////
;void send_data (char bytesend)
; 0000 0260 {
_send_data:
; .FSTART _send_data
; 0000 0261 char i,checksum;
; 0000 0262     {
	ST   -Y,R26
	RCALL __SAVELOCR2
;	bytesend -> Y+2
;	i -> R17
;	checksum -> R16
; 0000 0263 	tx_rd_index = 1;
	LDI  R30,LOW(1)
	STS  _tx_rd_index,R30
; 0000 0264 	tx_counter = bytesend;
	LDD  R30,Y+2
	STS  _tx_counter,R30
; 0000 0265 	tx_buffer[0] = bytesend;
	RCALL SUBOPT_0x16
; 0000 0266     checksum = 0;
	LDI  R16,LOW(0)
; 0000 0267     for (i=0;i<bytesend-1;i++)
	LDI  R17,LOW(0)
_0x81:
	LDD  R30,Y+2
	SUBI R30,LOW(1)
	CP   R17,R30
	BRSH _0x82
; 0000 0268         {
; 0000 0269         checksum ^= tx_buffer[i];
	MOV  R30,R17
	RCALL SUBOPT_0x14
	EOR  R16,R30
; 0000 026A         }
	SUBI R17,-1
	RJMP _0x81
_0x82:
; 0000 026B     tx_buffer[bytesend-1] = checksum;
	LDD  R30,Y+2
	RCALL SUBOPT_0x17
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	ST   Z,R16
; 0000 026C 	UDR = tx_buffer[0];
	RCALL SUBOPT_0x18
; 0000 026D     tx_counter--;
; 0000 026E     }
; 0000 026F }
	RCALL __LOADLOCR2
	ADIW R28,3
	RET
; .FEND
;void send_pkg (char bytesend)
; 0000 0271 {
_send_pkg:
; .FSTART _send_pkg
; 0000 0272     while (!fTranFinish);          // send back data
	ST   -Y,R26
;	bytesend -> Y+0
_0x83:
	SBRS R3,5
	RJMP _0x83
; 0000 0273     fTranFinish = 0;
	RCALL SUBOPT_0x19
; 0000 0274 	tx_rd_index = 1;
	LDI  R30,LOW(1)
	STS  _tx_rd_index,R30
; 0000 0275 	tx_counter = bytesend;
	LD   R30,Y
	STS  _tx_counter,R30
; 0000 0276 	UDR = tx_buffer[0];
	RCALL SUBOPT_0x18
; 0000 0277     tx_counter--;
; 0000 0278 }
_0x2000004:
	ADIW R28,1
	RET
; .FEND
;void send_status(void)
; 0000 027A {
_send_status:
; .FSTART _send_status
; 0000 027B     while (!fTranFinish);          // send back data
_0x86:
	SBRS R3,5
	RJMP _0x86
; 0000 027C     fTranFinish = 0;
	RCALL SUBOPT_0x19
; 0000 027D     tx_buffer[2] = RandSend; // send data
	LDS  R30,_RandSend
	__PUTB1MN _tx_buffer,2
; 0000 027E     tx_buffer[3] = 4; // send data
	LDI  R30,LOW(4)
	RCALL SUBOPT_0x1A
; 0000 027F     tx_buffer[5] = fON_OFF ? 1:0;
	__POINTW1MN _tx_buffer,5
	MOVW R26,R30
	SBRS R2,2
	RJMP _0x89
	LDI  R30,LOW(1)
	RJMP _0x8A
_0x89:
	LDI  R30,LOW(0)
_0x8A:
	RCALL SUBOPT_0x1B
; 0000 0280     tx_buffer[6] = FanSet;
; 0000 0281     tx_buffer[7] = fTimerOn? 1:0;
	SBRS R3,0
	RJMP _0x8C
	LDI  R30,LOW(1)
	RJMP _0x8D
_0x8C:
	LDI  R30,LOW(0)
_0x8D:
	RCALL SUBOPT_0x1C
; 0000 0282     tx_buffer[8] = sethour;
; 0000 0283     tx_buffer[9] = setminute;
; 0000 0284     tx_buffer[10] = Mode & 0x01;
	ANDI R30,LOW(0x1)
	RCALL SUBOPT_0x1D
; 0000 0285     tx_buffer[11] = fSwing? 1: 0;
	SBRS R2,7
	RJMP _0x8F
	LDI  R30,LOW(1)
	RJMP _0x90
_0x8F:
	LDI  R30,LOW(0)
_0x90:
	RCALL SUBOPT_0x1E
; 0000 0286     tx_buffer[12] = LightValue;
; 0000 0287     tx_buffer[13] = fDisplayOn;
; 0000 0288     tx_buffer[14] = ((Mode & 0x02) == 0x02)? 1: 0;// bit1 of Mode is sleep
	ANDI R30,LOW(0x2)
	CPI  R30,LOW(0x2)
	BRNE _0x92
	LDI  R30,LOW(1)
	RJMP _0x93
_0x92:
	LDI  R30,LOW(0)
_0x93:
	RCALL SUBOPT_0x1F
; 0000 0289 //                   tx_buffer[14] = (Mode & 0x02) >> 1;// bit1 of Mode is sleep
; 0000 028A     send_data(16);
; 0000 028B 
; 0000 028C }
	RET
; .FEND
;void ChangeName(void)   // run under 100ms timer
; 0000 028E {
_ChangeName:
; .FSTART _ChangeName
; 0000 028F char i;
; 0000 0290 const char *ptr;
; 0000 0291  switch (NameMc)
	RCALL __SAVELOCR4
;	i -> R17
;	*ptr -> R18,R19
	LDS  R30,_NameMc
; 0000 0292     {
; 0000 0293      case 0:
	CPI  R30,0
	BRNE _0x98
; 0000 0294      if (fChangeName)
	SBRS R2,3
	RJMP _0x99
; 0000 0295         {
; 0000 0296         NameMc = 1;
	LDI  R30,LOW(1)
	RCALL SUBOPT_0x20
; 0000 0297         SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 0298         }
; 0000 0299      //if fSyncApp NameMc = 10;   // sync app
; 0000 029A      if (++SyncKount == vSYNCKOUNT)
_0x99:
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0x64)
	BRNE _0x9A
; 0000 029B         {
; 0000 029C         SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 029D         NameMc = 10;    // send sync command
	LDI  R30,LOW(10)
	RCALL SUBOPT_0x20
; 0000 029E         }
; 0000 029F      break;
_0x9A:
	RJMP _0x97
; 0000 02A0      case 1:       // send AT command
_0x98:
	CPI  R30,LOW(0x1)
	BRNE _0x9B
; 0000 02A1      if (++SyncKount == 20) // send name after 2 second
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0x14)
	BRNE _0x9C
; 0000 02A2         {
; 0000 02A3          tx_buffer[0] = 'A';
	RCALL SUBOPT_0x23
; 0000 02A4          tx_buffer[1] = 'T';
; 0000 02A5          fRxReceived = 0;
; 0000 02A6          SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 02A7          send_pkg(2);
	LDI  R26,LOW(2)
	RCALL _send_pkg
; 0000 02A8          NameMc = 2;
	LDI  R30,LOW(2)
	RCALL SUBOPT_0x20
; 0000 02A9          }
; 0000 02AA      break;
_0x9C:
	RJMP _0x97
; 0000 02AB      case 2:
_0x9B:
	CPI  R30,LOW(0x2)
	BRNE _0x9D
; 0000 02AC      if (fRxReceived)
	SBRS R2,4
	RJMP _0x9E
; 0000 02AD         {
; 0000 02AE         if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x4F)
	BRNE _0xA0
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x4B)
	BREQ _0xA1
_0xA0:
	RJMP _0x9F
_0xA1:
; 0000 02AF             {
; 0000 02B0             NameMc = 3;
	LDI  R30,LOW(3)
	RCALL SUBOPT_0x20
; 0000 02B1             }
; 0000 02B2         if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      // app present
_0x9F:
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x59)
	BRNE _0xA3
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x45)
	BRNE _0xA3
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x53)
	BREQ _0xA4
_0xA3:
	RJMP _0xA2
_0xA4:
; 0000 02B3             {
; 0000 02B4             SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 02B5             LostKount = 0;
	RCALL SUBOPT_0x26
; 0000 02B6             NameMc = 0;     //reinit the change name process
	RCALL SUBOPT_0x27
; 0000 02B7             }
; 0000 02B8         }
_0xA2:
; 0000 02B9      if (++SyncKount == 10)    // timeout
_0x9E:
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0xA)
	BRNE _0xA5
; 0000 02BA         {
; 0000 02BB         SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 02BC         NameMc = 0;     //reinit the change name process
	RCALL SUBOPT_0x27
; 0000 02BD         }
; 0000 02BE      break;
_0xA5:
	RJMP _0x97
; 0000 02BF      case 3:
_0x9D:
	CPI  R30,LOW(0x3)
	BRNE _0xA6
; 0000 02C0      //rx_buffer[0] = 0xFF;
; 0000 02C1      //fSound = 1;
; 0000 02C2      ptr = NAME_CMD;
	__POINTWRM 18,19,_NAME_CMD
; 0000 02C3      for (i=0;i<8;i++)
	LDI  R17,LOW(0)
_0xA8:
	CPI  R17,8
	BRSH _0xA9
; 0000 02C4         {
; 0000 02C5         tx_buffer[i] = *ptr++;
	RCALL SUBOPT_0x28
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	RCALL SUBOPT_0x29
; 0000 02C6         }
	SUBI R17,-1
	RJMP _0xA8
_0xA9:
; 0000 02C7      ptr = NameBuffer;
	__POINTWRM 18,19,_NameBuffer
; 0000 02C8      SyncKount = i; // = 8 for 8 byte saved
	STS  _SyncKount,R17
; 0000 02C9      for (i=0;i<10;i++)         // max byte to send
	LDI  R17,LOW(0)
_0xAB:
	CPI  R17,10
	BRSH _0xAC
; 0000 02CA         {
; 0000 02CB         if (*ptr != 0)
	MOVW R26,R18
	LD   R30,X
	CPI  R30,0
	BREQ _0xAD
; 0000 02CC             {
; 0000 02CD             tx_buffer[i+8] = *ptr++;
	RCALL SUBOPT_0x28
	__ADDW1MN _tx_buffer,8
	RCALL SUBOPT_0x29
; 0000 02CE             SyncKount ++;
	LDS  R30,_SyncKount
	SUBI R30,-LOW(1)
	STS  _SyncKount,R30
; 0000 02CF             }
; 0000 02D0         else
	RJMP _0xAE
_0xAD:
; 0000 02D1             {
; 0000 02D2             break;
	RJMP _0xAC
; 0000 02D3             }
_0xAE:
; 0000 02D4         }
	SUBI R17,-1
	RJMP _0xAB
_0xAC:
; 0000 02D5      fRxReceived = 0;
	CLT
	BLD  R2,4
; 0000 02D6      send_pkg(SyncKount);
	LDS  R26,_SyncKount
	RCALL _send_pkg
; 0000 02D7      NameMc = 4;
	LDI  R30,LOW(4)
	RCALL SUBOPT_0x2A
; 0000 02D8      SyncKount = 0;
; 0000 02D9      fChangeName = 0;
	CLT
	BLD  R2,3
; 0000 02DA      break;
	RJMP _0x97
; 0000 02DB      case 4:
_0xA6:
	CPI  R30,LOW(0x4)
	BRNE _0xAF
; 0000 02DC      if (fRxReceived)
	SBRS R2,4
	RJMP _0xB0
; 0000 02DD         {
; 0000 02DE    //     DIG6 = MaledInv[(rx_buffer[0] & 0xf0) >> 4];
; 0000 02DF    //     DIG7 = MaledInv[rx_buffer[0] & 0x0F];
; 0000 02E0         if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x4F)
	BRNE _0xB2
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x4B)
	BREQ _0xB3
_0xB2:
	RJMP _0xB1
_0xB3:
; 0000 02E1             {
; 0000 02E2             NameMc = 5;
	LDI  R30,LOW(5)
	RCALL SUBOPT_0x2A
; 0000 02E3     //        fStsLed = 1;
; 0000 02E4             SyncKount = 0;
; 0000 02E5             }
; 0000 02E6         }
_0xB1:
; 0000 02E7      if (++SyncKount == 10)
_0xB0:
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0xA)
	BRNE _0xB4
; 0000 02E8         {
; 0000 02E9         NameMc = 5;
	LDI  R30,LOW(5)
	RCALL SUBOPT_0x20
; 0000 02EA         SyncKount = 18;
	LDI  R30,LOW(18)
	STS  _SyncKount,R30
; 0000 02EB         }
; 0000 02EC      break;
_0xB4:
	RJMP _0x97
; 0000 02ED      case 5:
_0xAF:
	CPI  R30,LOW(0x5)
	BRNE _0xB5
; 0000 02EE      if (++SyncKount == 20)
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0x14)
	BRNE _0xB6
; 0000 02EF         {
; 0000 02F0         fStsLed = 0;
	RCALL SUBOPT_0x2B
; 0000 02F1         NameMc = 0;
	RCALL SUBOPT_0x27
; 0000 02F2         SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 02F3         fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 02F4         }
; 0000 02F5      break;
_0xB6:
	RJMP _0x97
; 0000 02F6      /////////////////////////////////////////////
; 0000 02F7      case 10:       // sync app
_0xB5:
	CPI  R30,LOW(0xA)
	BRNE _0xB7
; 0000 02F8 //     fsyncApp = 0;
; 0000 02F9 //     fStsLed = 1;
; 0000 02FA      NameMc = 11;
	LDI  R30,LOW(11)
	RJMP _0x1C4
; 0000 02FB      break;
; 0000 02FC      case 11:       // send AT command
_0xB7:
	CPI  R30,LOW(0xB)
	BRNE _0xB8
; 0000 02FD      fStsLed = 0;
	RCALL SUBOPT_0x2B
; 0000 02FE      tx_buffer[0] = 'A';
	RCALL SUBOPT_0x23
; 0000 02FF      tx_buffer[1] = 'T';
; 0000 0300      fRxReceived = 0;
; 0000 0301      send_pkg(2);
	LDI  R26,LOW(2)
	RCALL _send_pkg
; 0000 0302      NameMc = 12;
	LDI  R30,LOW(12)
	RCALL SUBOPT_0x2A
; 0000 0303      SyncKount = 0;
; 0000 0304      break;
	RJMP _0x97
; 0000 0305      case 12:
_0xB8:
	CPI  R30,LOW(0xC)
	BREQ PC+2
	RJMP _0xB9
; 0000 0306      if (fRxReceived)
	SBRS R2,4
	RJMP _0xBA
; 0000 0307         {
; 0000 0308         if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      // app present
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x59)
	BRNE _0xBC
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x45)
	BRNE _0xBC
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x53)
	BREQ _0xBD
_0xBC:
	RJMP _0xBB
_0xBD:
; 0000 0309             {
; 0000 030A             LostKount = 0;
	LDI  R30,LOW(0)
	RJMP _0x1C5
; 0000 030B             }
; 0000 030C         else if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K') LostKount ++;     //no - app
_0xBB:
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x4F)
	BRNE _0xC0
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x4B)
	BREQ _0xC1
_0xC0:
	RJMP _0xBF
_0xC1:
	LDS  R30,_LostKount
	SUBI R30,-LOW(1)
_0x1C5:
	STS  _LostKount,R30
; 0000 030D         SyncKount = 0;
_0xBF:
	RJMP _0x1C6
; 0000 030E         NameMc = 0;
; 0000 030F         }
; 0000 0310      else
_0xBA:
; 0000 0311         {
; 0000 0312         if (++SyncKount == 10)
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0xA)
	BRNE _0xC3
; 0000 0313             {
; 0000 0314            // LostKount ++;
; 0000 0315             SyncKount = 0;
_0x1C6:
	LDI  R30,LOW(0)
	STS  _SyncKount,R30
; 0000 0316             NameMc = 0;
	RCALL SUBOPT_0x27
; 0000 0317             }
; 0000 0318         }
_0xC3:
; 0000 0319      if (LostKount == vLOSTKOUNT)  //reset the BLE 200 * 5s
	LDS  R26,_LostKount
	CPI  R26,LOW(0xB4)
	BRNE _0xC4
; 0000 031A         {
; 0000 031B          tx_buffer[0] = 'A';
	LDI  R30,LOW(65)
	RCALL SUBOPT_0x16
; 0000 031C          tx_buffer[1] = 'T';
	LDI  R30,LOW(84)
	__PUTB1MN _tx_buffer,1
; 0000 031D          tx_buffer[2] = '+';
	LDI  R30,LOW(43)
	__PUTB1MN _tx_buffer,2
; 0000 031E          tx_buffer[3] = 'R';
	LDI  R30,LOW(82)
	RCALL SUBOPT_0x1A
; 0000 031F          tx_buffer[4] = 'E';
	LDI  R30,LOW(69)
	__PUTB1MN _tx_buffer,4
; 0000 0320          tx_buffer[5] = 'S';
	LDI  R30,LOW(83)
	__PUTB1MN _tx_buffer,5
; 0000 0321          tx_buffer[6] = 'E';
	LDI  R30,LOW(69)
	__PUTB1MN _tx_buffer,6
; 0000 0322          tx_buffer[7] = 'T';
	LDI  R30,LOW(84)
	__PUTB1MN _tx_buffer,7
; 0000 0323          fRxReceived = 0;
	CLT
	BLD  R2,4
; 0000 0324          send_pkg(8);
	LDI  R26,LOW(8)
	RCALL _send_pkg
; 0000 0325          NameMc = 13;
	LDI  R30,LOW(13)
	RCALL SUBOPT_0x2A
; 0000 0326          SyncKount = 0;
; 0000 0327         }
; 0000 0328      break;
_0xC4:
	RJMP _0x97
; 0000 0329      case 13:
_0xB9:
	CPI  R30,LOW(0xD)
	BRNE _0xC5
; 0000 032A      if (fRxReceived)
	SBRS R2,4
	RJMP _0xC6
; 0000 032B         {
; 0000 032C         LostKount = 0;
	RCALL SUBOPT_0x26
; 0000 032D         SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 032E         NameMc = 0;
	RCALL SUBOPT_0x27
; 0000 032F         if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')     //reset OK
	RCALL SUBOPT_0x24
	CPI  R26,LOW(0x4F)
	BRNE _0xC8
	RCALL SUBOPT_0x25
	CPI  R26,LOW(0x4B)
	BREQ _0xC9
_0xC8:
	RJMP _0xC7
_0xC9:
; 0000 0330             {
; 0000 0331       //      fStsLed = 1;
; 0000 0332             NameMc = 14;
	LDI  R30,LOW(14)
	RCALL SUBOPT_0x20
; 0000 0333             }
; 0000 0334         }
_0xC7:
; 0000 0335      else
	RJMP _0xCA
_0xC6:
; 0000 0336         {
; 0000 0337         if (++SyncKount == 10) // no-reply
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0xA)
	BRNE _0xCB
; 0000 0338             {
; 0000 0339             SyncKount = 0;
	RCALL SUBOPT_0x21
; 0000 033A             NameMc = 0;
	RCALL SUBOPT_0x27
; 0000 033B             }
; 0000 033C         }
_0xCB:
_0xCA:
; 0000 033D      break;
	RJMP _0x97
; 0000 033E      case 14:
_0xC5:
	CPI  R30,LOW(0xE)
	BRNE _0xCE
; 0000 033F      if (++SyncKount == 20)
	RCALL SUBOPT_0x22
	CPI  R26,LOW(0x14)
	BRNE _0xCD
; 0000 0340         {
; 0000 0341         fStsLed = 0;
	RCALL SUBOPT_0x2B
; 0000 0342         NameMc = 0;
	RCALL SUBOPT_0x27
; 0000 0343         }
; 0000 0344      break;
_0xCD:
	RJMP _0x97
; 0000 0345      default:
_0xCE:
; 0000 0346      NameMc = 0;
	LDI  R30,LOW(0)
_0x1C4:
	STS  _NameMc,R30
; 0000 0347     }
_0x97:
; 0000 0348 }
	RJMP _0x2000003
; .FEND
;///////////////////////////////////////////////////////////
;char load_eeprom()
; 0000 034B {
_load_eeprom:
; .FSTART _load_eeprom
; 0000 034C char i,crc,retry,zero;
; 0000 034D 
; 0000 034E // first byte of block is StoreId (pos for new remote
; 0000 034F 
; 0000 0350     zero = 1;
	RCALL __SAVELOCR4
;	i -> R17
;	crc -> R16
;	retry -> R19
;	zero -> R18
	LDI  R18,LOW(1)
; 0000 0351     retry = 0;
	LDI  R19,LOW(0)
; 0000 0352     do {      // save section
_0xD0:
; 0000 0353         crc = 0;
	LDI  R16,LOW(0)
; 0000 0354 
; 0000 0355         StoreId = RemoteRom[0];
	LDI  R26,LOW(_RemoteRom)
	LDI  R27,HIGH(_RemoteRom)
	RCALL __EEPROMRDB
	STS  _StoreId,R30
; 0000 0356         crc = CRC8_DATA[crc ^ StoreId];
	RCALL SUBOPT_0x2D
	RCALL SUBOPT_0x2E
; 0000 0357 
; 0000 0358         for (i=0;i<2*MAXBUTTON*MAXREMOTE + 1;i++)
	LDI  R17,LOW(0)
_0xD3:
	CPI  R17,13
	BRSH _0xD4
; 0000 0359             {
; 0000 035A             RemoteData[i] = RemoteRom[i+1];
	RCALL SUBOPT_0x28
	RCALL SUBOPT_0x2F
	MOVW R0,R30
	RCALL SUBOPT_0x28
	__ADDW1MN _RemoteRom,1
	MOVW R26,R30
	RCALL __EEPROMRDB
	MOVW R26,R0
	ST   X,R30
; 0000 035B             if (RemoteData[i] != 0) zero = 0;
	RCALL SUBOPT_0x28
	RCALL SUBOPT_0x30
	CPI  R30,0
	BREQ _0xD5
	LDI  R18,LOW(0)
; 0000 035C             crc = CRC8_DATA[crc ^ RemoteData[i]];
_0xD5:
	RCALL SUBOPT_0x28
	RCALL SUBOPT_0x30
	RCALL SUBOPT_0x2E
; 0000 035D             }
	SUBI R17,-1
	RJMP _0xD3
_0xD4:
; 0000 035E         if (zero)    // force load default
	CPI  R18,0
	BREQ _0xD6
; 0000 035F             {
; 0000 0360             retry = 35;
	LDI  R19,LOW(35)
; 0000 0361             crc = 1;
	LDI  R16,LOW(1)
; 0000 0362             }
; 0000 0363         }
_0xD6:
; 0000 0364     while ((++retry < 30) && (crc != 0));
	SUBI R19,-LOW(1)
	CPI  R19,30
	BRSH _0xD7
	CPI  R16,0
	BRNE _0xD8
_0xD7:
	RJMP _0xD1
_0xD8:
	RJMP _0xD0
_0xD1:
; 0000 0365     return crc;
	RJMP _0x2000002
; 0000 0366 }
; .FEND
;
;char save_eeprom()
; 0000 0369 {
_save_eeprom:
; .FSTART _save_eeprom
; 0000 036A char i,crc,retry;
; 0000 036B 
; 0000 036C     retry = 0;
	RCALL __SAVELOCR4
;	i -> R17
;	crc -> R16
;	retry -> R19
	LDI  R19,LOW(0)
; 0000 036D     do {      // save section
_0xDA:
; 0000 036E         crc = 0;
	LDI  R16,LOW(0)
; 0000 036F         RemoteRom[0] = StoreId;
	RCALL SUBOPT_0x2D
	LDI  R26,LOW(_RemoteRom)
	LDI  R27,HIGH(_RemoteRom)
	RCALL __EEPROMWRB
; 0000 0370         crc = CRC8_DATA[crc ^ StoreId];
	RCALL SUBOPT_0x2D
	RCALL SUBOPT_0x2E
; 0000 0371         for (i=0;i<2*MAXBUTTON*MAXREMOTE;i++)
	LDI  R17,LOW(0)
_0xDD:
	CPI  R17,12
	BRSH _0xDE
; 0000 0372             {
; 0000 0373             RemoteRom[i+1] = RemoteData[i];
	RCALL SUBOPT_0x28
	__ADDW1MN _RemoteRom,1
	MOVW R26,R30
	RCALL SUBOPT_0x28
	RCALL SUBOPT_0x30
	RCALL __EEPROMWRB
; 0000 0374             crc = CRC8_DATA[crc ^ RemoteData[i]];
	RCALL SUBOPT_0x28
	RCALL SUBOPT_0x30
	RCALL SUBOPT_0x2E
; 0000 0375             }
	SUBI R17,-1
	RJMP _0xDD
_0xDE:
; 0000 0376         RemoteRom[2*MAXBUTTON*MAXREMOTE + 1] = crc;
	__POINTW2MN _RemoteRom,13
	MOV  R30,R16
	RCALL __EEPROMWRB
; 0000 0377             // verify section
; 0000 0378         delay_ms(100);
	LDI  R26,LOW(100)
	LDI  R27,0
	RCALL _delay_ms
; 0000 0379         crc = 0;
	LDI  R16,LOW(0)
; 0000 037A         for (i=0;i<2*MAXBUTTON*MAXREMOTE + 2;i++)
	LDI  R17,LOW(0)
_0xE0:
	CPI  R17,14
	BRSH _0xE1
; 0000 037B             {
; 0000 037C             crc = CRC8_DATA[crc ^ RemoteRom[i]];
	MOV  R26,R17
	LDI  R27,0
	SUBI R26,LOW(-_RemoteRom)
	SBCI R27,HIGH(-_RemoteRom)
	RCALL __EEPROMRDB
	RCALL SUBOPT_0x2E
; 0000 037D             }
	SUBI R17,-1
	RJMP _0xE0
_0xE1:
; 0000 037E         }
; 0000 037F     while ((++retry < 10) && (crc != 0));
	SUBI R19,-LOW(1)
	CPI  R19,10
	BRSH _0xE2
	CPI  R16,0
	BRNE _0xE3
_0xE2:
	RJMP _0xDB
_0xE3:
	RJMP _0xDA
_0xDB:
; 0000 0380     return crc;
_0x2000002:
	MOV  R30,R16
_0x2000003:
	RCALL __LOADLOCR4
	ADIW R28,4
	RET
; 0000 0381 }
; .FEND
;//------------------------------------------------------------
;char check_IR(void)
; 0000 0384 {
_check_IR:
; .FSTART _check_IR
; 0000 0385 char i,j;
; 0000 0386 // input IrData[1:0]
; 0000 0387 // compare to RemoteData[]
; 0000 0388 // compare each remote, and return the matched button of that remote
; 0000 0389     for (i=0;i<MAXREMOTE;i++)
	RCALL __SAVELOCR2
;	i -> R17
;	j -> R16
	LDI  R17,LOW(0)
_0xE5:
	CPI  R17,1
	BRSH _0xE6
; 0000 038A         {
; 0000 038B         for (j=0;j<MAXBUTTON;j++)
	LDI  R16,LOW(0)
_0xE8:
	CPI  R16,6
	BRSH _0xE9
; 0000 038C             {
; 0000 038D             if ((IrData[0] == RemoteData[i*MAXBUTTON*2+j*2]) && (IrData[1] == RemoteData[i*MAXBUTTON*2 + j*2 + 1]))
	RCALL SUBOPT_0x31
	RCALL SUBOPT_0x32
	RCALL SUBOPT_0x9
	CP   R30,R26
	BRNE _0xEB
	RCALL SUBOPT_0x31
	SUBI R30,-LOW(1)
	RCALL SUBOPT_0x32
	RCALL SUBOPT_0x8
	CP   R30,R26
	BREQ _0xEC
_0xEB:
	RJMP _0xEA
_0xEC:
; 0000 038E                 {
; 0000 038F                 return (j+1);
	MOV  R30,R16
	SUBI R30,-LOW(1)
	RJMP _0x2000001
; 0000 0390                 }
; 0000 0391             }
_0xEA:
	SUBI R16,-1
	RJMP _0xE8
_0xE9:
; 0000 0392         }
	SUBI R17,-1
	RJMP _0xE5
_0xE6:
; 0000 0393     return 0;
	LDI  R30,LOW(0)
_0x2000001:
	LD   R16,Y+
	LD   R17,Y+
	RET
; 0000 0394 }
; .FEND
;//------------------------------------------------------------
;void out7seg(void)
; 0000 0397 {
; 0000 0398 // shiftout 4 byte of data
; 0000 0399 char i,j;
; 0000 039A char temp;
; 0000 039B     for (j=0;j<4;j++)
;	i -> R17
;	j -> R16
;	temp -> R19
; 0000 039C     {
; 0000 039D         temp = LedBuff[j];
; 0000 039E         if (j == 0)
; 0000 039F             {
; 0000 03A0      //       if (Status == 2) temp &= SEGDP_INV;
; 0000 03A1             }
; 0000 03A2         else if (j == 2)
; 0000 03A3             {
; 0000 03A4      //       if (Status == 1) temp &= SEGDP_INV;
; 0000 03A5             }
; 0000 03A6         else if (j == 1)
; 0000 03A7             {
; 0000 03A8       //      if (fMpptPos)  temp &= SEGDP_INV;
; 0000 03A9             }
; 0000 03AA         for (i=0;i<8;i++)
; 0000 03AB         {
; 0000 03AC          LEDSDA = !(temp & 0x80);
; 0000 03AD          temp <<= 1;
; 0000 03AE         Nop;
; 0000 03AF         Nop;
; 0000 03B0         Nop;
; 0000 03B1          LEDSCL = 1;
; 0000 03B2          Nop;
; 0000 03B3          Nop;
; 0000 03B4          Nop;
; 0000 03B5          LEDSCL = 0;
; 0000 03B6         }
; 0000 03B7     }
; 0000 03B8     bLatch = 1;
; 0000 03B9     Nop;
; 0000 03BA     bLatch = 0;
; 0000 03BB 
; 0000 03BC }
;// end of out7seg
;//------------------------------------------------------------
;void main(void)
; 0000 03C0 {
_main:
; .FSTART _main
; 0000 03C1 // Declare your local variables here
; 0000 03C2 char delay100ms, delay500ms=0, TestValue, i, second, minute, hour, FanRun;
; 0000 03C3 char sounddelay, timerdispdelay, ModeMinute,ModeHour,AutoFanId = 0,AutoFanTime = 1;
; 0000 03C4 char touch_o = 0,touch_e = 0,IfullSec = 0,StsDelay,SwMc = 0;
; 0000 03C5 char delay10ms = 0, IrMode = 0, Button, ButtonId, RepeatKount,Button_reset,Button_old,RepeatTimeout;
; 0000 03C6 char LedPwm = 0,Sts2Delay;
; 0000 03C7 int ButDelay;
; 0000 03C8 bit f1s, fTimerDisp = 0,fBatCharge = 1;
; 0000 03C9 {
	SBIW R28,25
	LDI  R24,16
	LDI  R26,LOW(3)
	LDI  R27,HIGH(3)
	LDI  R30,LOW(_0x102*2)
	LDI  R31,HIGH(_0x102*2)
	RCALL __INITLOCB
;	delay100ms -> R17
;	delay500ms -> R16
;	TestValue -> R19
;	i -> R18
;	second -> R21
;	minute -> R20
;	hour -> Y+24
;	FanRun -> Y+23
;	sounddelay -> Y+22
;	timerdispdelay -> Y+21
;	ModeMinute -> Y+20
;	ModeHour -> Y+19
;	AutoFanId -> Y+18
;	AutoFanTime -> Y+17
;	touch_o -> Y+16
;	touch_e -> Y+15
;	IfullSec -> Y+14
;	StsDelay -> Y+13
;	SwMc -> Y+12
;	delay10ms -> Y+11
;	IrMode -> Y+10
;	Button -> Y+9
;	ButtonId -> Y+8
;	RepeatKount -> Y+7
;	Button_reset -> Y+6
;	Button_old -> Y+5
;	RepeatTimeout -> Y+4
;	LedPwm -> Y+3
;	Sts2Delay -> Y+2
;	ButDelay -> Y+0
;	f1s -> R15.0
;	fTimerDisp -> R15.1
;	fBatCharge -> R15.2
	LDI  R30,LOW(4)
	MOV  R15,R30
	LDI  R16,0
; 0000 03CA // Input/Output Ports initialization
; 0000 03CB // Port B initialization
; 0000 03CC // Func7=IN Func6=Out Func5=Out Func4=Out Func3=Out Func2=Out Func1=Out Func0=Out
; 0000 03CD // State7=0 State6=0 State5=0 State4=0 State3=0 State2=0 State1=0 State0=0
; 0000 03CE PORTB=0x80;
	LDI  R30,LOW(128)
	OUT  0x18,R30
; 0000 03CF DDRB=0x7F;
	LDI  R30,LOW(127)
	OUT  0x17,R30
; 0000 03D0 
; 0000 03D1 // Port C initialization
; 0000 03D2 // Func6=In Func5=In Func4=out Func3=out Func2=In Func1=In Func0=In
; 0000 03D3 // State6=P State5=T State4=P State3=P State2=P State1=T State0=T
; 0000 03D4 PORTC=0x7C;
	LDI  R30,LOW(124)
	OUT  0x15,R30
; 0000 03D5 DDRC=0x18;
	LDI  R30,LOW(24)
	OUT  0x14,R30
; 0000 03D6 
; 0000 03D7 // Port D initialization
; 0000 03D8 // Func7=in Func6=Out Func5=in Func4=out Func3=In Func2=out Func1=in Func0=In
; 0000 03D9 // State7=0 State6=0 State5=0 State4=P State3=P State2=P State1=0 State0=P
; 0000 03DA PORTD=0xFF;
	LDI  R30,LOW(255)
	OUT  0x12,R30
; 0000 03DB DDRD=0x54;
	LDI  R30,LOW(84)
	OUT  0x11,R30
; 0000 03DC 
; 0000 03DD // Timer/Counter 0 initialization
; 0000 03DE // Clock source: System Clock
; 0000 03DF // Clock value: 125.000 kHz
; 0000 03E0 TCCR0=0x03;
	LDI  R30,LOW(3)
	OUT  0x33,R30
; 0000 03E1 TCNT0=0x12;
	LDI  R30,LOW(18)
	OUT  0x32,R30
; 0000 03E2 
; 0000 03E3 // Timer/Counter 1 initialization
; 0000 03E4 // Clock source: System Clock
; 0000 03E5 // Clock value: 8000.000 kHz
; 0000 03E6 // Mode: Ph. & fr. cor. PWM top=ICR1
; 0000 03E7 // OC1A output: Disconnected
; 0000 03E8 // OC1B output: Non-Inverted PWM
; 0000 03E9 // Noise Canceler: On
; 0000 03EA // Input Capture on Falling Edge
; 0000 03EB // Timer Period: 0.03175 ms
; 0000 03EC // Output Pulse(s):
; 0000 03ED // OC1B Period: 0.03175 ms Width: 0.02 ms
; 0000 03EE // Timer1 Overflow Interrupt: Off
; 0000 03EF // Input Capture Interrupt: Off
; 0000 03F0 // Compare A Match Interrupt: Off
; 0000 03F1 // Compare B Match Interrupt: Off
; 0000 03F2 TCCR1A=(0<<COM1A1) | (0<<COM1A0) | (1<<COM1B1) | (0<<COM1B0) | (0<<WGM11) | (0<<WGM10);
	LDI  R30,LOW(32)
	OUT  0x2F,R30
; 0000 03F3 TCCR1B=(1<<ICNC1) | (0<<ICES1) | (1<<WGM13) | (0<<WGM12) | (0<<CS12) | (0<<CS11) | (1<<CS10);
	LDI  R30,LOW(145)
	OUT  0x2E,R30
; 0000 03F4 TCNT1H=0x00;
	LDI  R30,LOW(0)
	OUT  0x2D,R30
; 0000 03F5 TCNT1L=0x00;
	OUT  0x2C,R30
; 0000 03F6 ICR1H=0x00;
	OUT  0x27,R30
; 0000 03F7 ICR1L=0x7F;
	LDI  R30,LOW(127)
	OUT  0x26,R30
; 0000 03F8 OCR1AH=0x00;
	LDI  R30,LOW(0)
	OUT  0x2B,R30
; 0000 03F9 OCR1AL=0x50;
	LDI  R30,LOW(80)
	OUT  0x2A,R30
; 0000 03FA OCR1BH=0x00;
	LDI  R30,LOW(0)
	OUT  0x29,R30
; 0000 03FB OCR1BL=0x50;
	LDI  R30,LOW(80)
	OUT  0x28,R30
; 0000 03FC 
; 0000 03FD // Timer/Counter 2 initialization
; 0000 03FE // Clock source: System Clock
; 0000 03FF // Clock value: 250.000 kHz
; 0000 0400 // Mode: CTC top=OCR2A
; 0000 0401 // OC2 output: Disconnected
; 0000 0402 // Timer Period: 0.1 ms
; 0000 0403 ASSR=0<<AS2;
	LDI  R30,LOW(0)
	OUT  0x22,R30
; 0000 0404 TCCR2=(0<<PWM2) | (0<<COM21) | (0<<COM20) | (1<<CTC2) | (0<<CS22) | (1<<CS21) | (1<<CS20);
	LDI  R30,LOW(11)
	OUT  0x25,R30
; 0000 0405 TCNT2=0x00;
	LDI  R30,LOW(0)
	OUT  0x24,R30
; 0000 0406 OCR2=0x18;
	LDI  R30,LOW(24)
	OUT  0x23,R30
; 0000 0407 
; 0000 0408 // Timer(s)/Counter(s) Interrupt(s) initialization
; 0000 0409 TIMSK=(1<<OCIE2) | (0<<TOIE2) | (0<<TICIE1) | (0<<OCIE1A) | (0<<OCIE1B) | (0<<TOIE1) | (1<<TOIE0);
	LDI  R30,LOW(129)
	OUT  0x39,R30
; 0000 040A 
; 0000 040B // External Interrupt(s) initialization
; 0000 040C // INT0: Off
; 0000 040D // INT1: On
; 0000 040E // INT1 Mode: Falling Edge
; 0000 040F //GICR|=0x80;
; 0000 0410 //MCUCR=0x08;
; 0000 0411 //GIFR=0x80;
; 0000 0412 
; 0000 0413 // External Interrupt(s) initialization
; 0000 0414 // INT0: Off
; 0000 0415 // INT1: On
; 0000 0416 // INT1 Mode: Falling Edge
; 0000 0417 GICR|=(1<<INT1) | (0<<INT0);
	IN   R30,0x3B
	ORI  R30,0x80
	OUT  0x3B,R30
; 0000 0418 MCUCR=(1<<ISC11) | (0<<ISC10) | (0<<ISC01) | (0<<ISC00);
	LDI  R30,LOW(8)
	OUT  0x35,R30
; 0000 0419 GIFR=(1<<INTF1) | (0<<INTF0);
	LDI  R30,LOW(128)
	OUT  0x3A,R30
; 0000 041A 
; 0000 041B // External Interrupt(s) initialization
; 0000 041C // INT0: Off
; 0000 041D // INT1: On
; 0000 041E // INT1 Mode: Any change
; 0000 041F //GICR|=(1<<INT1) | (0<<INT0);
; 0000 0420 //MCUCR=(0<<ISC11) | (1<<ISC10) | (0<<ISC01) | (0<<ISC00);
; 0000 0421 //GIFR=(1<<INTF1) | (0<<INTF0);
; 0000 0422 
; 0000 0423 
; 0000 0424 // USART initialization
; 0000 0425 // Communication Parameters: 8 Data, 1 Stop, No Parity
; 0000 0426 // USART Receiver: On
; 0000 0427 // USART Transmitter: On
; 0000 0428 // USART Mode: Asynchronous
; 0000 0429 // USART Baud Rate: 9600
; 0000 042A UCSRA=0x00;
	LDI  R30,LOW(0)
	OUT  0xB,R30
; 0000 042B UCSRB=0xD8;
	LDI  R30,LOW(216)
	OUT  0xA,R30
; 0000 042C UCSRC=0x86;
	LDI  R30,LOW(134)
	OUT  0x20,R30
; 0000 042D UBRRH=0x00;
	LDI  R30,LOW(0)
	OUT  0x20,R30
; 0000 042E UBRRL=0x33;
	LDI  R30,LOW(51)
	OUT  0x9,R30
; 0000 042F 
; 0000 0430 // Analog Comparator initialization
; 0000 0431 // Analog Comparator: Off
; 0000 0432 // Analog Comparator Input Capture by Timer/Counter 1: Off
; 0000 0433 ACSR=0x80;
	LDI  R30,LOW(128)
	OUT  0x8,R30
; 0000 0434 SFIOR=0x00;
	LDI  R30,LOW(0)
	OUT  0x30,R30
; 0000 0435 
; 0000 0436 // ADC initialization
; 0000 0437 // ADC Clock frequency: 62.500 kHz
; 0000 0438 // ADC Voltage Reference: AVCC pin
; 0000 0439 // Only the 8 most significant bits of
; 0000 043A // the AD conversion result are used
; 0000 043B ADMUX=ADC_VREF_TYPE & 0xff;
	LDI  R30,LOW(96)
	OUT  0x7,R30
; 0000 043C ADCSRA=0x87;
	LDI  R30,LOW(135)
	OUT  0x6,R30
; 0000 043D 
; 0000 043E // SPI initialization
; 0000 043F // SPI Type: Master
; 0000 0440 // SPI Clock Rate: 500.000 kHz
; 0000 0441 // SPI Clock Phase: Cycle Start
; 0000 0442 // SPI Clock Polarity: Low
; 0000 0443 // SPI Data Order: MSB First
; 0000 0444 SPCR=0xD1;
	LDI  R30,LOW(209)
	OUT  0xD,R30
; 0000 0445 SPSR=0x00;
	LDI  R30,LOW(0)
	OUT  0xE,R30
; 0000 0446 }
; 0000 0447 //i2c_init();
; 0000 0448 
; 0000 0449 /* globally enable interrupts */
; 0000 044A #asm("sei")
	sei
; 0000 044B 
; 0000 044C TestValue = 1;
	LDI  R19,LOW(1)
; 0000 044D second = 0;
	LDI  R21,LOW(0)
; 0000 044E 
; 0000 044F minute = 42;
	LDI  R20,LOW(42)
; 0000 0450 hour = 9;
	LDI  R30,LOW(9)
	STD  Y+24,R30
; 0000 0451 setminute = 50;
	LDI  R30,LOW(50)
	STS  _setminute,R30
; 0000 0452 sethour = 9;
	LDI  R30,LOW(9)
	STS  _sethour,R30
; 0000 0453 BatPWM = 12;
	LDI  R30,LOW(12)
	MOV  R12,R30
; 0000 0454 FanSet = 6;
	LDI  R30,LOW(6)
	MOV  R13,R30
; 0000 0455 FanRun = FanSet;
	__PUTBSR 13,23
; 0000 0456 Mode = 0;
	RCALL SUBOPT_0x33
; 0000 0457 fTimerOn = 0;
	CLT
	BLD  R3,0
; 0000 0458 fDisplayMode = 1;
	SET
	BLD  R2,1
; 0000 0459 Vbat = 250; // disable auto protect when init
	LDI  R30,LOW(250)
	STS  _Vbat,R30
; 0000 045A bSts2Led = 0;
	CBI  0x15,3
; 0000 045B bStsLed = 0;
	CBI  0x12,4
; 0000 045C fON_OFF = 0;
	CLT
	BLD  R2,2
; 0000 045D //bSts2Led = 1;
; 0000 045E if (load_eeprom() != 0)
	RCALL _load_eeprom
	CPI  R30,0
	BREQ _0x107
; 0000 045F     {
; 0000 0460     StoreId = 0;
	LDI  R30,LOW(0)
	STS  _StoreId,R30
; 0000 0461     for (i=0;i<2*MAXBUTTON*MAXREMOTE+1;i++)
	LDI  R18,LOW(0)
_0x109:
	CPI  R18,13
	BRSH _0x10A
; 0000 0462         {
; 0000 0463         RemoteData[i] = 0;
	RCALL SUBOPT_0x34
	RCALL SUBOPT_0x2F
	LDI  R26,LOW(0)
	STD  Z+0,R26
; 0000 0464         }
	SUBI R18,-1
	RJMP _0x109
_0x10A:
; 0000 0465     save_eeprom();
	RCALL _save_eeprom
; 0000 0466     fSts2Led = 1;
	RCALL SUBOPT_0x35
; 0000 0467     }
; 0000 0468 //bSts2Led = 0;
; 0000 0469 fSts2Led = 0;
_0x107:
	CLT
	BLD  R3,7
; 0000 046A 
; 0000 046B while (1)
_0x10B:
; 0000 046C       {
; 0000 046D       // Place your code here
; 0000 046E //      if (fIrReceived)
; 0000 046F //        {
; 0000 0470 //        fIrReceived = 0;
; 0000 0471 //
; 0000 0472 //
; 0000 0473 //       if (fRC5)
; 0000 0474 //            {
; 0000 0475 //            if (IrData16[0] != IrData16[1])
; 0000 0476 //                {
; 0000 0477 //                if (++FanSet == 10) FanSet = 9;
; 0000 0478 //                }
; 0000 0479 //            else
; 0000 047A //                {
; 0000 047B //                if (FanSet-- == 0) FanSet = 0;
; 0000 047C //                }
; 0000 047D //            IrData16[1] = IrData16[0];
; 0000 047E //            }
; 0000 047F //        }
; 0000 0480       if (f1ms_ov)
	SBRS R2,0
	RJMP _0x10E
; 0000 0481         {
; 0000 0482         f1ms_ov = 0;
	CLT
	BLD  R2,0
; 0000 0483         if (++RandData == 255) RandData = 1;
	LDS  R26,_RandData
	SUBI R26,-LOW(1)
	STS  _RandData,R26
	CPI  R26,LOW(0xFF)
	BRNE _0x10F
	LDI  R30,LOW(1)
	STS  _RandData,R30
; 0000 0484         if (RxDelay != 0)
_0x10F:
	LDS  R30,_RxDelay
	CPI  R30,0
	BREQ _0x110
; 0000 0485             {
; 0000 0486             if (--RxDelay == 0)
	SUBI R30,LOW(1)
	STS  _RxDelay,R30
	CPI  R30,0
	BRNE _0x111
; 0000 0487                 {
; 0000 0488                 Rx_Mc = 0;
	LDI  R30,LOW(0)
	RCALL SUBOPT_0xF
; 0000 0489                 fRxReceived = 1;
	SET
	BLD  R2,4
; 0000 048A                 }
; 0000 048B             }
_0x111:
; 0000 048C         if (++delay100ms == 100)
_0x110:
	SUBI R17,-LOW(1)
	CPI  R17,100
	BREQ PC+2
	RJMP _0x112
; 0000 048D             {
; 0000 048E             delay100ms = 0;
	LDI  R17,LOW(0)
; 0000 048F             ADC();
	RCALL _ADC
; 0000 0490             if (++LedPwm == 10)
	LDD  R26,Y+3
	SUBI R26,-LOW(1)
	STD  Y+3,R26
	CPI  R26,LOW(0xA)
	BRNE _0x113
; 0000 0491                 {
; 0000 0492                 LedPwm = 0;
	LDI  R30,LOW(0)
	STD  Y+3,R30
; 0000 0493                 }
; 0000 0494             if (FanSet > LedPwm)
_0x113:
; 0000 0495                 {
; 0000 0496     //            if (fON_OFF) fSts1Led = 1;
; 0000 0497                 }
; 0000 0498             else
; 0000 0499                 {
; 0000 049A       //          fSts1Led = 0;
; 0000 049B                 }
; 0000 049C 
; 0000 049D             if (fStsLed == 1)
	SBRS R2,5
	RJMP _0x116
; 0000 049E                 {
; 0000 049F                 if (--StsDelay == 0)
	LDD  R30,Y+13
	SUBI R30,LOW(1)
	STD  Y+13,R30
	BRNE _0x117
; 0000 04A0                     {
; 0000 04A1                     fStsLed = 0;
	RCALL SUBOPT_0x2B
; 0000 04A2                     StsDelay = 2;
	LDI  R30,LOW(2)
	STD  Y+13,R30
; 0000 04A3                     }
; 0000 04A4                 }
_0x117:
; 0000 04A5             else
	RJMP _0x118
_0x116:
; 0000 04A6                 {
; 0000 04A7                 StsDelay = 3;
	LDI  R30,LOW(3)
	STD  Y+13,R30
; 0000 04A8                 }
_0x118:
; 0000 04A9         //    if (fSts2Led == 1) fSts2Led = 0;
; 0000 04AA             ChangeName();
	RCALL _ChangeName
; 0000 04AB             if (++delay500ms == 5)
	SUBI R16,-LOW(1)
	CPI  R16,5
	BREQ PC+2
	RJMP _0x119
; 0000 04AC                 {
; 0000 04AD                 delay500ms = 0;
	LDI  R16,LOW(0)
; 0000 04AE      //           fSts1Led = !fSts1Led;
; 0000 04AF                 if (--timerdispdelay == 0) fTimerDisp = 0;
	LDD  R30,Y+21
	SUBI R30,LOW(1)
	STD  Y+21,R30
	BRNE _0x11A
	CLT
	BLD  R15,1
; 0000 04B0                 if (TestIr > 0)
_0x11A:
	LDS  R26,_TestIr
	CPI  R26,LOW(0x1)
	BRLO _0x11B
; 0000 04B1                     {
; 0000 04B2                     TestIr --;
	LDS  R30,_TestIr
	SUBI R30,LOW(1)
	STS  _TestIr,R30
; 0000 04B3                     fSts2Led = 1;
	RCALL SUBOPT_0x35
; 0000 04B4                     }
; 0000 04B5                 f1s = !f1s;
_0x11B:
	LDI  R30,LOW(1)
	EOR  R15,R30
; 0000 04B6                 if (f1s)
	SBRS R15,0
	RJMP _0x11C
; 0000 04B7                     {
; 0000 04B8                     second ++;
	SUBI R21,-1
; 0000 04B9                     IfullSec++;
	LDD  R30,Y+14
	SUBI R30,-LOW(1)
	STD  Y+14,R30
; 0000 04BA                     if (second > 59)
	CPI  R21,60
	BRLO _0x11D
; 0000 04BB                         {
; 0000 04BC                         second = 0;
	LDI  R21,LOW(0)
; 0000 04BD                         if (++minute > 59)
	SUBI R20,-LOW(1)
	CPI  R20,60
	BRLO _0x11E
; 0000 04BE                             {
; 0000 04BF                             minute = 0;
	LDI  R20,LOW(0)
; 0000 04C0                             if (++hour == 24) hour = 0;
	LDD  R26,Y+24
	SUBI R26,-LOW(1)
	STD  Y+24,R26
	CPI  R26,LOW(0x18)
	BRNE _0x11F
	LDI  R30,LOW(0)
	STD  Y+24,R30
; 0000 04C1                             }
_0x11F:
; 0000 04C2                         // sleep timer process
; 0000 04C3                         if (Mode >= 2)
_0x11E:
	LDS  R26,_Mode
	CPI  R26,LOW(0x2)
	BRLO _0x120
; 0000 04C4                             {
; 0000 04C5                             if (ModeMinute-- == 0)
	LDD  R30,Y+20
	SUBI R30,LOW(1)
	STD  Y+20,R30
	SUBI R30,-LOW(1)
	BRNE _0x121
; 0000 04C6                                 {
; 0000 04C7                                 ModeMinute = 59;
	LDI  R30,LOW(59)
	STD  Y+20,R30
; 0000 04C8                                 if (FanSet > 1) FanSet --;
	LDI  R30,LOW(1)
	CP   R30,R13
	BRSH _0x122
	DEC  R13
; 0000 04C9                                 FanRun = FanSet;
_0x122:
	__PUTBSR 13,23
; 0000 04CA                                 if (ModeHour-- == 0)
	LDD  R30,Y+19
	SUBI R30,LOW(1)
	STD  Y+19,R30
	SUBI R30,-LOW(1)
	BRNE _0x123
; 0000 04CB                                     {
; 0000 04CC                                     fON_OFF = 0;
	CLT
	BLD  R2,2
; 0000 04CD                                     }
; 0000 04CE                                 }
_0x123:
; 0000 04CF                             }
_0x121:
; 0000 04D0                         if (fTimerOn)
_0x120:
	SBRS R3,0
	RJMP _0x124
; 0000 04D1                             {
; 0000 04D2                             if ((hour == sethour) && (minute == setminute))
	LDS  R30,_sethour
	LDD  R26,Y+24
	CP   R30,R26
	BRNE _0x126
	LDS  R30,_setminute
	CP   R30,R20
	BREQ _0x127
_0x126:
	RJMP _0x125
_0x127:
; 0000 04D3                                 {
; 0000 04D4                                 fON_OFF = 0;
	CLT
	BLD  R2,2
; 0000 04D5                                 fTimerOn = 0;
	BLD  R3,0
; 0000 04D6                                 RandSend = 0;
	LDI  R30,LOW(0)
	STS  _RandSend,R30
; 0000 04D7                                 send_status();
	RCALL _send_status
; 0000 04D8                                 }
; 0000 04D9                             }
_0x125:
; 0000 04DA                         }
_0x124:
; 0000 04DB                     }
_0x11D:
; 0000 04DC                 }
_0x11C:
; 0000 04DD             TestValue *= 2;
_0x119:
	LSL  R19
; 0000 04DE             if (TestValue == 0) TestValue = 1;
	CPI  R19,0
	BRNE _0x128
	LDI  R19,LOW(1)
; 0000 04DF /////////////////////////////// input process @ 100ms ///////////////////////
; 0000 04E0 // OUTPUT control for ON/OFF //////////////////////////
; 0000 04E1              if (fON_OFF)
_0x128:
	SBRS R2,2
	RJMP _0x129
; 0000 04E2                 {
; 0000 04E3                 //////////////////////////////// mode process
; 0000 04E4                  switch (Mode)
	RCALL SUBOPT_0x36
; 0000 04E5                     {
; 0000 04E6                     case 0:
	CPI  R30,0
	BRNE _0x12D
; 0000 04E7                     FanRun = FanSet;
	__PUTBSR 13,23
; 0000 04E8                     break;
	RJMP _0x12C
; 0000 04E9                     case 1:     // natural fan
_0x12D:
	CPI  R30,LOW(0x1)
	BRNE _0x12E
; 0000 04EA                     if (--AutoFanTime == 0)
	LDD  R30,Y+17
	SUBI R30,LOW(1)
	STD  Y+17,R30
	BRNE _0x12F
; 0000 04EB                         {
; 0000 04EC                          AutoFanTime = AUTO_FAN[AutoFanId++];
	RCALL SUBOPT_0x37
	RCALL SUBOPT_0x38
	STD  Y+17,R30
; 0000 04ED                          FanRun = FanSet + AUTO_FAN[AutoFanId++];
	RCALL SUBOPT_0x37
	RCALL SUBOPT_0x38
	RCALL SUBOPT_0x39
; 0000 04EE                          if (FanRun > 127)
	BRLO _0x130
; 0000 04EF                             {
; 0000 04F0                             FanRun = 0;
	LDI  R30,LOW(0)
	RJMP _0x1C7
; 0000 04F1                             }
; 0000 04F2                          else if (FanRun > 9)
_0x130:
	LDD  R26,Y+23
	CPI  R26,LOW(0xA)
	BRLO _0x132
; 0000 04F3                             {
; 0000 04F4                             FanRun = 9;
	LDI  R30,LOW(9)
_0x1C7:
	STD  Y+23,R30
; 0000 04F5                             }
; 0000 04F6                          if (AutoFanId >= 28) AutoFanId = 0;
_0x132:
	LDD  R26,Y+18
	CPI  R26,LOW(0x1C)
	BRLO _0x133
	LDI  R30,LOW(0)
	STD  Y+18,R30
; 0000 04F7                         }
_0x133:
; 0000 04F8                     break;
_0x12F:
	RJMP _0x12C
; 0000 04F9                     case 2:
_0x12E:
	CPI  R30,LOW(0x2)
	BRNE _0x134
; 0000 04FA                     FanRun = FanSet;
	__PUTBSR 13,23
; 0000 04FB                     break;
	RJMP _0x12C
; 0000 04FC                     case 3:
_0x134:
	CPI  R30,LOW(0x3)
	BRNE _0x13B
; 0000 04FD                     if (--AutoFanTime == 0)
	LDD  R30,Y+17
	SUBI R30,LOW(1)
	STD  Y+17,R30
	BRNE _0x136
; 0000 04FE                         {
; 0000 04FF                          AutoFanTime = AUTO_FAN[AutoFanId++];
	RCALL SUBOPT_0x37
	RCALL SUBOPT_0x38
	STD  Y+17,R30
; 0000 0500                          FanRun = FanSet + AUTO_FAN[AutoFanId++];
	RCALL SUBOPT_0x37
	RCALL SUBOPT_0x38
	RCALL SUBOPT_0x39
; 0000 0501                          if (FanRun > 127)
	BRLO _0x137
; 0000 0502                             {
; 0000 0503                             FanRun = 0;
	LDI  R30,LOW(0)
	RJMP _0x1C8
; 0000 0504                             }
; 0000 0505                          else if (FanRun > 9)
_0x137:
	LDD  R26,Y+23
	CPI  R26,LOW(0xA)
	BRLO _0x139
; 0000 0506                             {
; 0000 0507                             FanRun = 9;
	LDI  R30,LOW(9)
_0x1C8:
	STD  Y+23,R30
; 0000 0508                             }
; 0000 0509                          if (AutoFanId >= 28) AutoFanId = 0;
_0x139:
	LDD  R26,Y+18
	CPI  R26,LOW(0x1C)
	BRLO _0x13A
	LDI  R30,LOW(0)
	STD  Y+18,R30
; 0000 050A                         }
_0x13A:
; 0000 050B                     break;
_0x136:
	RJMP _0x12C
; 0000 050C                     default:
_0x13B:
; 0000 050D                     Mode = 0;
	RCALL SUBOPT_0x33
; 0000 050E                     }
_0x12C:
; 0000 050F // FAN SPEED CONTROL PWM //////////////////////////////
; 0000 0510                 if (FanRun == 0)
	LDD  R30,Y+23
	CPI  R30,0
	BRNE _0x13C
; 0000 0511                     {
; 0000 0512                     OCR1BL = 0;
	LDI  R30,LOW(0)
	RJMP _0x1C9
; 0000 0513                     }
; 0000 0514                 else
_0x13C:
; 0000 0515                     {
; 0000 0516                         { // dung so 8 lam so lon nhat
; 0000 0517 //                        OCR1BL = 15 + (FanRun-1) * 2;       // so 3 la so nho nhat.so 5 la so lon nhat.
; 0000 0518                         OCR1BL = 73 + FanRun * 6; // total 127, from 70
	LDD  R30,Y+23
	RCALL SUBOPT_0x3A
	SUBI R30,-LOW(73)
_0x1C9:
	OUT  0x28,R30
; 0000 0519                         }
; 0000 051A                     }
; 0000 051B                 if (FanSet == 0) fSwing = 0;
	TST  R13
	BRNE _0x13E
	CLT
	BLD  R2,7
; 0000 051C                 }
_0x13E:
; 0000 051D              else        // fON_OFF = 0
	RJMP _0x13F
_0x129:
; 0000 051E                 {
; 0000 051F                 OCR1BL = 0;       // so 3 la so nho nhat.so 5 la so lon nhat.
	LDI  R30,LOW(0)
	OUT  0x28,R30
; 0000 0520 //                LightValue = 0;
; 0000 0521                 if (Mode >= 2) Mode -= 2;   // stop the sleep mode
	LDS  R26,_Mode
	CPI  R26,LOW(0x2)
	BRLO _0x140
	RCALL SUBOPT_0x36
	SUBI R30,LOW(2)
	STS  _Mode,R30
; 0000 0522 //                BatPWM = 15;
; 0000 0523 //                fDisplayOn = 1;
; 0000 0524                 }
_0x140:
_0x13F:
; 0000 0525 // battery control section, voltage control
; 0000 0526             }
; 0000 0527         if (fRx_receive)
_0x112:
	SBRS R3,4
	RJMP _0x141
; 0000 0528             {
; 0000 0529             fRx_receive = 0;
	CLT
	BLD  R3,4
; 0000 052A             LostKount = 0;
	RCALL SUBOPT_0x26
; 0000 052B             SyncKount = 0;  // reset the sync signal MC
	RCALL SUBOPT_0x21
; 0000 052C //            if ((rx_buffer_out[0] == 8) || (rx_buffer_out[0] == vFRAMELEN))
; 0000 052D             if ((fProtect == 0) && (rx_buffer_out[0] == vFRAMELEN))
	SBRC R3,6
	RJMP _0x143
	LDS  R26,_rx_buffer_out
	CPI  R26,LOW(0x10)
	BREQ _0x144
_0x143:
	RJMP _0x142
_0x144:
; 0000 052E                 {// process for received data
; 0000 052F                 //fSound = 1;
; 0000 0530                 switch (rx_buffer_out[3])
	__GETB1MN _rx_buffer_out,3
; 0000 0531                     {
; 0000 0532                     case 1: //getting the version
	CPI  R30,LOW(0x1)
	BRNE _0x148
; 0000 0533                     hour = rx_buffer_out[5];
	__GETB1MN _rx_buffer_out,5
	STD  Y+24,R30
; 0000 0534                     minute = rx_buffer_out[6];
	__GETBRMN 20,_rx_buffer_out,6
; 0000 0535                     second = rx_buffer_out[7];
	__GETBRMN 21,_rx_buffer_out,7
; 0000 0536                     while (!fTranFinish);          // send back data
_0x149:
	SBRS R3,5
	RJMP _0x149
; 0000 0537                     fTranFinish = 0;
	RCALL SUBOPT_0x19
; 0000 0538                     tx_buffer[3] = 11; // send data
	LDI  R30,LOW(11)
	RCALL SUBOPT_0x1A
; 0000 0539                     for (i=0;i<8;i++)
	LDI  R18,LOW(0)
_0x14D:
	CPI  R18,8
	BRSH _0x14E
; 0000 053A                         {
; 0000 053B                         tx_buffer[5+i] = VERSION[i];
	RCALL SUBOPT_0x34
	__ADDW1MN _tx_buffer,5
	MOVW R26,R30
	RCALL SUBOPT_0x34
	SUBI R30,LOW(-_VERSION)
	SBCI R31,HIGH(-_VERSION)
	LD   R30,Z
	ST   X,R30
; 0000 053C                         }
	SUBI R18,-1
	RJMP _0x14D
_0x14E:
; 0000 053D                     send_data(16);
	LDI  R26,LOW(16)
	RCALL _send_data
; 0000 053E                     break;
	RJMP _0x147
; 0000 053F                     case 2:       // app getting data, sendback
_0x148:
	CPI  R30,LOW(0x2)
	BRNE _0x14F
; 0000 0540                     if (RandSend != RandData)
	LDS  R30,_RandData
	LDS  R26,_RandSend
	CP   R30,R26
	BREQ _0x150
; 0000 0541                         {
; 0000 0542                         RandSend = RandData;
	RJMP _0x1CA
; 0000 0543                         }
; 0000 0544                     else
_0x150:
; 0000 0545                         {
; 0000 0546                         RandSend = RandData ^ 0x7E;
	LDS  R26,_RandData
	LDI  R30,LOW(126)
	EOR  R30,R26
_0x1CA:
	STS  _RandSend,R30
; 0000 0547                         }
; 0000 0548                     send_status();
	RCALL _send_status
; 0000 0549                     break;
	RJMP _0x147
; 0000 054A                     case 3:    // update data for FAN
_0x14F:
	CPI  R30,LOW(0x3)
	BREQ PC+2
	RJMP _0x152
; 0000 054B                     if (rx_buffer_out[2] == RandSend)
	__GETB2MN _rx_buffer_out,2
	LDS  R30,_RandSend
	CP   R30,R26
	BRNE _0x153
; 0000 054C                         {
; 0000 054D                         fON_OFF = rx_buffer_out[5];
	__GETB1MN _rx_buffer_out,5
	RCALL __BSTB1
	BLD  R2,2
; 0000 054E                         FanSet = rx_buffer_out[6];
	__GETBRMN 13,_rx_buffer_out,6
; 0000 054F                         fTimerOn = rx_buffer_out[7];
	__GETB1MN _rx_buffer_out,7
	RCALL __BSTB1
	BLD  R3,0
; 0000 0550                         sethour = rx_buffer_out[8];
	__GETB1MN _rx_buffer_out,8
	STS  _sethour,R30
; 0000 0551                         setminute = rx_buffer_out[9];
	__GETB1MN _rx_buffer_out,9
	STS  _setminute,R30
; 0000 0552                         Mode = rx_buffer_out[10];       // single mode
	__GETB1MN _rx_buffer_out,10
	STS  _Mode,R30
; 0000 0553                         fSwing = rx_buffer_out[11];
	__GETB1MN _rx_buffer_out,11
	RCALL __BSTB1
	BLD  R2,7
; 0000 0554                         LightValue = rx_buffer_out[12];
	__GETB1MN _rx_buffer_out,12
	STS  _LightValue,R30
; 0000 0555                         fDisplayOn =  rx_buffer_out[13];
	__GETB1MN _rx_buffer_out,13
	RCALL __BSTB1
	BLD  R3,1
; 0000 0556                         if (rx_buffer_out[14] == 1)     // sleep
	__GETB2MN _rx_buffer_out,14
	CPI  R26,LOW(0x1)
	BRNE _0x154
; 0000 0557                             {
; 0000 0558                             Mode |= 0x02;
	RCALL SUBOPT_0x36
	ORI  R30,2
	RJMP _0x1CB
; 0000 0559                             }
; 0000 055A                         else
_0x154:
; 0000 055B                             {
; 0000 055C                             Mode &= (~0x02);
	RCALL SUBOPT_0x36
	ANDI R30,0xFD
_0x1CB:
	STS  _Mode,R30
; 0000 055D                             }
; 0000 055E                         fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 055F                         }
; 0000 0560                     else
	RJMP _0x156
_0x153:
; 0000 0561                         {     // send error message
; 0000 0562                         while (!fTranFinish);          // send back data
_0x157:
	SBRS R3,5
	RJMP _0x157
; 0000 0563                         fTranFinish = 0;
	RCALL SUBOPT_0x19
; 0000 0564                         tx_buffer[2] = 0; // send data
	LDI  R30,LOW(0)
	__PUTB1MN _tx_buffer,2
; 0000 0565                         tx_buffer[3] = 0; // send data
	RCALL SUBOPT_0x1A
; 0000 0566                         tx_buffer[5] = fON_OFF ? 1:0;
	__POINTW1MN _tx_buffer,5
	MOVW R26,R30
	SBRS R2,2
	RJMP _0x15A
	LDI  R30,LOW(1)
	RJMP _0x15B
_0x15A:
	LDI  R30,LOW(0)
_0x15B:
	RCALL SUBOPT_0x1B
; 0000 0567                         tx_buffer[6] = FanSet;
; 0000 0568                         tx_buffer[7] = fTimerOn? 1:0;
	SBRS R3,0
	RJMP _0x15D
	LDI  R30,LOW(1)
	RJMP _0x15E
_0x15D:
	LDI  R30,LOW(0)
_0x15E:
	RCALL SUBOPT_0x1C
; 0000 0569                         tx_buffer[8] = sethour;
; 0000 056A                         tx_buffer[9] = setminute;
; 0000 056B                         tx_buffer[10] = Mode && 0x01;
	CPI  R30,0
	BREQ _0x160
	LDI  R30,LOW(1)
	CPI  R30,0
	BREQ _0x160
	LDI  R30,1
	RJMP _0x161
_0x160:
	LDI  R30,0
_0x161:
	RCALL SUBOPT_0x1D
; 0000 056C                         tx_buffer[11] = fSwing? 1: 0;
	SBRS R2,7
	RJMP _0x162
	LDI  R30,LOW(1)
	RJMP _0x163
_0x162:
	LDI  R30,LOW(0)
_0x163:
	RCALL SUBOPT_0x1E
; 0000 056D                         tx_buffer[12] = LightValue;
; 0000 056E                         tx_buffer[13] = fDisplayOn;
; 0000 056F                         tx_buffer[14] = (Mode && 0x02)? 1: 0;// bit1 of Mode is sleep
	CPI  R30,0
	BREQ _0x165
	LDI  R30,LOW(2)
	CPI  R30,0
	BRNE _0x166
_0x165:
	RJMP _0x167
_0x166:
	LDI  R30,LOW(1)
	RJMP _0x168
_0x167:
	LDI  R30,LOW(0)
_0x168:
	RCALL SUBOPT_0x1F
; 0000 0570                         send_data(16);
; 0000 0571                         }
_0x156:
; 0000 0572                     break;
	RJMP _0x147
; 0000 0573                     case 8:     // rename the FAN
_0x152:
	CPI  R30,LOW(0x8)
	BRNE _0x147
; 0000 0574                   //  NameBuffer[0] = 'P';
; 0000 0575                   //  NameBuffer[1] = 'D';
; 0000 0576                   //  NameBuffer[2] = 'e';
; 0000 0577                     for (i=0;i<10;i++)  // copy 10 byte to NameBuffer
	LDI  R18,LOW(0)
_0x16C:
	CPI  R18,10
	BRSH _0x16D
; 0000 0578                         {
; 0000 0579                         NameBuffer[i] = rx_buffer_out[i+5];
	MOV  R26,R18
	LDI  R27,0
	SUBI R26,LOW(-_NameBuffer)
	SBCI R27,HIGH(-_NameBuffer)
	RCALL SUBOPT_0x34
	__ADDW1MN _rx_buffer_out,5
	LD   R30,Z
	ST   X,R30
; 0000 057A                         }
	SUBI R18,-1
	RJMP _0x16C
_0x16D:
; 0000 057B 
; 0000 057C                     while (!fTranFinish);          // send back data
_0x16E:
	SBRS R3,5
	RJMP _0x16E
; 0000 057D                     fTranFinish = 0;
	RCALL SUBOPT_0x19
; 0000 057E                     tx_buffer[3] = 9; // send disconnect command
	LDI  R30,LOW(9)
	RCALL SUBOPT_0x1A
; 0000 057F                     send_data(16);
	LDI  R26,LOW(16)
	RCALL _send_data
; 0000 0580                     fChangeName = 1;
	SET
	BLD  R2,3
; 0000 0581                     break;
; 0000 0582                     }     // end of switch case
_0x147:
; 0000 0583                 }
; 0000 0584             }   // end of rx_receive bit
_0x142:
; 0000 0585         if (++delay10ms == 10)
_0x141:
	LDD  R26,Y+11
	SUBI R26,-LOW(1)
	STD  Y+11,R26
	CPI  R26,LOW(0xA)
	BREQ PC+2
	RJMP _0x171
; 0000 0586             {
; 0000 0587             delay10ms = 0;  // run for IR process
	LDI  R30,LOW(0)
	STD  Y+11,R30
; 0000 0588             if (fSound)
	SBRS R2,6
	RJMP _0x172
; 0000 0589                 {
; 0000 058A                 if (++sounddelay == 30)
	LDD  R26,Y+22
	SUBI R26,-LOW(1)
	STD  Y+22,R26
	CPI  R26,LOW(0x1E)
	BRNE _0x173
; 0000 058B                     {
; 0000 058C                     fSound = 0;
	CLT
	BLD  R2,6
; 0000 058D                     send_status();
	RCALL _send_status
; 0000 058E                     }
; 0000 058F                 }
_0x173:
; 0000 0590             else
	RJMP _0x174
_0x172:
; 0000 0591                 {
; 0000 0592                 sounddelay = 0;
	LDI  R30,LOW(0)
	STD  Y+22,R30
; 0000 0593                 }
_0x174:
; 0000 0594 
; 0000 0595             if (--Button_reset == 0) Button_old = 0xff;
	LDD  R30,Y+6
	SUBI R30,LOW(1)
	STD  Y+6,R30
	BRNE _0x175
	LDI  R30,LOW(255)
	STD  Y+5,R30
; 0000 0596             if (fSts2Led)
_0x175:
	SBRS R3,7
	RJMP _0x176
; 0000 0597                 {
; 0000 0598                 if (--Sts2Delay == 0) fSts2Led = 0;
	LDD  R30,Y+2
	SUBI R30,LOW(1)
	STD  Y+2,R30
	BRNE _0x177
	CLT
	BLD  R3,7
; 0000 0599                 }
_0x177:
; 0000 059A             else
	RJMP _0x178
_0x176:
; 0000 059B                 {
; 0000 059C                 Sts2Delay = 20;
	LDI  R30,LOW(20)
	STD  Y+2,R30
; 0000 059D                 }
_0x178:
; 0000 059E             switch (IrMode) // process for recieving IR data
	LDD  R30,Y+10
; 0000 059F                 {
; 0000 05A0                 case 0: // normal mode
	CPI  R30,0
	BREQ PC+2
	RJMP _0x17C
; 0000 05A1                 fStsLed = fON_OFF;
	BST  R2,2
	BLD  R2,5
; 0000 05A2                 StsDelay = 2;
	LDI  R30,LOW(2)
	STD  Y+13,R30
; 0000 05A3                 if (fIrReceived)
	SBRS R3,3
	RJMP _0x17D
; 0000 05A4                     {
; 0000 05A5                     fIrReceived = 0;
	RCALL SUBOPT_0x3B
; 0000 05A6                     Button_reset = 20;
	LDI  R30,LOW(20)
	STD  Y+6,R30
; 0000 05A7                     Button = check_IR();  // = 0: not match, = 1-MAXBUTTON: return button value
	RCALL _check_IR
	STD  Y+9,R30
; 0000 05A8                     if (Mode != 0)
	RCALL SUBOPT_0x36
	CPI  R30,0
	BREQ _0x17E
; 0000 05A9                         {
; 0000 05AA                         fSts1Led = fON_OFF;
	BST  R2,2
	RJMP _0x1CC
; 0000 05AB                         }
; 0000 05AC                     else
_0x17E:
; 0000 05AD                         {
; 0000 05AE                         fSts1Led = 0;
	CLT
_0x1CC:
	BLD  R3,2
; 0000 05AF                         }
; 0000 05B0                     if (Button != Button_old)
	LDD  R30,Y+5
	LDD  R26,Y+9
	CP   R30,R26
	BRNE PC+2
	RJMP _0x180
; 0000 05B1                         {
; 0000 05B2                         if (fON_OFF || (Button > 4) || (Button == 0))
	SBRC R2,2
	RJMP _0x182
	LDD  R26,Y+9
	CPI  R26,LOW(0x5)
	BRSH _0x182
	CPI  R26,LOW(0x0)
	BREQ _0x182
	RJMP _0x181
_0x182:
; 0000 05B3                             {
; 0000 05B4                             fSts2Led = 1;
	RCALL SUBOPT_0x35
; 0000 05B5                             switch (Button)
	LDD  R30,Y+9
; 0000 05B6                                 {
; 0000 05B7                                 case 0:
	CPI  R30,0
	BRNE _0x187
; 0000 05B8                                 ButDelay = 0;    // timeout for repeat pressing button
	RCALL SUBOPT_0x3C
; 0000 05B9                                 IrData[4] = IrData[0];
	LDS  R30,_IrData
	RCALL SUBOPT_0x3D
; 0000 05BA                                 IrData[5] = IrData[1];
; 0000 05BB                                 RepeatKount = 0;
	RCALL SUBOPT_0x3E
; 0000 05BC                                 if (bOpt == 0) IrMode = 1;     // checking IR storing condition
	SBIC 0x16,7
	RJMP _0x188
	LDI  R30,LOW(1)
	STD  Y+10,R30
; 0000 05BD                                 break;
_0x188:
	RJMP _0x186
; 0000 05BE                                 case 1: // off button
_0x187:
	CPI  R30,LOW(0x1)
	BRNE _0x189
; 0000 05BF                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05C0                                 fON_OFF = 0;    // control everything
	CLT
	RJMP _0x1CD
; 0000 05C1                                 break;
; 0000 05C2                                 case 2:   // lamp button
_0x189:
	CPI  R30,LOW(0x2)
	BRNE _0x18A
; 0000 05C3                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05C4                                 if (++LightValue == 4) LightValue = 0;
	LDS  R26,_LightValue
	SUBI R26,-LOW(1)
	STS  _LightValue,R26
	CPI  R26,LOW(0x4)
	BRNE _0x18B
	LDI  R30,LOW(0)
	STS  _LightValue,R30
; 0000 05C5                                 break;
_0x18B:
	RJMP _0x186
; 0000 05C6                                 case 3:      // mode button
_0x18A:
	CPI  R30,LOW(0x3)
	BRNE _0x18C
; 0000 05C7                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05C8                                 if (++Mode == 2) Mode = 0;
	LDS  R26,_Mode
	SUBI R26,-LOW(1)
	STS  _Mode,R26
	CPI  R26,LOW(0x2)
	BRNE _0x18D
	RCALL SUBOPT_0x33
; 0000 05C9                                 break;
_0x18D:
	RJMP _0x186
; 0000 05CA                                 case 4: // timer button -> swing
_0x18C:
	CPI  R30,LOW(0x4)
	BRNE _0x18E
; 0000 05CB                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05CC                                 fSwing = !fSwing;
	LDI  R30,LOW(128)
	EOR  R2,R30
; 0000 05CD                                 break;
	RJMP _0x186
; 0000 05CE                                 case 5: // swing -> DEC button
_0x18E:
	CPI  R30,LOW(0x5)
	BRNE _0x18F
; 0000 05CF                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05D0                                 if (FanSet-- == 0)
	MOV  R30,R13
	DEC  R13
	CPI  R30,0
	BRNE _0x190
; 0000 05D1                                     {
; 0000 05D2                                     FanSet = 0;
	CLR  R13
; 0000 05D3                                     fON_OFF = 0;
	CLT
	RJMP _0x1CE
; 0000 05D4                                     }
; 0000 05D5                                 else
_0x190:
; 0000 05D6                                     {
; 0000 05D7                                     fON_OFF = 1;
	SET
_0x1CE:
	BLD  R2,2
; 0000 05D8                                     }
; 0000 05D9                                 break;        // ON/Speed -> INC
	RJMP _0x186
; 0000 05DA                                 case 6:
_0x18F:
	CPI  R30,LOW(0x6)
	BRNE _0x186
; 0000 05DB                                 fSound = 1;
	RCALL SUBOPT_0x2C
; 0000 05DC                                 if (++FanSet >= 10) FanSet = 9;
	INC  R13
	LDI  R30,LOW(10)
	CP   R13,R30
	BRLO _0x193
	LDI  R30,LOW(9)
	MOV  R13,R30
; 0000 05DD                                 fON_OFF = 1;
_0x193:
	SET
_0x1CD:
	BLD  R2,2
; 0000 05DE                                 break;
; 0000 05DF                                 }
_0x186:
; 0000 05E0                             }
; 0000 05E1                         }
_0x181:
; 0000 05E2                     Button_old = Button;
_0x180:
	LDD  R30,Y+9
	STD  Y+5,R30
; 0000 05E3                     }
; 0000 05E4                 if (bSw == 0)
_0x17D:
	SBIC 0x13,2
	RJMP _0x194
; 0000 05E5                     {
; 0000 05E6                     if (++ButDelay > 250)
	RCALL SUBOPT_0x3F
	CPI  R26,LOW(0xFB)
	LDI  R30,HIGH(0xFB)
	CPC  R27,R30
	BRLT _0x195
; 0000 05E7                         {
; 0000 05E8                         IrMode = 11;
	LDI  R30,LOW(11)
	STD  Y+10,R30
; 0000 05E9                         RepeatKount = 0;
	RCALL SUBOPT_0x3E
; 0000 05EA                         ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 05EB 
; 0000 05EC //                        IrMode = 2;
; 0000 05ED  //                       ButDelay = 0;
; 0000 05EE    //                     ButtonId = 0;
; 0000 05EF                         }
; 0000 05F0                     }
_0x195:
; 0000 05F1                 else
	RJMP _0x196
_0x194:
; 0000 05F2                     {
; 0000 05F3                     ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 05F4                     }
_0x196:
; 0000 05F5                 break;
	RJMP _0x17B
; 0000 05F6                 case 1:     // check IRstoring condition for repeat every
_0x17C:
	CPI  R30,LOW(0x1)
	BRNE _0x197
; 0000 05F7                 if (++ButDelay > 100) IrMode = 0;   // exit when timeout
	RCALL SUBOPT_0x3F
	CPI  R26,LOW(0x65)
	LDI  R30,HIGH(0x65)
	CPC  R27,R30
	BRLT _0x198
	LDI  R30,LOW(0)
	STD  Y+10,R30
; 0000 05F8                 if (fIrReceived)
_0x198:
	SBRS R3,3
	RJMP _0x199
; 0000 05F9                     {
; 0000 05FA                     fIrReceived = 0;
	RCALL SUBOPT_0x3B
; 0000 05FB                     if ((IrData[4] != IrData[0]) || (IrData[5] != IrData[1]))
	__GETB2MN _IrData,4
	LDS  R30,_IrData
	CP   R30,R26
	BRNE _0x19B
	__GETB2MN _IrData,5
	__GETB1MN _IrData,1
	CP   R30,R26
	BREQ _0x19A
_0x19B:
; 0000 05FC                         {
; 0000 05FD                         ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 05FE                         fStsLed = 1;
	SET
	BLD  R2,5
; 0000 05FF                         if (++RepeatKount == 8)
	RCALL SUBOPT_0x40
	CPI  R26,LOW(0x8)
	BRNE _0x19D
; 0000 0600                             {
; 0000 0601                             IrMode = 11;
	LDI  R30,LOW(11)
	STD  Y+10,R30
; 0000 0602                             RepeatKount = 0;
	RCALL SUBOPT_0x3E
; 0000 0603                             ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 0604                             }
; 0000 0605                         }
_0x19D:
; 0000 0606                     IrData[4] = IrData[0];
_0x19A:
	LDS  R30,_IrData
	RCALL SUBOPT_0x3D
; 0000 0607                     IrData[5] = IrData[1];
; 0000 0608                     }
; 0000 0609                 break;
_0x199:
	RJMP _0x17B
; 0000 060A                 case 11:
_0x197:
	CPI  R30,LOW(0xB)
	BRNE _0x19E
; 0000 060B                 if (++ButDelay == 10)
	RCALL SUBOPT_0x3F
	SBIW R26,10
	BRNE _0x19F
; 0000 060C                     {
; 0000 060D                     ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 060E                     fSts2Led = !fSts2Led;
	RCALL SUBOPT_0x41
; 0000 060F                     if (++RepeatKount == 30)
	CPI  R26,LOW(0x1E)
	BRNE _0x1A0
; 0000 0610                         {
; 0000 0611                         IrMode = 2;
	LDI  R30,LOW(2)
	RCALL SUBOPT_0x42
; 0000 0612                         ButtonId = 0;
; 0000 0613                         fIrReceived = 0;
; 0000 0614                         }
; 0000 0615                     }
_0x1A0:
; 0000 0616                 break;
_0x19F:
	RJMP _0x17B
; 0000 0617                 case 2:     //store IR data
_0x19E:
	CPI  R30,LOW(0x2)
	BREQ PC+2
	RJMP _0x1A1
; 0000 0618                 fSts2Led = 1;
	RCALL SUBOPT_0x35
; 0000 0619                 if (fIrReceived)
	SBRS R3,3
	RJMP _0x1A2
; 0000 061A                     {
; 0000 061B                     fIrReceived = 0;
	RCALL SUBOPT_0x3B
; 0000 061C                     ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 061D             //        Button_reset = 30;
; 0000 061E             //        i = Set_IR(ButtonId);     // check for exist and store, return 1 if new, 0 if old
; 0000 061F             //        Button = check_IR();  // = 0: not match, = 1-MAXBUTTON: return button value
; 0000 0620                     i = ButtonId;
	LDD  R18,Y+8
; 0000 0621                     if (i != 0) i--;
	CPI  R18,0
	BREQ _0x1A3
	SUBI R18,1
; 0000 0622                     if ((IrData[0] != RemoteData[StoreId*MAXBUTTON*2 + i*2]) || (IrData[1] != RemoteData[StoreId*MAXBUTT ...
_0x1A3:
	RCALL SUBOPT_0x43
	RCALL SUBOPT_0x44
	RCALL SUBOPT_0x32
	RCALL SUBOPT_0x9
	CP   R30,R26
	BRNE _0x1A5
	RCALL SUBOPT_0x43
	RCALL SUBOPT_0x44
	SUBI R30,-LOW(1)
	RCALL SUBOPT_0x32
	RCALL SUBOPT_0x8
	CP   R30,R26
	BREQ _0x1A4
_0x1A5:
; 0000 0623                         {
; 0000 0624                         RemoteData[StoreId*MAXBUTTON*2 + ButtonId*2] = IrData[0];
	RCALL SUBOPT_0x43
	RCALL SUBOPT_0x45
	LDI  R31,0
	RCALL SUBOPT_0x2F
	RCALL SUBOPT_0x9
	STD  Z+0,R26
; 0000 0625                         RemoteData[StoreId*MAXBUTTON*2 + ButtonId*2 + 1] = IrData[1];
	RCALL SUBOPT_0x43
	RCALL SUBOPT_0x45
	SUBI R30,-LOW(1)
	LDI  R31,0
	RCALL SUBOPT_0x2F
	RCALL SUBOPT_0x8
	STD  Z+0,R26
; 0000 0626                         fStsLed = 1;
	SET
	BLD  R2,5
; 0000 0627                         if (++ButtonId == MAXBUTTON)  // save data
	LDD  R26,Y+8
	SUBI R26,-LOW(1)
	STD  Y+8,R26
	CPI  R26,LOW(0x6)
	BRNE _0x1A7
; 0000 0628                             {
; 0000 0629                             if (++StoreId == MAXREMOTE) StoreId = 0;
	LDS  R26,_StoreId
	SUBI R26,-LOW(1)
	STS  _StoreId,R26
	CPI  R26,LOW(0x1)
	BRNE _0x1A8
	LDI  R30,LOW(0)
	STS  _StoreId,R30
; 0000 062A                             save_eeprom();
_0x1A8:
	RCALL _save_eeprom
; 0000 062B                             IrMode = 4;
	LDI  R30,LOW(4)
	STD  Y+10,R30
; 0000 062C                             ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 062D                             RepeatKount = 0;
	RCALL SUBOPT_0x3E
; 0000 062E                             }
; 0000 062F                         }
_0x1A7:
; 0000 0630                     }
_0x1A4:
; 0000 0631              //   if (bSw == 1) IrMode = 0;
; 0000 0632                 if (++ButDelay > 500)
_0x1A2:
	RCALL SUBOPT_0x3F
	CPI  R26,LOW(0x1F5)
	LDI  R30,HIGH(0x1F5)
	CPC  R27,R30
	BRLT _0x1A9
; 0000 0633                     {
; 0000 0634                     if (bSw == 0)
	SBIC 0x13,2
	RJMP _0x1AA
; 0000 0635                         {
; 0000 0636                         IrMode = 5; // clear all IR data
	LDI  R30,LOW(5)
	RJMP _0x1CF
; 0000 0637                         }
; 0000 0638                     else
_0x1AA:
; 0000 0639                         {
; 0000 063A                         IrMode = 0;
	LDI  R30,LOW(0)
_0x1CF:
	STD  Y+10,R30
; 0000 063B                         }
; 0000 063C                     }
; 0000 063D                 break;
_0x1A9:
	RJMP _0x17B
; 0000 063E                 case 3:
_0x1A1:
	CPI  R30,LOW(0x3)
	BRNE _0x1AC
; 0000 063F                 if (bSw == 1)
	SBIS 0x13,2
	RJMP _0x1AD
; 0000 0640                     {
; 0000 0641                     IrMode = 0;
	LDI  R30,LOW(0)
	STD  Y+10,R30
; 0000 0642                     fSts2Led = 0;
	CLT
	BLD  R3,7
; 0000 0643                     }
; 0000 0644                 if (++RepeatTimeout == 20)    //200ms
_0x1AD:
	LDD  R26,Y+4
	SUBI R26,-LOW(1)
	STD  Y+4,R26
	CPI  R26,LOW(0x14)
	BRNE _0x1AE
; 0000 0645                     {
; 0000 0646                     RepeatTimeout = 0;
	LDI  R30,LOW(0)
	STD  Y+4,R30
; 0000 0647                     fSts2Led = 1;
	RCALL SUBOPT_0x35
; 0000 0648                     }
; 0000 0649                 break;
_0x1AE:
	RJMP _0x17B
; 0000 064A                 case 4:
_0x1AC:
	CPI  R30,LOW(0x4)
	BRNE _0x1AF
; 0000 064B                 if (++ButDelay == 10)
	RCALL SUBOPT_0x3F
	SBIW R26,10
	BRNE _0x1B0
; 0000 064C                     {
; 0000 064D                     ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 064E                     fSts2Led = !fSts2Led;
	RCALL SUBOPT_0x41
; 0000 064F                     if (++RepeatKount == 30)
	CPI  R26,LOW(0x1E)
	BRNE _0x1B1
; 0000 0650                         {
; 0000 0651                         IrMode = 3;
	LDI  R30,LOW(3)
	RCALL SUBOPT_0x42
; 0000 0652                         ButtonId = 0;
; 0000 0653                         fIrReceived = 0;
; 0000 0654                         }
; 0000 0655                     }
_0x1B1:
; 0000 0656                 break;
_0x1B0:
	RJMP _0x17B
; 0000 0657                 case 5:
_0x1AF:
	CPI  R30,LOW(0x5)
	BRNE _0x1B2
; 0000 0658                 for (i=0;i<MAXREMOTE*MAXBUTTON;i++)
	LDI  R18,LOW(0)
_0x1B4:
	CPI  R18,6
	BRSH _0x1B5
; 0000 0659                     {
; 0000 065A                         RemoteData[i] = 0;
	RCALL SUBOPT_0x34
	RCALL SUBOPT_0x2F
	LDI  R26,LOW(0)
	STD  Z+0,R26
; 0000 065B                     }
	SUBI R18,-1
	RJMP _0x1B4
_0x1B5:
; 0000 065C                 save_eeprom();
	RCALL _save_eeprom
; 0000 065D                 ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 065E                 RepeatKount = 0;
	RCALL SUBOPT_0x3E
; 0000 065F                 IrMode = 6; // inform all cleared
	LDI  R30,LOW(6)
	STD  Y+10,R30
; 0000 0660                 break;
	RJMP _0x17B
; 0000 0661                 case 6:
_0x1B2:
	CPI  R30,LOW(0x6)
	BRNE _0x1B9
; 0000 0662                 if (++ButDelay == 10)
	RCALL SUBOPT_0x3F
	SBIW R26,10
	BRNE _0x1B7
; 0000 0663                     {
; 0000 0664                     ButDelay = 0;
	RCALL SUBOPT_0x3C
; 0000 0665                     fSts2Led = !fSts2Led;
	RCALL SUBOPT_0x41
; 0000 0666                     if (++RepeatKount == 40)
	CPI  R26,LOW(0x28)
	BRNE _0x1B8
; 0000 0667                         {
; 0000 0668                         IrMode = 0;
	LDI  R30,LOW(0)
	STD  Y+10,R30
; 0000 0669          //               ButtonId = 0;
; 0000 066A                         fIrReceived = 0;
	RCALL SUBOPT_0x3B
; 0000 066B                         }
; 0000 066C                     }
_0x1B8:
; 0000 066D                 break;
_0x1B7:
; 0000 066E                 default:
_0x1B9:
; 0000 066F                 break;
; 0000 0670                 }
_0x17B:
; 0000 0671             }
; 0000 0672 
; 0000 0673 bSts1Led = fSts1Led;
_0x171:
	SBRC R3,2
	RJMP _0x1BA
	CBI  0x15,4
	RJMP _0x1BB
_0x1BA:
	SBI  0x15,4
_0x1BB:
; 0000 0674 bSts2Led = fSts2Led;
	SBRC R3,7
	RJMP _0x1BC
	CBI  0x15,3
	RJMP _0x1BD
_0x1BC:
	SBI  0x15,3
_0x1BD:
; 0000 0675 bStsLed = fStsLed;
	SBRC R2,5
	RJMP _0x1BE
	CBI  0x12,4
	RJMP _0x1BF
_0x1BE:
	SBI  0x12,4
_0x1BF:
; 0000 0676         } // end of 1ms timer
; 0000 0677       }    // end of while loop
_0x10E:
	RJMP _0x10B
; 0000 0678 }
_0x1C0:
	RJMP _0x1C0
; .FEND

	.DSEG
_VERSION:
	.BYTE 0x8
_NAME_CMD:
	.BYTE 0x9
_AUTO_FAN:
	.BYTE 0x1C
_CRC8_DATA:
	.BYTE 0x100
_LedBuff:
	.BYTE 0xC
_LightValue:
	.BYTE 0x1
_BatT:
	.BYTE 0x1
_IbatIn:
	.BYTE 0x1
_IbatOut:
	.BYTE 0x1
_Vbat:
	.BYTE 0x1
_ADid:
	.BYTE 0x1
_RandData:
	.BYTE 0x1
_RandSend:
	.BYTE 0x1
_TestIr:
	.BYTE 0x1
_NameMc:
	.BYTE 0x1
_SyncKount:
	.BYTE 0x1
_LostKount:
	.BYTE 0x1
_IrByte:
	.BYTE 0x1
_BitKount:
	.BYTE 0x1
_IrTimeOut:
	.BYTE 0x1
_NameBuffer:
	.BYTE 0xA
_IrData:
	.BYTE 0x8
_RemoteData:
	.BYTE 0xD
_StoreId:
	.BYTE 0x1
_BuzzFreq:
	.BYTE 0x1

	.ESEG
_RemoteRom:
	.BYTE 0xE

	.DSEG
_IrInt:
	.BYTE 0x2
_Rx_Mc:
	.BYTE 0x1
_tx_counter:
	.BYTE 0x1
_RxDelay:
	.BYTE 0x1
_setminute:
	.BYTE 0x1
_sethour:
	.BYTE 0x1
_Mode:
	.BYTE 0x1
_rx_buffer:
	.BYTE 0x14
_rx_buffer_out:
	.BYTE 0x14
_rx_wr_index:
	.BYTE 0x1
_tx_buffer:
	.BYTE 0x32
_tx_rd_index:
	.BYTE 0x1

	.CSEG
;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x0:
	ST   -Y,R26
	ST   -Y,R30
	ST   -Y,R31
	IN   R30,SREG
	ST   -Y,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x1:
	STS  _IrTimeOut,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 6 TIMES, CODE SIZE REDUCTION:8 WORDS
SUBOPT_0x2:
	LDI  R30,LOW(0)
	STS  _BitKount,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:6 WORDS
SUBOPT_0x3:
	LDI  R30,LOW(0)
	STS  _IrByte,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 12 TIMES, CODE SIZE REDUCTION:9 WORDS
SUBOPT_0x4:
	LDS  R30,_IrByte
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:7 WORDS
SUBOPT_0x5:
	LSR  R30
	STS  _IrByte,R30
	CPI  R17,18
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:7 WORDS
SUBOPT_0x6:
	RCALL SUBOPT_0x4
	ORI  R30,0x80
	STS  _IrByte,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:13 WORDS
SUBOPT_0x7:
	LDS  R26,_BitKount
	SUBI R26,-LOW(1)
	STS  _BitKount,R26
	CPI  R26,LOW(0x8)
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x8:
	__GETB2MN _IrData,1
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x9:
	LDS  R26,_IrData
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:8 WORDS
SUBOPT_0xA:
	BLD  R4,0
	LDS  R30,_BitKount
	SUBI R30,-LOW(1)
	STS  _BitKount,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:10 WORDS
SUBOPT_0xB:
	LDS  R30,_BitKount
	SUBI R30,-LOW(1)
	STS  _BitKount,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0xC:
	LDS  R30,_IrInt
	LDS  R31,_IrInt+1
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0xD:
	STS  _IrInt,R30
	STS  _IrInt+1,R31
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0xE:
	STS  _rx_wr_index,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0xF:
	STS  _Rx_Mc,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x10:
	LDS  R30,_rx_wr_index
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x11:
	LDS  R26,_rx_wr_index
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x12:
	LDS  R30,_tx_counter
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x13:
	RCALL SUBOPT_0x12
	SUBI R30,LOW(1)
	STS  _tx_counter,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x14:
	LDI  R31,0
	SUBI R30,LOW(-_tx_buffer)
	SBCI R31,HIGH(-_tx_buffer)
	LD   R30,Z
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x15:
	LDS  R30,_ADid
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x16:
	STS  _tx_buffer,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x17:
	SUBI R30,LOW(1)
	LDI  R31,0
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x18:
	LDS  R30,_tx_buffer
	OUT  0xC,R30
	RJMP SUBOPT_0x13

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x19:
	CLT
	BLD  R3,5
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x1A:
	__PUTB1MN _tx_buffer,3
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:3 WORDS
SUBOPT_0x1B:
	ST   X,R30
	__PUTBMRN _tx_buffer,6,13
	__POINTW1MN _tx_buffer,7
	MOVW R26,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:8 WORDS
SUBOPT_0x1C:
	ST   X,R30
	LDS  R30,_sethour
	__PUTB1MN _tx_buffer,8
	LDS  R30,_setminute
	__PUTB1MN _tx_buffer,9
	LDS  R30,_Mode
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x1D:
	__PUTB1MN _tx_buffer,10
	__POINTW1MN _tx_buffer,11
	MOVW R26,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:9 WORDS
SUBOPT_0x1E:
	ST   X,R30
	LDS  R30,_LightValue
	__PUTB1MN _tx_buffer,12
	LDI  R30,0
	SBRC R3,1
	LDI  R30,1
	__PUTB1MN _tx_buffer,13
	LDS  R30,_Mode
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x1F:
	__PUTB1MN _tx_buffer,14
	LDI  R26,LOW(16)
	RJMP _send_data

;OPTIMIZER ADDED SUBROUTINE, CALLED 17 TIMES, CODE SIZE REDUCTION:14 WORDS
SUBOPT_0x20:
	STS  _NameMc,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 13 TIMES, CODE SIZE REDUCTION:22 WORDS
SUBOPT_0x21:
	LDI  R30,LOW(0)
	STS  _SyncKount,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 8 TIMES, CODE SIZE REDUCTION:26 WORDS
SUBOPT_0x22:
	LDS  R26,_SyncKount
	SUBI R26,-LOW(1)
	STS  _SyncKount,R26
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x23:
	LDI  R30,LOW(65)
	RCALL SUBOPT_0x16
	LDI  R30,LOW(84)
	__PUTB1MN _tx_buffer,1
	CLT
	BLD  R2,4
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 6 TIMES, CODE SIZE REDUCTION:3 WORDS
SUBOPT_0x24:
	LDS  R26,_rx_buffer
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 8 TIMES, CODE SIZE REDUCTION:5 WORDS
SUBOPT_0x25:
	__GETB2MN _rx_buffer,1
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x26:
	LDI  R30,LOW(0)
	STS  _LostKount,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 7 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x27:
	LDI  R30,LOW(0)
	RJMP SUBOPT_0x20

;OPTIMIZER ADDED SUBROUTINE, CALLED 9 TIMES, CODE SIZE REDUCTION:6 WORDS
SUBOPT_0x28:
	MOV  R30,R17
	LDI  R31,0
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x29:
	MOVW R0,R30
	MOVW R26,R18
	__ADDWRN 18,19,1
	LD   R30,X
	MOVW R26,R0
	ST   X,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x2A:
	RCALL SUBOPT_0x20
	RJMP SUBOPT_0x21

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x2B:
	CLT
	BLD  R2,5
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 8 TIMES, CODE SIZE REDUCTION:5 WORDS
SUBOPT_0x2C:
	SET
	BLD  R2,6
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 7 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x2D:
	LDS  R30,_StoreId
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:14 WORDS
SUBOPT_0x2E:
	EOR  R30,R16
	LDI  R31,0
	SUBI R30,LOW(-_CRC8_DATA)
	SBCI R31,HIGH(-_CRC8_DATA)
	LD   R16,Z
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 13 TIMES, CODE SIZE REDUCTION:10 WORDS
SUBOPT_0x2F:
	SUBI R30,LOW(-_RemoteData)
	SBCI R31,HIGH(-_RemoteData)
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 8 TIMES, CODE SIZE REDUCTION:5 WORDS
SUBOPT_0x30:
	RCALL SUBOPT_0x2F
	LD   R30,Z
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:5 WORDS
SUBOPT_0x31:
	LDI  R26,LOW(6)
	MUL  R17,R26
	MOVW R30,R0
	LSL  R30
	MOV  R26,R30
	MOV  R30,R16
	LSL  R30
	ADD  R30,R26
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x32:
	LDI  R31,0
	RJMP SUBOPT_0x30

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x33:
	LDI  R30,LOW(0)
	STS  _Mode,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x34:
	MOV  R30,R18
	LDI  R31,0
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x35:
	SET
	BLD  R3,7
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x36:
	LDS  R30,_Mode
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:7 WORDS
SUBOPT_0x37:
	LDD  R30,Y+18
	SUBI R30,-LOW(1)
	STD  Y+18,R30
	RJMP SUBOPT_0x17

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x38:
	SUBI R30,LOW(-_AUTO_FAN)
	SBCI R31,HIGH(-_AUTO_FAN)
	LD   R30,Z
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x39:
	ADD  R30,R13
	STD  Y+23,R30
	LDD  R26,Y+23
	CPI  R26,LOW(0x80)
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:6 WORDS
SUBOPT_0x3A:
	LDI  R26,LOW(6)
	MUL  R30,R26
	MOVW R30,R0
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 6 TIMES, CODE SIZE REDUCTION:3 WORDS
SUBOPT_0x3B:
	CLT
	BLD  R3,3
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 11 TIMES, CODE SIZE REDUCTION:18 WORDS
SUBOPT_0x3C:
	LDI  R30,LOW(0)
	STD  Y+0,R30
	STD  Y+0+1,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:3 WORDS
SUBOPT_0x3D:
	__PUTB1MN _IrData,4
	__GETB1MN _IrData,1
	__PUTB1MN _IrData,5
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 5 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x3E:
	LDI  R30,LOW(0)
	STD  Y+7,R30
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 6 TIMES, CODE SIZE REDUCTION:18 WORDS
SUBOPT_0x3F:
	LD   R26,Y
	LDD  R27,Y+1
	ADIW R26,1
	ST   Y,R26
	STD  Y+1,R27
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:4 WORDS
SUBOPT_0x40:
	LDD  R26,Y+7
	SUBI R26,-LOW(1)
	STD  Y+7,R26
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 3 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x41:
	LDI  R30,LOW(128)
	EOR  R3,R30
	RJMP SUBOPT_0x40

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x42:
	STD  Y+10,R30
	LDI  R30,LOW(0)
	STD  Y+8,R30
	RJMP SUBOPT_0x3B

;OPTIMIZER ADDED SUBROUTINE, CALLED 4 TIMES, CODE SIZE REDUCTION:1 WORDS
SUBOPT_0x43:
	RCALL SUBOPT_0x2D
	RJMP SUBOPT_0x3A

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x44:
	LSL  R30
	MOV  R26,R30
	MOV  R30,R18
	LSL  R30
	ADD  R30,R26
	RET

;OPTIMIZER ADDED SUBROUTINE, CALLED 2 TIMES, CODE SIZE REDUCTION:2 WORDS
SUBOPT_0x45:
	LSL  R30
	MOV  R26,R30
	LDD  R30,Y+8
	LSL  R30
	ADD  R30,R26
	RET


	.CSEG
_delay_ms:
	adiw r26,0
	breq __delay_ms1
__delay_ms0:
	__DELAY_USW 0x7D0
	wdr
	sbiw r26,1
	brne __delay_ms0
__delay_ms1:
	ret

__EQB12:
	CP   R30,R26
	LDI  R30,1
	BREQ __EQB12T
	CLR  R30
__EQB12T:
	RET

__EEPROMRDB:
	SBIC EECR,EEWE
	RJMP __EEPROMRDB
	PUSH R31
	IN   R31,SREG
	CLI
	OUT  EEARL,R26
	OUT  EEARH,R27
	SBI  EECR,EERE
	IN   R30,EEDR
	OUT  SREG,R31
	POP  R31
	RET

__EEPROMWRB:
	SBIS EECR,EEWE
	RJMP __EEPROMWRB1
	WDR
	RJMP __EEPROMWRB
__EEPROMWRB1:
	IN   R25,SREG
	CLI
	OUT  EEARL,R26
	OUT  EEARH,R27
	SBI  EECR,EERE
	IN   R24,EEDR
	CP   R30,R24
	BREQ __EEPROMWRB0
	OUT  EEDR,R30
	SBI  EECR,EEMWE
	SBI  EECR,EEWE
__EEPROMWRB0:
	OUT  SREG,R25
	RET

__BSTB1:
	CLT
	TST  R30
	BREQ PC+2
	SET
	RET

__SAVELOCR4:
	ST   -Y,R19
__SAVELOCR3:
	ST   -Y,R18
__SAVELOCR2:
	ST   -Y,R17
	ST   -Y,R16
	RET

__LOADLOCR4:
	LDD  R19,Y+3
__LOADLOCR3:
	LDD  R18,Y+2
__LOADLOCR2:
	LDD  R17,Y+1
	LD   R16,Y
	RET

__INITLOCB:
__INITLOCW:
	ADD  R26,R28
	ADC  R27,R29
__INITLOC0:
	LPM  R0,Z+
	ST   X+,R0
	DEC  R24
	BRNE __INITLOC0
	RET

;END OF CODE MARKER
__END_OF_CODE:
