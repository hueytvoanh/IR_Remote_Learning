
#pragma used+
sfrb TWBR=0;
sfrb TWSR=1;
sfrb TWAR=2;
sfrb TWDR=3;
sfrb ADCL=4;
sfrb ADCH=5;
sfrw ADCW=4;      
sfrb ADCSRA=6;
sfrb ADMUX=7;
sfrb ACSR=8;
sfrb UBRRL=9;
sfrb UCSRB=0xa;
sfrb UCSRA=0xb;
sfrb UDR=0xc;
sfrb SPCR=0xd;
sfrb SPSR=0xe;
sfrb SPDR=0xf;
sfrb PIND=0x10;
sfrb DDRD=0x11;
sfrb PORTD=0x12;
sfrb PINC=0x13;
sfrb DDRC=0x14;
sfrb PORTC=0x15;
sfrb PINB=0x16;
sfrb DDRB=0x17;
sfrb PORTB=0x18;
sfrb EECR=0x1c;
sfrb EEDR=0x1d;
sfrb EEARL=0x1e;
sfrb EEARH=0x1f;
sfrw EEAR=0x1e;   
sfrb UBRRH=0x20;
sfrb UCSRC=0X20;
sfrb WDTCR=0x21;
sfrb ASSR=0x22;
sfrb OCR2=0x23;
sfrb TCNT2=0x24;
sfrb TCCR2=0x25;
sfrb ICR1L=0x26;
sfrb ICR1H=0x27;
sfrw ICR1=0x26;   
sfrb OCR1BL=0x28;
sfrb OCR1BH=0x29;
sfrw OCR1B=0x28;  
sfrb OCR1AL=0x2a;
sfrb OCR1AH=0x2b;
sfrw OCR1A=0x2a;  
sfrb TCNT1L=0x2c;
sfrb TCNT1H=0x2d;
sfrw TCNT1=0x2c;  
sfrb TCCR1B=0x2e;
sfrb TCCR1A=0x2f;
sfrb SFIOR=0x30;
sfrb OSCCAL=0x31;
sfrb TCNT0=0x32;
sfrb TCCR0=0x33;
sfrb MCUCSR=0x34;
sfrb MCUCR=0x35;
sfrb TWCR=0x36;
sfrb SPMCR=0x37;
sfrb TIFR=0x38;
sfrb TIMSK=0x39;
sfrb GIFR=0x3a;
sfrb GICR=0x3b;
sfrb SPL=0x3d;
sfrb SPH=0x3e;
sfrb SREG=0x3f;
#pragma used-

#asm
	#ifndef __SLEEP_DEFINED__
	#define __SLEEP_DEFINED__
	.EQU __se_bit=0x80
	.EQU __sm_mask=0x70
	.EQU __sm_powerdown=0x20
	.EQU __sm_powersave=0x30
	.EQU __sm_standby=0x60
	.EQU __sm_ext_standby=0x70
	.EQU __sm_adc_noise_red=0x10
	.SET power_ctrl_reg=mcucr
	#endif
#endasm

#pragma used+

void delay_us(unsigned int n);
void delay_ms(unsigned int n);

#pragma used-

const unsigned char     VERSION[8]={'F','O','R','T','E','K','1','F'};
const unsigned char     NAME[] = "PDE Gift";
const unsigned char     NAME_CMD[] = "AT+NAME=";

const unsigned char   AUTO_FAN[28]={120,0,60,-2,30,-4,60,0,60,-2,60,0,60,2,60,0,60,-2,40,-4,60,0,60,-2,120,0,60,2}; 

const unsigned char   FAN[6]={0x04,0x02,0x40,0x20,0x10,0x08};
const unsigned char   TEST[8]={~0x01,~0x02,~0x04,~0x08,~0x10,~0x20,~0x40,~0x80};

const unsigned char   MaledInv[18]={~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2),~(0x01 << 6) & ~(0x01 << 5),~(0x01 << 7) & ~(0x01 << 6) &  ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 1),~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 1),~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 1) & ~(0x01 << 2),~(0x01 << 7) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 1) & ~(0x01 << 2),~(0x01 << 7) & ~(0x01 << 1) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2),~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5),~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2)  & ~(0x01 << 1),~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 2)  & ~(0x01 << 1),
~(0x01 << 7) & ~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 3) & ~(0x01 << 2)  & ~(0x01 << 1),~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2)  & ~(0x01 << 1),~(0x01 << 7) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2),~(0x01 << 6) & ~(0x01 << 5) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 1),~(0x01 << 7) & ~(0x01 << 4) & ~(0x01 << 3) & ~(0x01 << 2)  & ~(0x01 << 1),~(0x01 << 7) & ~(0x01 << 3) & ~(0x01 << 2)  & ~(0x01 << 1),~(0x01 << 1),0xFF};   

const char CRC8_DATA[256]={
0x00, 0x5e, 0xbc, 0xe2, 0x61, 0x3f, 0xdd, 0x83, 0xc2, 0x9c, 0x7e, 0x20, 0xa3, 0xfd, 0x1f, 0x41,
0x9d, 0xc3, 0x21, 0x7f, 0xfc, 0xa2, 0x40, 0x1e,	0x5f, 0x01, 0xe3, 0xbd, 0x3e, 0x60, 0x82, 0xdc,
0x23, 0x7d, 0x9f, 0xc1, 0x42, 0x1c, 0xfe, 0xa0,	0xe1, 0xbf, 0x5d, 0x03, 0x80, 0xde, 0x3c, 0x62,
0xbe, 0xe0, 0x02, 0x5c, 0xdf, 0x81, 0x63, 0x3d,	0x7c, 0x22, 0xc0, 0x9e, 0x1d, 0x43, 0xa1, 0xff,
0x46, 0x18, 0xfa, 0xa4, 0x27, 0x79, 0x9b, 0xc5,	0x84, 0xda, 0x38, 0x66, 0xe5, 0xbb, 0x59, 0x07,
0xdb, 0x85, 0x67, 0x39, 0xba, 0xe4, 0x06, 0x58,	0x19, 0x47, 0xa5, 0xfb, 0x78, 0x26, 0xc4, 0x9a,
0x65, 0x3b, 0xd9, 0x87, 0x04, 0x5a, 0xb8, 0xe6,	0xa7, 0xf9, 0x1b, 0x45, 0xc6, 0x98, 0x7a, 0x24,
0xf8, 0xa6, 0x44, 0x1a, 0x99, 0xc7, 0x25, 0x7b,	0x3a, 0x64, 0x86, 0xd8, 0x5b, 0x05, 0xe7, 0xb9,
0x8c, 0xd2, 0x30, 0x6e, 0xed, 0xb3, 0x51, 0x0f,	0x4e, 0x10, 0xf2, 0xac, 0x2f, 0x71, 0x93, 0xcd,
0x11, 0x4f, 0xad, 0xf3, 0x70, 0x2e, 0xcc, 0x92,	0xd3, 0x8d, 0x6f, 0x31, 0xb2, 0xec, 0x0e, 0x50,
0xaf, 0xf1, 0x13, 0x4d, 0xce, 0x90, 0x72, 0x2c,	0x6d, 0x33, 0xd1, 0x8f, 0x0c, 0x52, 0xb0, 0xee,
0x32, 0x6c, 0x8e, 0xd0, 0x53, 0x0d, 0xef, 0xb1,	0xf0, 0xae, 0x4c, 0x12, 0x91, 0xcf, 0x2d, 0x73,
0xca, 0x94, 0x76, 0x28, 0xab, 0xf5, 0x17, 0x49,	0x08, 0x56, 0xb4, 0xea, 0x69, 0x37, 0xd5, 0x8b,
0x57, 0x09, 0xeb, 0xb5, 0x36, 0x68, 0x8a, 0xd4,	0x95, 0xcb, 0x29, 0x77, 0xf4, 0xaa, 0x48, 0x16,
0xe9, 0xb7, 0x55, 0x0b, 0x88, 0xd6, 0x34, 0x6a,	0x2b, 0x75, 0x97, 0xc9, 0x4a, 0x14, 0xf6, 0xa8,
0x74, 0x2a, 0xc8, 0x96, 0x15, 0x4b, 0xa9, 0xf7,	0xb6, 0xe8, 0x0a, 0x54, 0xd7, 0x89, 0x6b, 0x35};

char    IrMc = 0,SPIid = 0,SPI_L,SPI_H,SPI_data,Kount100us;
char    LedBuff[12],FanSet = 6,BatPWM = 1,LightValue,LightPWM;
char    BatT, IbatIn, IbatOut, Vbat, ADid = 0;
char    RandData,RandSend,CYCLE = 5,TestIr;
char    NameMc = 0,SyncKount,LostKount,IrByte,BitKount,IrTimeOut;
char    NameBuffer[10],IrData[8],RemoteData[2*6*1+1],StoreId;
char    BuzzFreq;

eeprom char RemoteRom[2*6*1+2];
int     IrInt;

char    Rx_Mc = 0,tx_counter,RxDelay = 0;
char    setminute, sethour,Mode = 0;
bit     f1ms_ov,fDisplayMode,fON_OFF = 1,fChangeName = 0,fRxReceived = 0;
bit     fStsLed,fSound,fSwing,fTimerOn,fDisplayOn = 1,fSts1Led,fIrReceived;

bit     fRx_receive = 0,fTranFinish = 1,fProtect = 0, fSts2Led,fPulse,fRC5;

interrupt [3] void ext_int1_isr(void)
{

char temp,i;

temp = Kount100us;
Kount100us = 0;       
IrTimeOut = 20;
switch (IrMc)
{
case 0:  

IrMc = 1;
break;
case 1:        
if ((temp > 70) && (temp < 170)) 
{
BitKount = 0;
IrMc = 2;  
IrByte = 0;

} 
else if ((temp > 10) && (temp < 23))   
{   
MCUCR=(0<<3       ) | (1<<2       ) | (0<<1       ) | (0<<0       );    
BitKount = 0;
IrMc = 30; 

IrInt = 0;
}  
else 
{
IrMc = 0;

}
break;             
case 2:           
if ((temp > 28) || (temp < 8))    
{
IrMc = 0;   
}                        
else
{     
IrByte >>= 1;  
if (temp > 17) IrByte |= 0x80;
if (++BitKount == 8)
{
IrData[0] = IrByte;
BitKount = 0;
IrByte = 0;
IrMc = 3;
}
}
break;
case 3:           
if ((temp > 28) || (temp < 8))    
{
IrMc = 0;   
}                        
else
{     
IrByte >>= 1;  
if (temp > 17) IrByte |= 0x80;
if (++BitKount == 8)
{
IrData[1] = IrByte;
BitKount = 0;
IrByte = 0;
IrMc = 4;
}
}
break;          
case 4:           
if ((temp > 28) || (temp < 8))    
{
IrMc = 0;   
}                        
else
{     
IrByte >>= 1;  
if (temp > 17) IrByte |= 0x80;
if (++BitKount == 8)
{
IrData[2] = IrByte;
BitKount = 0;
IrByte = 0;
IrMc = 5;
}
}
break;  
case 5:           
if ((temp > 28) || (temp < 8))    
{
IrMc = 0;   
}                        
else
{     
IrByte >>= 1;  
if (temp > 17) IrByte |= 0x80;
if (++BitKount == 8)
{
IrData[3] = IrByte;         

if ((IrData[0] ^ IrData[1] == 0xFF) && (IrData[2] ^ IrData[3] == 0xFF)) 
{

fIrReceived = 1;
IrData[1] = IrData[2];   
fRC5 = 0;
}
BitKount = 0;
IrByte = 0;
IrMc = 0;    
}
}
break;
case 10:             
if ((temp > 4) && (temp < 15))  
{
IrMc = 11;  
fPulse = 0; 
BitKount ++;
} 
else if ((temp >= 15) && (temp < 23))  
{
IrMc = 12;  
BitKount ++;
fPulse = 0;
} 
break;             
case 11:             
if ((temp > 4) && (temp < 13))   
{
fPulse = 1;
BitKount++;    
IrMc =  10;
}
break;             
case 12:        
if ((temp > 4) && (temp < 13))   
{
fPulse = 1;

IrMc =  13;
}   
else if ((temp > 13) && (temp < 23))   
{
BitKount ++;    
IrMc = 10;  
fPulse = 1;                
} 
break;
case 13:   
if ((temp > 4) && (temp < 13))   
{
fPulse = 0;
BitKount++;    
IrMc =  12;
}     
break; 
case 20:   
fRC5 = 1;   
IrTimeOut = 8;  
if (BitKount < 20)
{                          
BitKount ++;
}
else
{
IrMc = 255;
}
break;

case 30:     
fRC5 = 1;   
IrTimeOut = 5;  
if (temp > 3 && temp < 15)  
{
IrInt <<= 1;
if (temp > 8) IrInt |= 1;  
BitKount ++;
if (BitKount < 11)
{         
IrMc = 31;  
}
else
{

fIrReceived = 1;         
fRC5 = 1;
IrData[0] = (IrInt & 0xFF00)>>8;
IrData[1] = (IrInt & 0x00ff);

MCUCR = (1<<3       ) | (0<<2       ) | (0<<1       ) | (0<<0       );    
IrMc = 0;
}
}
else
{

}
break;
case 31:     

IrTimeOut = 5;  
IrMc = 30;
break;  

case 255:   
break;
}

}

char rx_buffer[20];
char rx_buffer_out[20];

unsigned char rx_wr_index,rx_rd_index;

interrupt [12] void usart_rx_isr(void)
{
char status1,data;
status1=UCSRA;
data=UDR;                               

if ((status1 & ((1<<4       ) | (1<<2       ) | (1<<3       )))==0)
{
switch (Rx_Mc)   
{    
case 0:
{
rx_buffer[0]=data;   
rx_wr_index=1;
Rx_Mc = 1;   
RxDelay = 40;
}
break;
case 1:         
rx_buffer[rx_wr_index]=data;                                         
RxDelay = 40;     
++rx_wr_index;
if ((rx_wr_index == 20) ||(rx_wr_index == rx_buffer[0]))
{                                
{
fRx_receive = 1;
for (rx_wr_index=0;rx_wr_index<20;rx_wr_index++)      
{
rx_buffer_out[rx_wr_index] = rx_buffer[rx_wr_index];
} 
}
Rx_Mc = 0;
};
break; 
default:
Rx_Mc = 0; 
}
}
}

#pragma used+
#pragma used-

char tx_buffer[50];

unsigned char tx_wr_index,tx_rd_index,tx_counter;

interrupt [14] void usart_tx_isr(void)
{
if (tx_counter != 0)
{      

--tx_counter;
UDR=tx_buffer[tx_rd_index];

if (++tx_rd_index == 50) tx_rd_index=0;
}  
else 
{          

fTranFinish = 1;
}
}

#pragma used+

#pragma used-

interrupt [10] void timer0_ovf_isr(void)
{

TCNT0=-125-2;     

f1ms_ov = 1;   
if (--IrTimeOut == 0)  
{        
MCUCR=(1<<3       ) | (0<<2       ) | (0<<1       ) | (0<<0       );    
IrMc = 0;            
}
}

interrupt [4] void timer2_comp_isr(void)
{

Kount100us ++;          
if (fSound)
{
if (++BuzzFreq == 4)
{
BuzzFreq = 0;
PORTB.0 = !PORTB.0;
}
}  
else
{
PORTB.0 = 0;
BuzzFreq = 0;
}

}

unsigned char read_adc(unsigned char adc_input)
{
ADMUX=adc_input | (0x60 & 0xff);

delay_us(10);

ADCSRA|=0x40;

while ((ADCSRA & 0x10)==0);
ADCSRA|=0x10;
return ADCH;
}

void ADC()
{
switch (ADid)
{
case 0:
IbatIn = read_adc(0);
ADid ++;
break;     
case 1:
IbatOut = read_adc(7);
ADid ++;
break;     
case 2:
Vbat = read_adc(1);
ADid ++;
break;     
case 3:
BatT = read_adc(6);
ADid = 0;
break;     
default:
ADid = 0;
}

}

interrupt [11] void spi_isr(void)
{

}

void send_data (char bytesend)
{              
char i,checksum;         
{        
tx_rd_index = 1;
tx_counter = bytesend;  
tx_buffer[0] = bytesend;
checksum = 0;
for (i=0;i<bytesend-1;i++)
{
checksum ^= tx_buffer[i];
}           
tx_buffer[bytesend-1] = checksum;
UDR = tx_buffer[0];
tx_counter--;
}
}
void send_pkg (char bytesend)
{
while (!fTranFinish);          
fTranFinish = 0;       
tx_rd_index = 1;
tx_counter = bytesend;  
UDR = tx_buffer[0];
tx_counter--;
}
void send_status(void)
{
while (!fTranFinish);          
fTranFinish = 0;
tx_buffer[2] = RandSend; 
tx_buffer[3] = 4; 
tx_buffer[5] = fON_OFF ? 1:0;            
tx_buffer[6] = FanSet;
tx_buffer[7] = fTimerOn? 1:0;
tx_buffer[8] = sethour;
tx_buffer[9] = setminute;
tx_buffer[10] = Mode & 0x01;
tx_buffer[11] = fSwing? 1: 0;
tx_buffer[12] = LightValue;   
tx_buffer[13] = fDisplayOn;
tx_buffer[14] = ((Mode & 0x02) == 0x02)? 1: 0;

send_data(16);

}
void ChangeName(void)   
{
char i;
const char *ptr;
switch (NameMc)
{
case 0:
if (fChangeName) 
{
NameMc = 1; 
SyncKount = 0;
}

if (++SyncKount == 100) 
{
SyncKount = 0;
NameMc = 10;    
}
break;
case 1:       
if (++SyncKount == 20) 
{          
tx_buffer[0] = 'A';
tx_buffer[1] = 'T';
fRxReceived = 0;
SyncKount = 0;
send_pkg(2);
NameMc = 2;   
}
break;          
case 2:
if (fRxReceived)
{
if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
{
NameMc = 3;
}      
if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      
{
SyncKount = 0;
LostKount = 0;
NameMc = 0;     
}           
}
if (++SyncKount == 10)    
{
SyncKount = 0;
NameMc = 0;     
}
break;
case 3:    

ptr = NAME_CMD;    
for (i=0;i<8;i++)
{
tx_buffer[i] = *ptr++;
}
ptr = NameBuffer;     
SyncKount = i; 
for (i=0;i<10;i++)         
{
if (*ptr != 0) 
{
tx_buffer[i+8] = *ptr++;      
SyncKount ++;
}
else
{
break;
}
}
fRxReceived = 0;
send_pkg(SyncKount);
NameMc = 4;   
SyncKount = 0;
fChangeName = 0;
break;
case 4:
if (fRxReceived)
{

if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')
{
NameMc = 5;       

SyncKount = 0;
}
}    
if (++SyncKount == 10)
{
NameMc = 5;        
SyncKount = 18;
}
break;
case 5:                 
if (++SyncKount == 20)
{
fStsLed = 0;
NameMc = 0;  
SyncKount = 0;
fSound = 1;
}     
break;      

case 10:       

NameMc = 11;
break;
case 11:       
fStsLed = 0;    
tx_buffer[0] = 'A';
tx_buffer[1] = 'T';
fRxReceived = 0;
send_pkg(2);
NameMc = 12;
SyncKount = 0;
break;          
case 12:
if (fRxReceived)
{
if (rx_buffer[0] == 'Y' && rx_buffer[1] == 'E' && rx_buffer[1] == 'S')      
{
LostKount = 0;
}         
else if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K') LostKount ++;     
SyncKount = 0;
NameMc = 0;
}                 
else
{
if (++SyncKount == 10)
{

SyncKount = 0;
NameMc = 0;
}
} 
if (LostKount == 180     )  
{
tx_buffer[0] = 'A';
tx_buffer[1] = 'T';
tx_buffer[2] = '+';
tx_buffer[3] = 'R';
tx_buffer[4] = 'E';
tx_buffer[5] = 'S';
tx_buffer[6] = 'E';
tx_buffer[7] = 'T';
fRxReceived = 0;
send_pkg(8);
NameMc = 13;
SyncKount = 0;        
}         
break;
case 13:
if (fRxReceived)
{
LostKount = 0;
SyncKount = 0;
NameMc = 0;
if (rx_buffer[0] == 'O' && rx_buffer[1] == 'K')     
{

NameMc = 14;
}
}                 
else
{
if (++SyncKount == 10) 
{
SyncKount = 0;
NameMc = 0;
}
}              
break; 
case 14:
if (++SyncKount == 20)
{
fStsLed = 0;
NameMc = 0;
}
break;   
default:
NameMc = 0;
}
}                                          

char load_eeprom()
{
char i,crc,retry,zero;

zero = 1;
retry = 0;
do {      
crc = 0;        

StoreId = RemoteRom[0];
crc = CRC8_DATA[crc ^ StoreId];

for (i=0;i<2*6*1 + 1;i++)
{
RemoteData[i] = RemoteRom[i+1];
if (RemoteData[i] != 0) zero = 0;
crc = CRC8_DATA[crc ^ RemoteData[i]];
}
if (zero)    
{
retry = 35;
crc = 1;
}      
}
while ((++retry < 30) && (crc != 0));
return crc;
}

char save_eeprom()
{
char i,crc,retry;

retry = 0;
do {      
crc = 0;        
RemoteRom[0] = StoreId;
crc = CRC8_DATA[crc ^ StoreId];
for (i=0;i<2*6*1;i++)
{
RemoteRom[i+1] = RemoteData[i];
crc = CRC8_DATA[crc ^ RemoteData[i]];
}      
RemoteRom[2*6*1 + 1] = crc;  

delay_ms(100);
crc = 0;
for (i=0;i<2*6*1 + 2;i++)
{
crc = CRC8_DATA[crc ^ RemoteRom[i]];
}              
}
while ((++retry < 10) && (crc != 0));
return crc;
}

char check_IR(void)
{
char i,j;

for (i=0;i<1;i++)
{
for (j=0;j<6;j++)
{
if ((IrData[0] == RemoteData[i*6*2+j*2]) && (IrData[1] == RemoteData[i*6*2 + j*2 + 1]))
{
return (j+1);
}           
}
}                   
return 0;
}

void out7seg(void)
{

char i,j;
char temp;
for (j=0;j<4;j++)
{
temp = LedBuff[j];    
if (j == 0)
{

}                                  
else if (j == 2)
{

}    
else if (j == 1)
{

}
for (i=0;i<8;i++)
{
PORTB.3 = !(temp & 0x80);
temp <<= 1;
#asm("NOP");
#asm("NOP");
#asm("NOP");
PORTB.5 = 1;         
#asm("NOP");
#asm("NOP");
#asm("NOP");
PORTB.5 = 0;
}            
}
PORTB.4 = 1;
#asm("NOP");
PORTB.4 = 0;

}

void main(void)
{

char delay100ms, delay500ms=0, TestValue, i, second, minute, hour, FanRun;
char sounddelay, timerdispdelay, ModeMinute,ModeHour,AutoFanId = 0,AutoFanTime = 1;
char touch_o = 0,touch_e = 0,IfullSec = 0,StsDelay,SwMc = 0;
char delay10ms = 0, IrMode = 0, Button, ButtonId, RepeatKount,Button_reset,Button_old,RepeatTimeout;
char LedPwm = 0,Sts2Delay;
int ButDelay;
bit f1s, fTimerDisp = 0,fBatCharge = 1;
{

PORTB=0x80;
DDRB=0x7F;

PORTC=0x7C;
DDRC=0x18;

PORTD=0xFF;
DDRD=0x54;

TCCR0=0x03;
TCNT0=0x12;

TCCR1A=(0<<7       ) | (0<<6       ) | (1<<5       ) | (0<<4       ) | (0<<1       ) | (0<<0       );
TCCR1B=(1<<7       ) | (0<<6       ) | (1<<4       ) | (0<<3       ) | (0<<2       ) | (0<<1       ) | (1<<0       );
TCNT1H=0x00;
TCNT1L=0x00;
ICR1H=0x00;
ICR1L=0x7F;
OCR1AH=0x00;
OCR1AL=0x50;
OCR1BH=0x00;
OCR1BL=0x50;

ASSR=0<<3       ;
TCCR2=(0<<6          ) | (0<<5       ) | (0<<4       ) | (1<<3          ) | (0<<2       ) | (1<<1       ) | (1<<0       );
TCNT2=0x00;
OCR2=0x18;

TIMSK=(1<<7       ) | (0<<6       ) | (0<<5       ) | (0<<4       ) | (0<<3       ) | (0<<2       ) | (1<<0       );

GICR|=(1<<7       ) | (0<<6       );
MCUCR=(1<<3       ) | (0<<2       ) | (0<<1       ) | (0<<0       );
GIFR=(1<<7       ) | (0<<6       );

UCSRA=0x00;
UCSRB=0xD8;
UCSRC=0x86;
UBRRH=0x00;
UBRRL=0x33;

ACSR=0x80;
SFIOR=0x00;

ADMUX=0x60 & 0xff;
ADCSRA=0x87;

SPCR=0xD1;
SPSR=0x00;
}

#asm("sei")

TestValue = 1;
second = 0;

minute = 42;
hour = 9;
setminute = 50;
sethour = 9;
BatPWM = 12;
FanSet = 6;
FanRun = FanSet;
Mode = 0;
fTimerOn = 0;
fDisplayMode = 1;
Vbat = 250; 
PORTC.3 = 0;
PORTD.4 = 0;
fON_OFF = 0;

if (load_eeprom() != 0)
{
StoreId = 0;
for (i=0;i<2*6*1+1;i++)
{
RemoteData[i] = 0;
}                 
save_eeprom();
fSts2Led = 1;
}

fSts2Led = 0;

while (1)
{

if (f1ms_ov)
{                  
f1ms_ov = 0;
if (++RandData == 255) RandData = 1;   
if (RxDelay != 0) 
{
if (--RxDelay == 0)
{
Rx_Mc = 0; 
fRxReceived = 1;
}
}    
if (++delay100ms == 100)
{
delay100ms = 0;           
ADC();   
if (++LedPwm == 10)
{
LedPwm = 0;
}          
if (FanSet > LedPwm)
{

}            
else
{

}

if (fStsLed == 1)
{
if (--StsDelay == 0) 
{
fStsLed = 0;
StsDelay = 2;
}
}
else
{
StsDelay = 3;
}         

ChangeName();
if (++delay500ms == 5)
{
delay500ms = 0;    

if (--timerdispdelay == 0) fTimerDisp = 0;    
if (TestIr > 0)
{
TestIr --;
fSts2Led = 1;
}
f1s = !f1s;
if (f1s)
{
second ++;
IfullSec++;
if (second > 59) 
{
second = 0;       
if (++minute > 59) 
{
minute = 0;
if (++hour == 24) hour = 0;
}

if (Mode >= 2)
{
if (ModeMinute-- == 0)
{
ModeMinute = 59;
if (FanSet > 1) FanSet --;
FanRun = FanSet;
if (ModeHour-- == 0)
{
fON_OFF = 0;
}
}
}     
if (fTimerOn)
{
if ((hour == sethour) && (minute == setminute))
{
fON_OFF = 0;
fTimerOn = 0; 
RandSend = 0;  
send_status();
}
}
}     
}   
}          
TestValue *= 2;
if (TestValue == 0) TestValue = 1;

if (fON_OFF)
{ 

switch (Mode)  
{
case 0:
FanRun = FanSet; 
break;
case 1:     
if (--AutoFanTime == 0)
{
AutoFanTime = AUTO_FAN[AutoFanId++];
FanRun = FanSet + AUTO_FAN[AutoFanId++];  
if (FanRun > 127) 
{
FanRun = 0;
}           
else if (FanRun > 9)
{
FanRun = 9;
}
if (AutoFanId >= 28) AutoFanId = 0;
}
break;
case 2:
FanRun = FanSet; 
break;
case 3:
if (--AutoFanTime == 0)
{
AutoFanTime = AUTO_FAN[AutoFanId++];
FanRun = FanSet + AUTO_FAN[AutoFanId++];  
if (FanRun > 127) 
{
FanRun = 0;
}           
else if (FanRun > 9)
{
FanRun = 9;
}
if (AutoFanId >= 28) AutoFanId = 0;
}
break;
default:
Mode = 0;
}     

if (FanRun == 0)
{
OCR1BL = 0;
}
else
{   
{ 

OCR1BL = 73 + FanRun * 6; 
}
}
if (FanSet == 0) fSwing = 0;   
}
else        
{
OCR1BL = 0;       

if (Mode >= 2) Mode -= 2;   

}                   

}
if (fRx_receive)
{
fRx_receive = 0;
LostKount = 0; 
SyncKount = 0;  

if ((fProtect == 0) && (rx_buffer_out[0] == 16))    
{

switch (rx_buffer_out[3])
{      
case 1: 
hour = rx_buffer_out[5];
minute = rx_buffer_out[6];
second = rx_buffer_out[7];
while (!fTranFinish);          
fTranFinish = 0;
tx_buffer[3] = 11; 
for (i=0;i<8;i++)
{
tx_buffer[5+i] = VERSION[i];            
}
send_data(16);      
break;
case 2:       
if (RandSend != RandData)
{
RandSend = RandData;
}
else
{
RandSend = RandData ^ 0x7E;
}
send_status();
break;
case 3:    
if (rx_buffer_out[2] == RandSend)
{
fON_OFF = rx_buffer_out[5];
FanSet = rx_buffer_out[6];
fTimerOn = rx_buffer_out[7];
sethour = rx_buffer_out[8];
setminute = rx_buffer_out[9];
Mode = rx_buffer_out[10];       
fSwing = rx_buffer_out[11];
LightValue = rx_buffer_out[12];
fDisplayOn =  rx_buffer_out[13];
if (rx_buffer_out[14] == 1)     
{
Mode |= 0x02;
}
else
{
Mode &= (~0x02);
}
fSound = 1;
}
else
{     
while (!fTranFinish);          
fTranFinish = 0;
tx_buffer[2] = 0; 
tx_buffer[3] = 0; 
tx_buffer[5] = fON_OFF ? 1:0;            
tx_buffer[6] = FanSet;
tx_buffer[7] = fTimerOn? 1:0;
tx_buffer[8] = sethour;
tx_buffer[9] = setminute;
tx_buffer[10] = Mode && 0x01;
tx_buffer[11] = fSwing? 1: 0;
tx_buffer[12] = LightValue;   
tx_buffer[13] = fDisplayOn;
tx_buffer[14] = (Mode && 0x02)? 1: 0;
send_data(16);
}
break;
case 8:     

for (i=0;i<10;i++)  
{
NameBuffer[i] = rx_buffer_out[i+5];
}

while (!fTranFinish);          
fTranFinish = 0;
tx_buffer[3] = 9; 
send_data(16);   
fChangeName = 1;   
break;                   
}     
}
}   
if (++delay10ms == 10)
{
delay10ms = 0;  
if (fSound)
{
if (++sounddelay == 30)
{
fSound = 0;                   
send_status();
}
}         
else
{
sounddelay = 0;                                          
}

if (--Button_reset == 0) Button_old = 0xff;   
if (fSts2Led)
{
if (--Sts2Delay == 0) fSts2Led = 0;
}
else
{
Sts2Delay = 20;
}           
switch (IrMode) 
{
case 0: 
fStsLed = fON_OFF;
StsDelay = 2;
if (fIrReceived)
{
fIrReceived = 0;                
Button_reset = 20;
Button = check_IR();  
if (Mode != 0)
{
fSts1Led = fON_OFF;
}           
else
{
fSts1Led = 0;
}
if (Button != Button_old)
{            
if (fON_OFF || (Button > 4) || (Button == 0))
{    
fSts2Led = 1; 
switch (Button)
{
case 0:
ButDelay = 0;    
IrData[4] = IrData[0];
IrData[5] = IrData[1];
RepeatKount = 0;
if (PINB.7 == 0) IrMode = 1;     
break;
case 1: 
fSound = 1;
fON_OFF = 0;    
break;                               
case 2:   
fSound = 1;
if (++LightValue == 4) LightValue = 0;
break;                  
case 3:      
fSound = 1;
if (++Mode == 2) Mode = 0;
break;
case 4: 
fSound = 1;
fSwing = !fSwing;
break;    
case 5: 
fSound = 1;
if (FanSet-- == 0) 
{
FanSet = 0;
fON_OFF = 0;
}
else
{
fON_OFF = 1;
}
break;        
case 6:
fSound = 1;
if (++FanSet >= 10) FanSet = 9; 
fON_OFF = 1;
break;
}
}
}
Button_old = Button;
}   
if (PINC.2 == 0) 
{
if (++ButDelay > 250)
{
IrMode = 11;  
RepeatKount = 0;
ButDelay = 0;

}
}      
else
{
ButDelay = 0;
}                                                                  
break; 
case 1:     
if (++ButDelay > 100) IrMode = 0;   
if (fIrReceived)
{
fIrReceived = 0;
if ((IrData[4] != IrData[0]) || (IrData[5] != IrData[1])) 
{
ButDelay = 0;                
fStsLed = 1;
if (++RepeatKount == 8)
{
IrMode = 11;  
RepeatKount = 0;
ButDelay = 0;
} 
}               
IrData[4] = IrData[0];
IrData[5] = IrData[1];
}                
break;
case 11:        
if (++ButDelay == 10)
{
ButDelay = 0;
fSts2Led = !fSts2Led;
if (++RepeatKount == 30)
{
IrMode = 2;
ButtonId = 0;   
fIrReceived = 0;
}
}
break;   
case 2:     
fSts2Led = 1;
if (fIrReceived)
{
fIrReceived = 0; 
ButDelay = 0;               

i = ButtonId;
if (i != 0) i--;
if ((IrData[0] != RemoteData[StoreId*6*2 + i*2]) || (IrData[1] != RemoteData[StoreId*6*2 + i*2 + 1]))
{
RemoteData[StoreId*6*2 + ButtonId*2] = IrData[0];
RemoteData[StoreId*6*2 + ButtonId*2 + 1] = IrData[1];
fStsLed = 1;
if (++ButtonId == 6)  
{
if (++StoreId == 1) StoreId = 0;
save_eeprom();    
IrMode = 4;
ButDelay = 0;        
RepeatKount = 0;
}
}
}

if (++ButDelay > 500) 
{
if (PINC.2 == 0)
{
IrMode = 5; 
}
else
{
IrMode = 0;
}
}
break;
case 3:
if (PINC.2 == 1)
{
IrMode = 0;
fSts2Led = 0;
} 
if (++RepeatTimeout == 20)    
{
RepeatTimeout = 0; 
fSts2Led = 1;
}
break;    
case 4:
if (++ButDelay == 10)
{
ButDelay = 0;
fSts2Led = !fSts2Led;
if (++RepeatKount == 30)
{
IrMode = 3;
ButtonId = 0;   
fIrReceived = 0;
}
}
break;   
case 5:
for (i=0;i<1*6;i++)
{
RemoteData[i] = 0;
}              
save_eeprom();                        
ButDelay = 0;
RepeatKount = 0;
IrMode = 6; 
break;                           
case 6:
if (++ButDelay == 10)
{
ButDelay = 0;
fSts2Led = !fSts2Led;
if (++RepeatKount == 40)
{
IrMode = 0;

fIrReceived = 0;
}
}                
break;
default:
break; 
}
}

PORTC.4 = fSts1Led;
PORTC.3 = fSts2Led;
PORTD.4 = fStsLed;
} 
}    
}
